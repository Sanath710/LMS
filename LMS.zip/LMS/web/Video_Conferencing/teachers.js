var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
var stringLength = 30;
var container = document.querySelector('#jitsi-container');

function pickRandom() {
    return possible[Math.floor(Math.random() * possible.length)];
}

var randomString = Array.apply(null, Array(stringLength)).map(pickRandom).join('');
var domain = "meet.jit.si";

// const myOverwrite =
// {
//     "TOOLBAR_BUTTONS": [
//         'microphone', 'camera', 'closedcaptions', 'desktop', 'fullscreen', 'invite',
//         'fodeviceselection', 'hangup', 'profile', 'info', 'chat', 'recording',
//         'livestreaming', 'etherpad', 'sharedvideo', 'settings', 'raisehand',
//         'videoquality', 'filmstrip', 'invite', 'feedback', 'stats', 'shortcuts',
//         'tileview', 'videobackgroundblur', 'download', 'help', 'mute-everyone',
//         'e2ee'
//     ]
// };

var options = 
{
    "roomName": randomString,
    "parentNode": container,
    // "width": window.screen.width-16,
    // "height": window.screen.height-125,
    "configOverwrite": {
        "prejoinPageEnabled": false,
        "startWithVideoMuted":false,
    },
    // "interfaceConfigOverwrite": myOverwrite,
};
api = new JitsiMeetExternalAPI(domain, options);