<?php
    session_start();
    // error_reporting(0);
    if(@$_SESSION['Attend_Time']) {

        include_once("../COMMON_FILES/Connection.php");
        $uid = $_POST['uid'];
        $crse = $_POST['crse'];
        $CS = $_POST['CS'];
        $div = $_POST['div'];
        
        $fetchTime_Qry = "SELECT CRSE_SCHED_StartTime, CRSE_SCHED_EndTime 
                            FROM Mtb_CourseSchedule WHERE CRSE_SCHED_LectureLink = '$CS'";
        $fetchTime_Data = mysqli_query($con,$fetchTime_Qry);
        $fetchTime_Res = mysqli_fetch_array($fetchTime_Data);
        $st = $fetchTime_Res[0];
        $et = $fetchTime_Res[1];
    
        $date = date("Y-m-d");
         $updateQRY = "UPDATE Mtb_Attendance SET Attend_Status = 'A'
                       WHERE Attend_CRSEID = $crse AND Attend_UID = '$uid' AND DATE(Attend_Time) = '$date' 
                       AND TIME(Attend_Time) >= TIME('01:00:00') AND TIME(Attend_Time) <= TIME('21:00:00') 
                       AND Attend_Div = '$div'";
        if(mysqli_query($con,$updateQRY)) {
            unset($_SESSION['Attend_Time']);
        } else {

        }
    }

?>