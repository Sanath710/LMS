<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");

        # For VC Username Display
        $uid = $_SESSION['Sess_USR_ID'];
        $sql = "SELECT USR_FirstName,USR_EmailID,USR_LastName FROM Mtb_Users WHERE USR_ID = '$uid'";
        $data = mysqli_query($con,$sql);
        $usrData = mysqli_fetch_all($data);

        $div = $_GET['div'];
        $day = $_GET['day'];
        $crse = $_GET['course'];
        $startTime = $_GET['start'];
        $CS = $_GET['CS'];
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <title>LMS | Vide Conferencing</title>
        <!-- Essential Script -->
        <script src='../Video_Conferencing/external_api.js'></script>
        <script src="../COMMON_FILES/sweetalert.min.js"></script>
        <script src="../js/jquery.min.js"></script>
        <!-- Window Replace State -->
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "TeachersVC.php?div=<?php echo $div; ?>&day=<?php echo $day; ?>&course=<?php echo $crse; ?>&start=<?php echo $startTime; ?>&CS=<?php echo $CS; ?>");
            }
        </script>
        <link rel="stylesheet" type="text/css" href="../css/icofont.css">
        <style>
            .card .card-block {
                padding-top:0.8%!important;
                padding-bottom:0.8%!important;
            }
            *, *:before, *:after {
                box-sizing: border-box;
            }
            html {
                font-size: 16px;
            }
            .plane {
                margin: 20px auto;
                max-width: 300px;
            }
            .cockpit {
                height: 250px;
                position: relative;
                overflow: hidden;
                text-align: center;
                border-bottom: 5px solid #d8d8d8;
            }
            .cockpit:before {
                content: "";
                display: block;
                position: absolute;
                top: 0;
                left: 0;
                height: 500px;
                width: 100%;
                border-radius: 50%;
                border-right: 5px solid #d8d8d8;
                border-left: 5px solid #d8d8d8;
            }
            .cockpit h1 {
                width: 60%;
                margin: 100px auto 35px auto;
            }
            .exit {
                position: relative;
                height: 50px;
            }
            .exit:before, .exit:after {
                content: "EXIT";
                font-size: 14px;
                line-height: 18px;
                padding: 0px 2px;
                font-family: "Arial Narrow", Arial, sans-serif;
                display: block;
                position: absolute;
                background: green;
                color: white;
                top: 50%;
                transform: translate(0, -50%);
            }
            .exit:before {
                left: 0;
            }
            .exit:after {
                right: 0;
            }
            .fuselage {
                border-right: 5px solid #d8d8d8;
                border-left: 5px solid #d8d8d8;
            }
            ol {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            .seats {
                display: flex;
                width: 200%;
                height: 3.5rem;
                flex-direction: row;
                flex-wrap: nowrap;
                justify-content: flex-start;
            }
            .seat {
                display: flex;
                flex: 0 0 14.2857142857%;
                padding: 5px;
                position: relative;
            }
            /* .seat:nth-child(3) {
                margin-right: 2%;
            } */
            .seat input[type=checkbox] {
                position: absolute;
                opacity: 0;
            }
            .seat input[type=checkbox]:checked + label {
                background: #bada55;
                -webkit-animation-name: rubberBand;
                animation-name: rubberBand;
                animation-duration: 300ms;
                animation-fill-mode: both;
            }
            .seat input[type=checkbox]:disabled + label {
                background: #ddd;
                text-indent: -9999px;
                overflow: hidden;
            }
            .seat input[type=checkbox]:disabled + label:after {
                content: "X";
                text-indent: 0;
                position: absolute;
                top: 4px;
                left: 50%;
                transform: translate(-50%, 0%);
            }
            .seat input[type=checkbox]:disabled + label:hover {
                box-shadow: none;
                cursor: not-allowed;
            }
            .seat label {
                display: block;
                position: relative;
                width: 100%;
                text-align: center;
                font-size: 14px;
                font-weight: bold;
                line-height: 1.5rem;
                padding: 4px 0;
                background: #f42536;
                border-radius: 5px;
                animation-duration: 300ms;
                animation-fill-mode: both;
            }
            .seat label:before {
                content: "";
                position: absolute;
                width: 75%;
                height: 75%;
                top: 1px;
                left: 50%;
                transform: translate(-50%, 0%);
                background: rgba(255, 255, 255, .4);
                border-radius: 3px;
            }
            .seat label:hover {
                cursor: pointer;
                box-shadow: 0 0 0px 2px #5c6aff;
            }
          
            .rubberBand {
                -webkit-animation-name: rubberBand;
                animation-name: rubberBand;
            }
 
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0%;margin-left:-0.5%;width:101%;" >
                    <div class="page-wrapper" style="display:flex;margin-bottom:-2%;">
                        <div class="card" style="width:100%;">
                            <div class="card-block">
                                <div class="row">
                                    <p id="cs" style="display:none;"><?php echo $CS ?></p>
                                    <div id="jitsi-container" style="width:100%;min-height:53.3rem;"></div>
                                    <script>
                                        // var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                                        // var stringLength = 30;
                                        var container = document.querySelector('#jitsi-container');
                                        var CS = document.getElementById('cs').innerHTML;
                                        // function pickRandom() {
                                        //     return possible[Math.floor(Math.random() * possible.length)];
                                        // }

                                        // var randomString = Array.apply(null, Array(stringLength)).map(pickRandom).join('');
                                        var domain = "meet.jit.si";
                                        // document.getElementById('cs').innerHTML = randomString;
                                        const myOverwrite =
                                        {
                                            "SHOW_CHROME_EXTENSION_BANNER" : false
                                        };
                                        var options = 
                                        {
                                            "roomName": CS,
                                            "parentNode": container,
                                            // "width": window.screen.width-16,
                                            // "height": window.screen.height-125,
                                            // "configOverwrite": {
                                                // "prejoinPageEnabled": false,
                                            //     "startWithVideoMuted":false,
                                            // },
                                            "userInfo": {
                                                'displayName': '<?php echo $usrData[0][0]." ".$usrData[0][2]; ?>',
                                                'email':'<?php echo $usrData[0][1]; ?>'
                                            },
                                            "interfaceConfigOverwrite": myOverwrite,
                                        };
                                        api = new JitsiMeetExternalAPI(domain, options);
                                        
  
  
                                    </script>
                                    
                                    <?php
                                        $year = date("Y");
                                        $updateQRY = "UPDATE mtb_courseschedule SET CRSE_SCHED_LectureLink = '$CS' WHERE CRSE_SCHED_Day='$day' AND CRSE_SCHED_CourseID = $crse AND CRSE_SCHED_Year = $year AND CRSE_SCHED_Division = '$div' AND CRSE_SCHED_StartTime = '$startTime'";
                                        if(!mysqli_query($con,$updateQRY)) {
                                            echo 
                                            '<script> 
                                                swal("Alert", "Something went wrong.", "warning");
                                            </script>
                                            ';
                                        } 
                                    ?>
                                </div>
                            </div>
                        </div>
                        <script>
                            $(function () {
                                $('[data-toggle="tooltip"]').tooltip()
                            })
                        </script>
                        <!-- Side Menu (Right) -->
                        <div  class="card" style="width:5%;height:54.9rem;background-color:white;margin-left:0.7%;align-items:center;padding-top:1.5%;">
                            <h6 style="font-weight:510;margin-bottom:27%;"><u>Actions</u></h6>
                            <button type="button" class="btn btn-outline-primary btn-icon waves-effect waves-light" id="btnAttend" style="padding-left:8.5%;" data-toggle="tooltip" data-placement="left" title="Send Attendance Pop-Up">
                                <i class="fa fa-plus-square-o f-22" style="margin-top:5%;"></i>
                            </button>
                            <button type="button" class="btn btn-outline-success btn-icon waves-effect waves-light" style="padding-left:10%;margin-top:26%;" data-toggle="tooltip" data-placement="left" title="View Attendance Status">
                                <i class="fa fa-eye f-18"></i>
                            </button>
                            <button type="button" class="btn btn-outline-danger btn-icon waves-effect waves-light" style="padding-left:10%;margin-top:26%;" data-toggle="tooltip" data-placement="left" title="Set Minimum Attendance required to be marked as PRESENT for session">
                                <i class="fa fa-gear f-20"></i>
                            </button>
                            <button type="button" class="btn waves-effect waves-dark btn-inverse btn-outline-inverse btn-icon" style="padding-left:10%;margin-top:26%;" data-toggle="tooltip" data-placement="left" title="View Default Attendance Configurations">
                            <i class="fa fa-info-circle f-20"></i>
                            </button>
                        </div>
                        <script>
                            $("#btnAttend").click(function(e) {
                                e.preventDefault();
                                $.ajax({
                                    type: "POST",
                                    url: "trigger_TCHR.php",
                                    data: { 
                                        CS:'<?php echo $CS;?>',
                                        crse:'<?php echo $crse;?>',
                                        uid:'<?php echo $uid;?>',
                                        div:'<?php echo $div;?>'
                                    },
                                    success: function(result) {
                                        swal("Success", "Attendance Pop-Up Sent.", "success");
                                        var timer = setInterval(function() {
                                            $("#div_refresh").load("trigger_StatusUpdate_TCHR.php");
                                            $.ajax({
                                                type: "POST",
                                                url: "trigger_StatusUpdate_TCHR.php",
                                                data: { 
                                                    CS:'<?php echo $CS;?>',
                                                    crse:'<?php echo $crse;?>',
                                                    uid:'<?php echo $uid;?>',
                                                    div:'<?php echo $div;?>'
                                                },
                                                success: function(result) {
                                                    // SUCCESS MSG
                                                },
                                                error: function(result) {
                                                    swal("Timer Event Failed", "Something went wrong.\n", "warning");
                                                }  
                                            });
                                            // Clearing timer once executed.
                                            clearInterval(timer);
                                        }, 500);
                                    },
                                    error: function(result) {
                                        swal("Alert", "Something went wrong.\nAttendance pop-up not sent.", "warning");
                                    }
                                });
                            });
                        </script>
                        <noscript>JavaScript Disabled. Please enable JavaScript Extension or Change your browser.</noscript>
                    </div>
                    <!-- <div class="plane">
                        <ol>
                            <li class="row">
                                <ol class="seats" type="A">
                                    <li class="seat">
                                        <input type="checkbox" id="1A" />
                                        <label for="1A">1A</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" id="1B" />
                                        <label for="1B">1B</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" id="1C" />
                                        <label for="1C">1C</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" disabled id="1D" />
                                        <label for="1D">Occupied</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" id="1E" />
                                        <label for="1E">1E</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" id="1F" />
                                        <label for="1F">1F</label>
                                    </li>
                                </ol>
                            </li>
                            <li class="row">
                                <ol class="seats" type="A">
                                    <li class="seat">
                                        <input type="checkbox" id="1A" />
                                        <label for="1A">1A</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" id="1B" />
                                        <label for="1B">1B</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" id="1C" />
                                        <label for="1C">1C</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" disabled id="1D" />
                                        <label for="1D">Occupied</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" id="1E" />
                                        <label for="1E">1E</label>
                                    </li>
                                    <li class="seat">
                                        <input type="checkbox" id="1F" />
                                        <label for="1F">1F</label>
                                    </li>
                                </ol>
                            </li>
                        </ol>
                    </div> -->
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>