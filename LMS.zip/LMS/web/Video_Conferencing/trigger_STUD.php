<?php
    session_start();
    include_once("../COMMON_FILES/Connection.php");
    error_reporting(0);

    echo date("d-m-y H:m:s");

    $date = date("Y-m-d");
    $div = $_POST['div'];
    $crse = $_POST['crse'];
    print_r($_POST);
    // echo "<br/>Div : ".$div;
    $invokePopUP_Qry = "SELECT Attend_Status FROM Mtb_Attendance 
                        WHERE Attend_UID = 'T2021000001' AND Attend_CRSEID = $crse  AND DATE(Attend_Time) = '$date' 
                        AND TIME(Attend_Time) >= TIME('01:00:00') AND TIME(Attend_Time) <= TIME('23:00:00') 
                        AND Attend_Div = '$div' AND Attend_Status = 'P'";
    $invokePopUP_Data = mysqli_query($con,$invokePopUP_Qry);
    if(mysqli_fetch_assoc($invokePopUP_Data)) {
        echo "<p id='check' style=''>1</p>";
    } else {
        echo "<p id='check' style=''>0</p>";
    }
?>