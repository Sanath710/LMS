<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {
        include_once("../Student/StudentNavbar.php");
        include_once("../COMMON_FILES/Connection.php");
        $conString = $_GET['id'];

        # FOR VC USERNAME DISPLAY
        $uid = $_SESSION['Sess_USR_ID'];
        $sql = "SELECT USR_FirstName,USR_EmailID FROM Mtb_Users WHERE USR_ID = '$uid'";
        $data = mysqli_query($con,$sql);
        $usrData = mysqli_fetch_all($data);

        $CS = $conString;
        $getLectureDetails = "SELECT CRSE_SCHED_CourseID, CRSE_SCHED_Division 
                              FROM Mtb_CourseSchedule WHERE CRSE_SCHED_LectureLink = '$CS'";
        $getLectureDetailsData = mysqli_query($con,$getLectureDetails);
        $getLectureDetailsRes = mysqli_fetch_all($getLectureDetailsData);
        $crse = $getLectureDetailsRes[0][0];
        $div = $getLectureDetailsRes[0][1];
?>
<html>
    <head>
        <!-- DEVELOPER -->
        <meta name="author" content="Sanath Dinesh" />
        <title>LMS | Video Conferencing</title>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css" />
        <!-- ESSENTIAL SCRIPT -->
        <!-- <script src="../COMMON_FILES/sweetalert.min.js"></script> -->
        <script src='../Video_Conferencing/external_api.js'></script>
        <script src='../js/jquery.min.js'></script>
        <!-- <script src="http://code.jquery.com/jquery-latest.js"></script> -->
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <!-- WINDOW REPLACE STATE -->
        <script>
            // if (window.history.replaceState) 
            // {
            //     window.history.replaceState( null, null, "StudentsVC.php?id=<?php //echo $conString; ?>");
            // }
        </script>
        <style>
            .card .card-block {
                padding-top:0.8%!important;
                padding-bottom:0.8%!important;
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0%;" >
                    <div class="page-wrapper">
                        <div class="card" style="width:96%;">
                            <div class="card-block">
                                <div class="row">
                                <!-- <button onclick="markAttandance()">Try it</button> -->


                                    <p id="res"></p>
                                                                
                                    <div id="div_refresh"></div>
                                    <script>
                                        let invokeTime = 1000; 
                                        // let spark = 0;
                                        $(document).ready(function(){
                                            var timer = setInterval(function() {
                                                $.ajax({
                                                    type: "POST",
                                                    url: "trigger_STUD.php",
                                                    data: { 
                                                        CS:'<?php echo $CS; ?>',
                                                        crse:'<?php echo $crse; ?>',
                                                        div:'<?php echo $div; ?>'
                                                    },
                                                    success: function(result) {
                                                        document.getElementById("res").innerHTML = result;
                                                        if(document.getElementById("check").innerHTML == 1) {
                                                            markAttandance();
                                                            // spark = 1;
                                                        } 
                                                    },
                                                    error: function(result) {
                                                        swal("Timer Event Failed", "Something went wrong.\n", "warning");
                                                    }  
                                                });
                                            }, invokeTime);
                                        });
                                    </script>
                                    <!--   FOR ATTENDANCE   -->
                                    <p id='demo'></p>
                                    <!------------------------>
                                    <div id="jitsi-container" style="width:100%;min-height: 51.75rem;"></div>
                                    <noscript>JavaScript Disabled. Please enable JavaScript Extension or Change your browser.</noscript>
                                    <script>
                                        // ATTENDANCE MARKER.
                                        function markAttandance() {
                                            Swal.fire(
                                                {
                                                    title: 'Hello <?php echo $_SESSION['Sess_USR_ID']; ?>,<br/>You there ?',
                                                    text: "",
                                                    html: 'Timeout in <b></b> Seconds.',
                                                    icon: 'info',
                                                    timer:<?php echo 7000; ?>,
                                                    timerProgressBar: true,
                                                    didOpen: () => {
                                                        // Swal.showLoading()
                                                        const b = Swal.getHtmlContainer().querySelector('b')
                                                        timerInterval = setInterval(() => {
                                                        b.textContent = parseInt(Swal.getTimerLeft()/1000)
                                                        }, 100)
                                                    },
                                                    willClose: () => {
                                                        clearInterval(timerInterval)
                                                    },
                                                    showCancelButton: false,
                                                    confirmButtonColor: '#3085d6',
                                                    cancelButtonColor: '#d33',
                                                    confirmButtonText: 'Yup!',
                                                    allowOutsideClick: false,
                                                    allowEscapeKey: false
                                                }).then((result) => 
                                                {
                                                    if (result.isConfirmed) {
                                                        var id = "<?php echo $uid; ?>";
                                                        var value = 1;
                                                        var attentive = 1;

                                                        var xmlhttp = new XMLHttpRequest();
                                                        xmlhttp.open('POST', 'attendance_DB.php');
                                                        xmlhttp.onreadystatechange = function () {
                                                            if (xmlhttp.readyState==4) {
                                                                if(xmlhttp.status==200) {
                                                                    Swal.fire({
                                                                        title: 'Hurahh!!',
                                                                        text: "You are attentive in session.",
                                                                        icon: 'success',
                                                                    });
                                                                }
                                                            }
                                                        };
                                                        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                                        xmlhttp.send("uid=" + id + "&value="+value+"&attentive="+attentive);
                                                    } 
                                                    else {
                                                        let id = "<?php echo $uid; ?>";
                                                        var value = 0;
                                                        var attentive = 0;

                                                        var xmlhttp = new XMLHttpRequest();
                                                        xmlhttp.open('POST', 'attendance_DB.php');
                                                        xmlhttp.onreadystatechange = function () {
                                                            if (xmlhttp.readyState==4) {
                                                                if(xmlhttp.status==200) {
                                                                    Swal.fire({
                                                                        title: 'Alert',
                                                                        text: "You must pay attention in lecture.",
                                                                        icon: 'warning',
                                                                        allowOutsideClick: false,
                                                                        allowEscapeKey: false
                                                                    });
                                                                }
                                                            }
                                                        };
                                                        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                                        xmlhttp.send("uid=" + id + "&value=" +value+"&attentive="+attentive);
                                                    }
                                                })
                                        }
                                        var container = document.querySelector('#jitsi-container');
                                        const myOverwrite =
                                        {
                                            "TOOLBAR_BUTTONS": [
                                                'microphone','camera','fullscreen', 'hangup',
                                                'raisehand','videoquality', 'tileview', 'chat', 'e2ee','desktop'
                                            ],
                                            "SHOW_CHROME_EXTENSION_BANNER" : false
                                        };
                                        var domain = "meet.jit.si";
                                        var options = 
                                        {
                                            "roomName": "<?php echo $conString; ?>",
                                            "parentNode": container,
                                            "configOverwrite": {
                                                "prejoinPageEnabled": false,
                                                "startWithVideoMuted":false,
                                                "disableKick": true,
                                            },
                                            "userInfo": {
                                                'displayName': '<?php echo $uid; echo " - ".$usrData[0][0]; ?>',
                                                'email':'<?php echo $usrData[0][1]; ?>'
                                            },
                                            "interfaceConfigOverwrite":  myOverwrite
                                        };
                                        // api = new JitsiMeetExternalAPI(domain, options);
                                        // setTimeout(myFunction, 8000);
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>