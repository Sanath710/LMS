<?php
    session_start();
    include("../COMMON_FILES/Connection.php");

    $uid = $_POST['uid'];
    $crse = $_POST['crse'];
    $CS = $_POST['CS'];
    $div = $_POST['div'];

    $fetchTime_Qry = "SELECT CRSE_SCHED_StartTime, CRSE_SCHED_EndTime 
                      FROM Mtb_CourseSchedule WHERE CRSE_SCHED_LectureLink = '$CS'";
    $fetchTime_Data = mysqli_query($con,$fetchTime_Qry);
    $fetchTime_Res = mysqli_fetch_array($fetchTime_Data);
    $st = $fetchTime_Res[0];
    $et = $fetchTime_Res[1];

    $date = date("Y-m-d");
    $checkForNewEntry_Qry = "SELECT Attend_ID FROM Mtb_Attendance 
                             WHERE Attend_CRSEID = $crse AND DATE(Attend_Time) = '$date' 
                             AND TIME(Attend_Time) >= TIME('13:00:00') AND TIME(Attend_Time) <= TIME('21:00:00') 
                             AND Attend_Div = '$div'";
    $checkNewEntry_Data = mysqli_query($con,$checkForNewEntry_Qry);
    $flagNewEntry = mysqli_fetch_array($checkNewEntry_Data);
    $flagNewEntry = $flagNewEntry[0];
    $_SESSION['Attend_Time'] = $uid;
    if(!$flagNewEntry) {
        $attend_Qry = "INSERT INTO Mtb_Attendance(Attend_UID, Attend_CRSEID, Attend_Time, Attend_Total, Attend_Div, Attend_Status) VALUES ('$uid',$crse,now(),1,'$div','P')";
        if(mysqli_query($con,$attend_Qry)) {
            # INSERTED
        } else {
            # SOME ERROR OCCURED
        }
        unset($flagNewEntry);
        unset($attend_Qry);
    } else {
        $updateQRY = "UPDATE Mtb_Attendance SET Attend_Total = Attend_Total+1 
                      WHERE Attend_CRSEID = $crse AND Attend_UID = '$uid' AND DATE(Attend_Time) = '$date' 
                      AND TIME(Attend_Time) >= TIME('13:00:00') AND TIME(Attend_Time) <= TIME('21:00:00') 
                      AND Attend_Div = '$div'";
        if(mysqli_query($con,$updateQRY))
        {
            $updateStatus = "UPDATE Mtb_Attendance SET Attend_Status = 'P'
                             WHERE Attend_CRSEID = $crse AND Attend_UID = '$uid' AND DATE(Attend_Time) = '$date' 
                             AND TIME(Attend_Time) >= TIME('13:00:00') AND TIME(Attend_Time) <= TIME('21:00:00') 
                             AND Attend_Div = '$div'";
            if(mysqli_query($con,$updateStatus)) 
            {
                #UPDATED
            } 
            else {
                # SOME ERROR OCCURED
            }
        } 
        else {
            # SOME ERROR OCCURED
        }
    }
?>