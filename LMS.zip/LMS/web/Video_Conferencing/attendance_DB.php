<?php 
    session_start();
    include_once("../COMMON_FILES/Connection.php");
    // error_reporting(0);
    // echo "<pre>";
    // print_r($_POST);
    // echo "</pre>";
    // $status = 1;
    // *
    // *
    // *    REMOVE UNNECESSARY GLOBAL VARIABLES & RESTATE Time VARIABLES IN SQL QUERY
    // *    x ---------------- x
    // *    x ---------------- x
    // *
    echo date("d-m-y H:m:s");
    @$status = $_POST['value'];
    @$uid = $_SESSION['Sess_USR_ID'];
    @$crse = $_POST['crse'];
    @$div = $_POST['div'];
    @$CS = $_POST['CS'];
    $date = date("Y-m-d");
    echo "<br/>".$CS." kd<br/>";
    print_r($_POST);
    @$attentive = $_POST['attentive'];
    #
    @$fetchTime_Qry = "SELECT CRSE_SCHED_StartTime, CRSE_SCHED_EndTime 
                       FROM Mtb_CourseSchedule WHERE CRSE_SCHED_LectureLink = '$CS'";
    @$fetchTime_Data = mysqli_query($con,$fetchTime_Qry);
    @$fetchTime_Res = mysqli_fetch_array($fetchTime_Data);
    #
    @$st = $fetchTime_Res[0];
    @$et = $fetchTime_Res[1];
    #

    # Working fine ...
    function insertAttendance($status) {
        global $uid, $crse, $div, $CS, $date, $con;
        #
        if($status == 1) {
            $ins_New_Qry = "INSERT INTO Mtb_Attendance(Attend_UID, Attend_CRSEID, Attend_Time, Attend_Total, Attend_Div) 
                            VALUES ('$uid',$crse,now(),1,'$div')";
            if(mysqli_query($con,$ins_New_Qry)) {
            // 
            // ***************************************************************
            // ***************************************************************
            // 
            }  else {
                // 
                // ***************************************************************
                // ***************************************************************
                // 
            }
        } 
        else {
            // 
            // ***************************************************************
            // ***************************************************************
            // 
        }
    }

    # Working fine ...
    function updateAttendance($attentive) {
        global $uid, $crse, $div, $CS, $date, $con;
        #
        if($attentive == 1) {
            echo "******";
            $markPresence_qry = "UPDATE Mtb_Attendance SET Attend_Total = Attend_Total+1  
                                 WHERE Attend_CRSEID = $crse AND Attend_UID = 'S2021003002' AND DATE(Attend_Time) = '$date' 
                                 AND TIME(Attend_Time) >= TIME('01:00:00') AND TIME(Attend_Time) <= TIME('23:00:00') 
                                 AND Attend_Div = '$div'";
            if(mysqli_query($con,$markPresence_qry)) {
                // 
                // ***************************************************************      ADD SWAL ()
                // ***************************************************************
                // 
            } else {
                // 
                // ***************************************************************
                // ***************************************************************
                // 
            }
        } 
        else if($attentive == 0) {
            # Do Nothing.
        }
    }
    // 
    // ***************************************************************  HIDE BELOW ELEMENT <P></P> STYLE="DISPLAY:NONE;"
    // ***************************************************************
    // 
    // echo '<p id="abortInvoke">0</p>';

    # Working fine ...
    function popUpSignal() {
        #
        global $uid, $crse, $div, $CS, $date, $con,$status,$attentive;
        #
        // 
        // ***************************************************************      TCHR ID T2021000001 BELOW QRY
        // ***************************************************************
        // 
        $invokePopUP_Qry = "SELECT Attend_Status FROM Mtb_Attendance 
                            WHERE Attend_UID = 'T2021000001' AND Attend_CRSEID = $crse  AND DATE(Attend_Time) = '$date' 
                            AND TIME(Attend_Time) >= TIME('01:00:00') AND TIME(Attend_Time) <= TIME('23:00:00') 
                            AND Attend_Div = '$div' AND Attend_Status = 'P'";
        $invokePopUP_Data = mysqli_query($con,$invokePopUP_Qry);
        #
        if(@mysqli_fetch_assoc($invokePopUP_Data)) {
            // echo "Testing : ".date('H:i:s'); 
            #
            // 
            // ***************************************************************      TCHR ID T2021000001 BELOW QRY
            // ***************************************************************
            // 
            $_SESSION['Attend_Marking'] = $_SESSION['Sess_USR_ID'];
            $check = "SELECT Attend_Status, Attend_Total 
                      FROM Mtb_Attendance WHERE Attend_CRSEID = $crse 
                      AND DATE(Attend_Time) = '$date' AND TIME(Attend_Time) >= TIME('01:00:00') 
                      AND TIME(Attend_Time) <= TIME('23:00:00') AND Attend_Div = '$div' AND Attend_Status = 'P' 
                      AND Attend_UID = 'T2021000001'";
            $checkData = mysqli_query($con,$check);
            $checkRes = mysqli_fetch_assoc($checkData);
            #
            if($checkRes != '') {
                #
                $tchr_AttendTotal = $checkRes['Attend_Total'];
                #
                $alreadyIns = "SELECT Attend_Total FROM Mtb_Attendance WHERE Attend_CRSEID = $crse 
                               AND DATE(Attend_Time) = '$date' AND TIME(Attend_Time) >= TIME('01:00:00') 
                               AND TIME(Attend_Time) <= TIME('23:00:00') AND Attend_Div = '$div' AND Attend_UID = '$uid'";
                $alreadyData = mysqli_query($con,$alreadyIns);
                $alreadyRes = mysqli_fetch_assoc($alreadyData);
                #
                if(@$alreadyRes['Attend_Total'] < $tchr_AttendTotal) {
                    echo '<script>markAttendance();</script>';
                    if($alreadyRes != '') {
                        updateAttendance($attentive);
                    } else {
                        insertAttendance($status);
                    }
                } else {
                    # CODE MANIPULATION OCCURED FOR ATTENDANCE.
                }
            } else {
               # NO ATTENDANCE SIGNAL FROM TEACHER TOOK PLACE.
            }
            unset($_POST);
        } else {
            # innerHTML = 1 : JUST FOR MAINTAINING POP-UPS POPPING EVENTS,
            #                 DYNAMICALLY WITH COORDINATION WITH TEACHER'S ATTENDANCE EVENT.
            echo '<script>document.getElementById("abortInvoke").innerHTML = 1;</script>';
            // echo "*********";
            // 
            // 
            //  REMOVE echo "**************";
            // 
            // 
        }
    }

# Execution Functions ...
    popUpSignal()

?>