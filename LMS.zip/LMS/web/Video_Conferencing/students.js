var container = document.querySelector('#jitsi-container');
const myOverwrite =
{
    "TOOLBAR_BUTTONS": [
        'microphone','fullscreen', 'hangup', 'chat',
        'raisehand','videoquality', 'tileview', 'hangup', 'chat', 'e2ee','desktop'
    ],
    "SHOW_CHROME_EXTENSION_BANNER" : false
};
var domain = "meet.jit.si";
var options = 
{
    "roomName": "pxJhi5v6W33H21fX2NOkJfGJWvLVM4",
    "parentNode": container,
    "configOverwrite": {
        "prejoinPageEnabled": false,
        "startWithVideoMuted":false,
    },
    "interfaceConfigOverwrite":  myOverwrite
};
api = new JitsiMeetExternalAPI(domain, options);
