<?php

// $ch = curl_init();

// // set URL and other appropriate options
// curl_setopt($ch, CURLOPT_URL, "https://meet.jit.si/1vs1pA2RlBuKmBDrl9fiIDpupUf3Ve");
// curl_setopt($ch, CURLOPT_HEADER, 0);

// // grab URL and pass it to the browser
// curl_exec($ch);

// // close cURL resource, and free up system resources
// curl_close($ch);

?>
<html>

<body>
<!-- <iframe id="myiFrame" src="https://meet.jit.si/WPQMWWSQ22dNlTEj2CCWQmimwhoKIN#config.prejoinPageEnabled=false" style="height:50rem;width:100%;"></iframe> -->
    <script src='external_api.js'></script>

    <div id="jitsi-container">
        </div>
<script>
            var container = document.querySelector('#jitsi-container');

                 const myOverwrite =
                {
                    "TOOLBAR_BUTTONS": [
                        'microphone','fullscreen', 'hangup', 'chat', 'sharedvideo',
                        'raisehand','videoquality','feedback', 'tileview',
                       
                    ]
                    // "TOOLBAR_BUTTONS": [
                    //     'microphone', 'camera', 'closedcaptions', 'desktop', 'fullscreen',
                    //     'fodeviceselection', 'hangup', 'profile', 'info', 'chat', 'recording',
                    //     'livestreaming', 'etherpad', 'sharedvideo', 'settings', 'raisehand',
                    //     'videoquality', 'filmstrip', 'invite', 'feedback', 'stats', 'shortcuts',
                    //     'tileview', 'videobackgroundblur', 'download', 'help', 'mute-everyone',
                    //     'e2ee'
                    // ]
                };
                var domain = "meet.jit.si";
                    
                var options = 
                {
                    "roomName": "pxJhi5v6W33H21fX2NOkJfGJWvLVM4",
                    "parentNode": container,
                    // "width": window.screen.width-16,
                    // "height": window.screen.height-125,
                    "configOverwrite": {
                        "prejoinPageEnabled": false,
                        "startWithVideoMuted":false,
                    },
                    "interfaceConfigOverwrite": myOverwrite
                    // "userInfo": {
                    //                 displayName: ID,
                    //                 email: EmailID
                    //             }
                };
                
                // window.open("https://meet.jit.si/1vs1pA2RlBuKmBDrl9fiIDpupUf3Ve");
                api = new JitsiMeetExternalAPI(domain, options);
//                 window.onload = function() {
//    let myiFrame = document.getElementById("myiFrame");
//    let doc = myiFrame.contentDocument;
//    doc.body.innerHTML = doc.body.innerHTML + '<style>.video-preview{display:none;}</style>';
// }
</script>
    <!-- disableInviteFunctions -->
</body>
</html>