<html>
    <head>
        <script src='external_api.js'></script>
    </head>
    <body>
        <button id="start" type="button">Start</button>
        <!-- <div id="name"></div> -->
        <div id="jitsi-container">
        </div>
        <p id="usrID" hidden><?php echo 'S202100002';?></p>
        <p id="usrEmail" hidden><?php echo 'example@gmail.com';?></p>
        <p id="token"></p>
        <!-- <video id="video" width="640" height="480" autoplay="true"></video> -->
        <script>
        
        
            var button = document.querySelector('#start');
            var container = document.querySelector('#jitsi-container');
            var api = null;
            
            button.addEventListener('click', () => {
                var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                var stringLength = 30;

                function pickRandom() {
                    return possible[Math.floor(Math.random() * possible.length)];
                }

                var randomString = Array.apply(null, Array(stringLength)).map(pickRandom).join('');
                var domain = "meet.jit.si";
                var ID = document.getElementById("usrID").innerHTML;
                var EmailID = document.getElementById("usrEmail").innerHTML;
                // window.history.replaceState(null, null, "VC.php?id="+randomString);
                
                const myOverwrite =
                {
                    "TOOLBAR_BUTTONS": [
                        'microphone','fullscreen', 'hangup', 'chat', 'sharedvideo', 'invite',
                        'raisehand','videoquality','feedback', 'tileview', 'videobackgroundblur'
                       
                    ]
                    // "TOOLBAR_BUTTONS": [
                    //     'microphone', 'camera', 'closedcaptions', 'desktop', 'fullscreen',
                    //     'fodeviceselection', 'hangup', 'profile', 'info', 'chat', 'recording',
                    //     'livestreaming', 'etherpad', 'sharedvideo', 'settings', 'raisehand',
                    //     'videoquality', 'filmstrip', 'invite', 'feedback', 'stats', 'shortcuts',
                    //     'tileview', 'videobackgroundblur', 'download', 'help', 'mute-everyone',
                    //     'e2ee'
                    // ]
                };

                var options = 
                {
                    "roomName": randomString,
                    "parentNode": container,
                    // "width": window.screen.width-16,
                    // "height": window.screen.height-125,
                    "configOverwrite": {
                        "prejoinPageEnabled": false,
                        "startWithVideoMuted":false,
                    },
                    "interfaceConfigOverwrite": myOverwrite,
                    "brandingRoomAlias":"BVPICS",
                    "userInfo": {
                                    displayName: ID,
                                    email: EmailID
                                }
                };
                api = new JitsiMeetExternalAPI(domain, options);
                button.style.display="none";
                // document.getElementById("name").innerHTML = "Please Wait...";
            });
            // #config.startWithVideoMuted=false






            // vc = new cv.VideoCapture(video);
    
//     function processVideo() {stats.begin();
//       vc.read(src);}
//       var stream = $(`#videoId`)[0].captureStream();
// var videoTracks = stream.getVideoTracks();
// var audioTracks = stream.getAudioTracks();

// if (videoTracks.length > 0) {
//     var videoTrack = videoTracks[0];
//     room.addTrack(videoTrack); // <- room is JitsiConference object and it expects JitsiLocalTrack
// }
// if (audioTracks.length > 0) {
//     var audioTrack = audioTracks[0];
//     room.addTrack(audioTrack); // <- room is JitsiConference object and it expects JitsiLocalTrack
// }
        </script>
        <?php //echo shell_exec("Try.py");?>
    </body>
</html>