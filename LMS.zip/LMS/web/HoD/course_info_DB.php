<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include("../COMMON_FILES/Connection.php");
        // echo "<pre>";
        // print_r($_POST);
        // print_r($_FILES);
        // echo "</pre>";

        // User ID
        $uid = $_SESSION['Sess_USR_ID'];

        //Form Data Received Other than File.
        $pid = $_POST['pid'];
        $cid = $_POST['cid'];

        // For URL
        $encoded_cid = base64_encode($cid);

        $year = $_POST['year'];
        $sem = $_POST['sem'];
        $assess_Name = $_POST['a_Name'];
        $assess_Type = $_POST['ASType'];
        $assess_Date = $_POST['A_Date'];
        $assess_Time = $_POST['A_Time'];
        $weightage = $_POST['Weightage_Points'];
        $due_Date = $_POST['D_Date'];
        $due_Time = $_POST['D_Time'];
        $assess_Desc = $_POST['A_Desc'];
        $assess_Points = $_POST['A_Points'];
        $visibility = $_POST['Show_Hide'];

        // Form Data Received (Only File Related)
        $fileName = $_FILES['A_Upload']['name'];
        $fileType = $_FILES['A_Upload']['type'];
        $fileSize = $_FILES['A_Upload']['size'];
        $fileLocation = $_FILES['A_Upload']['tmp_name'];
        $fileError = $_FILES['A_Upload']['error'];

        #seperating file name with it's extension.
        $fileExt = explode('.',$fileName);
    
        #checking uploaded file's extension
        $checkExt = strtolower(end($fileExt));

        $supportedExt = array('pdf','docx');

        #file name with a random number so that similar dont get replaced
        $randomName = rand(1000,10000)."-".$_FILES["A_Upload"]["name"];

        #File + Description
        if($fileError==0 && $assess_Desc != null)
        {
            if(in_array($checkExt,$supportedExt))
            {
                #File Size > 2 KB
                if($fileSize > 20000)
                {
                    #File Size  < 5 MB
                    if($fileSize < 5242880)
                    {
                        //For Assigning New Assessment Type Name.
                        $asType_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_new WHERE CRSE_Doc_USR_ID = '$uid' AND CRSE_Doc_CourseID = $cid AND CRSE_DOC_Year = '$year' 
                                        AND CRSE_Doc_Type LIKE '$assess_Type%' GROUP BY CRSE_Doc_Type";
                        $asData = mysqli_query($con,$asType_QRY);
                        $OLD_assessmentNo = mysqli_num_rows($asData);
                        $NEW_assessmentNo = $assess_Type." ".($OLD_assessmentNo+1);

                        #TO move the uploaded file to specific location
                        if(move_uploaded_file($fileLocation, "../Uploaded_Documents/".$randomName))
                        {
                            $insert_Mtb = "INSERT INTO Mtb_CourseDocs_new (CRSE_DOC_PRGMID, CRSE_DOC_Year, CRSE_DOC_Sem, CRSE_Doc_USR_ID, CRSE_Doc_CourseID, CRSE_Doc_DocName, 
                                           CRSE_Doc_Type, CRSE_Doc_Submission, CRSE_Doc_Points)
                                           VALUES ('$pid','$year',$sem,'$uid',$cid,'$assess_Name','$NEW_assessmentNo',now(),'$assess_Points')";
                            
                            // Get Assessment Name
                            $assessment_Name = $assess_Type." ".$NEW_assessmentNo;
                            if($OLD_assessmentNo == 0) $assessment_Name = $assess_Type." 1";
                            if(mysqli_query($con,$insert_Mtb))
                            {
                                // Get Document ID which is auto generated.
                                $getDocID_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_new ORDER BY CRSE_DOC_DocID DESC LIMIT 1";
                                $getDocID_Data = mysqli_query($con,$getDocID_QRY);
                                $getDocID_Result = mysqli_fetch_assoc($getDocID_Data);

                                $DOC_ID = $getDocID_Result['CRSE_DOC_DocID'];

                                // Inserting into TCHR Relation
                                $ins_TB_TCHR = "INSERT INTO Tb_CourseDocTCHR (CRSE_DOC_TCHR_DocID, CRSE_DOC_TCHR_AvailableFromDate, CRSE_DOC_TCHR_AvailableFromTime,
                                                    CRSE_DOC_TCHR_DueDate, CRSE_DOC_TCHR_DueTime,CRSE_DOC_TCHR_Weightage,CRSE_DOC_TCHR_DocVisibility)
                                               VALUES($DOC_ID,'$assess_Date','$assess_Time','$due_Date','$due_Time',$weightage,$visibility)";
                                if(mysqli_query($con,$ins_TB_TCHR))
                                {
                                    $insert_trans_2 = "INSERT INTO Tb_CourseDocDesc VALUES ($DOC_ID,'$assess_Desc')";
                                    if(mysqli_query($con,$insert_trans_2))
                                    {
                                        $insert_trans_3 = "INSERT INTO Tb_CourseDocattached VALUES ($DOC_ID,'Uploaded_Documents/$randomName')";
                                        if(mysqli_query($con,$insert_trans_3))
                                        {
                                            header("Location:../HoD/course_info.php?s=1&id=$encoded_cid");
                                        }
                                        else
                                        {
                                            header("Location:../HoD/course_info.php?s=2&id=$encoded_cid");
                                        }
                                    }
                                    else
                                    {
                                        header("Location:../HoD/course_info.php?s=3&id=$encoded_cid");
                                    }
                                }
                                else
                                {
                                    header("Location:../HoD/course_info.php?s=4&id=$encoded_cid");
                                }
                            }
                            else 
                            {
                                header("Location:../HoD/course_info.php?s=5&id=$encoded_cid");
                            }
                        }
                        else
                        {
                            header("Location:../HoD/course_info.php?s=6&id=$encoded_cid");
                        }
                    }
                    else
                    {
                        header("Location:../HoD/course_info.php?s=7&id=$encoded_cid");
                    }
                }
                else
                {
                    header("Location:../HoD/course_info.php?s=8&id=$encoded_cid");
                }
            }
            else
            {
                header("Location:../HoD/course_info.php?s=9&id=$encoded_cid");
            }
        }
        #No File & Only Desc
        else if($fileError==4 && $assess_Desc != null)
        {
            //For Assigning New Assessment Type Name.
            $asType_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_new WHERE CRSE_Doc_USR_ID = '$uid' AND CRSE_Doc_CourseID = $cid AND CRSE_DOC_Year = '$year' 
                            AND CRSE_Doc_Type LIKE '$assess_Type%' GROUP BY CRSE_Doc_Type";
            $asData = mysqli_query($con,$asType_QRY);
            $OLD_assessmentNo = mysqli_num_rows($asData);
            $NEW_assessmentNo = $assess_Type." ".($OLD_assessmentNo+1);

            // Master table insert query
            $insert_Mtb = "INSERT INTO Mtb_CourseDocs_new (CRSE_DOC_PRGMID, CRSE_DOC_Year, CRSE_DOC_Sem, CRSE_Doc_USR_ID, CRSE_Doc_CourseID, CRSE_Doc_DocName, 
                            CRSE_Doc_Type, CRSE_Doc_Submission, CRSE_Doc_Points)
                            VALUES ('$pid','$year',$sem,'$uid',$cid,'$assess_Name','$NEW_assessmentNo',now(),'$assess_Points')";

            // Get Assessment Name
            $assessment_Name = $assess_Type." ".$OLD_assessmentNo;
            if($OLD_assessmentNo == 0) $assessment_Name = $assess_Type." 1";
            // echo $assessment_Name;

            if(mysqli_query($con,$insert_Mtb))
            {
                // Get Document ID which is auto generated.
                $getDocID_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_new ORDER BY CRSE_DOC_DocID DESC LIMIT 1";
                $getDocID_Data = mysqli_query($con,$getDocID_QRY);
                $getDocID_Result = mysqli_fetch_assoc($getDocID_Data);
                // print_r($getDocID_Result);

                $DOC_ID = $getDocID_Result['CRSE_DOC_DocID'];

                $ins_TB_TCHR = "INSERT INTO Tb_CourseDocTCHR (CRSE_DOC_TCHR_DocID, CRSE_DOC_TCHR_AvailableFromDate, CRSE_DOC_TCHR_AvailableFromTime,
                                    CRSE_DOC_TCHR_DueDate, CRSE_DOC_TCHR_DueTime,CRSE_DOC_TCHR_Weightage,CRSE_DOC_TCHR_DocVisibility)
                                VALUES($DOC_ID,'$assess_Date','$assess_Time','$due_Date','$due_Time',$weightage,$visibility)";
                if(mysqli_query($con,$ins_TB_TCHR))
                {
                    $insert_trans_2 = "INSERT INTO Tb_CourseDocDesc VALUES ($DOC_ID,'$assess_Desc')";
                    if(mysqli_query($con,$insert_trans_2))
                    {
                        header("Location:../HoD/course_info.php?s=1&id=$encoded_cid");
                    }
                    else
                    {
                        header("Location:../HoD/course_info.php?s=11&id=$encoded_cid");
                    }
                }
                else
                {
                    header("Location:../HoD/course_info.php?s=4&id=$encoded_cid");
                }
            }
            else
            {
                header("Location:../HoD/course_info.php?s=5&id=$encoded_cid");
            }
        }
        // Only File. YET TO BE ACCOMPLISHED.
        else if($fileError == 0 && ($assess_Desc == null || empty($assess_Desc)))
        {
            if(in_array($checkExt,$supportedExt))
            {
                #File Size > 2 KB
                if($fileSize > 20000)
                {
                    #File Size  < 5 MB
                    if($fileSize < 5242880)
                    {
                        //For Assigning New Assessment Type Name.
                        $asType_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_new WHERE CRSE_Doc_USR_ID = '$uid' AND CRSE_Doc_CourseID = $cid AND CRSE_DOC_Year = '$year' 
                                        AND CRSE_Doc_Type LIKE '$assess_Type%' GROUP BY CRSE_Doc_Type";
                        $asData = mysqli_query($con,$asType_QRY);
                        $OLD_assessmentNo = mysqli_num_rows($asData);
                        $NEW_assessmentNo = $assess_Type." ".($OLD_assessmentNo+1);

                        #TO move the uploaded file to specific location
                        if(move_uploaded_file($fileLocation, "../Uploaded_Documents/".$randomName))
                        {
                            $insert_Mtb = "INSERT INTO Mtb_CourseDocs_new (CRSE_DOC_PRGMID, CRSE_DOC_Year, CRSE_DOC_Sem, CRSE_Doc_USR_ID, CRSE_Doc_CourseID, CRSE_Doc_DocName, 
                                           CRSE_Doc_Type, CRSE_Doc_Submission, CRSE_Doc_Points)
                                           VALUES ('$pid','$year',$sem,'$uid',$cid,'$assess_Name','$NEW_assessmentNo',now(),'$assess_Points')";
                            
                            // Get Assessment Name
                            $assessment_Name = $assess_Type." ".$OLD_assessmentNo;
                            if($OLD_assessmentNo == 0) $assessment_Name = $assess_Type." 1";
                        
                            if(mysqli_query($con,$insert_Mtb))
                            {
                                // Get Document ID which is auto generated.
                                $getDocID_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_new ORDER BY CRSE_DOC_DocID DESC LIMIT 1";
                                $getDocID_Data = mysqli_query($con,$getDocID_QRY);
                                $getDocID_Result = mysqli_fetch_assoc($getDocID_Data);

                                $DOC_ID = $getDocID_Result['CRSE_DOC_DocID'];

                                // Inserting into TCHR Relation
                                $ins_TB_TCHR = "INSERT INTO Tb_CourseDocTCHR (CRSE_DOC_TCHR_DocID, CRSE_DOC_TCHR_AvailableFromDate, CRSE_DOC_TCHR_AvailableFromTime,
                                                    CRSE_DOC_TCHR_DueDate, CRSE_DOC_TCHR_DueTime,CRSE_DOC_TCHR_Weightage,CRSE_DOC_TCHR_DocVisibility)
                                               VALUES($DOC_ID,'$assess_Date','$assess_Time','$due_Date','$due_Time',$weightage,$visibility)";
                                if(mysqli_query($con,$ins_TB_TCHR))
                                {
                                    $insert_trans_3 = "INSERT INTO Tb_CourseDocattached VALUES ($DOC_ID,'Uploaded_Documents/$randomName')";
                                    if(mysqli_query($con,$insert_trans_3))
                                    {
                                        header("Location:../HoD/course_info.php?s=1&id=$encoded_cid");
                                    }
                                    else
                                    {
                                        header("Location:../HoD/course_info.php?s=2&id=$encoded_cid");
                                    }
                                }
                                else
                                {
                                    header("Location:../HoD/course_info.php?s=4&id=$encoded_cid");
                                }
                            }
                            else
                            {
                                header("Location:../HoD/course_info.php?s=5&id=$encoded_cid");
                            }
                        }
                        else
                        {
                            header("Location:../HoD/course_info.php?s=6&id=$encoded_cid");
                        }
                    }
                    else
                    {
                        header("Location:../HoD/course_info.php?s=7&id=$encoded_cid");
                    }
                }
                else
                {
                    header("Location:../HoD/course_info.php?s=8&id=$encoded_cid");
                }
            }
            else
            {
                header("Location:../HoD/course_info.php?s=9&id=$encoded_cid");
            }
        }
        else
        {
            header("Location:../HoD/course_info.php?s=2&id=$encoded_cid");
        }
    } 
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>