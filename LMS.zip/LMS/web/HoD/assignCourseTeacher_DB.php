<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H" || substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {  
        include("../COMMON_FILES/Connection.php");

        $pid = $_POST['selProgramID'];
        $sem = $_POST['selSem'];
        // $year = $_POST['selYear'];
        $year = date("Y");
        $tid = $_POST['selTeacherID'];
        $course = $_POST['selCourse'];
        $div = $_POST['selDivision'];
        // $usrStatus = $_POST['userStatus'];
        if(!empty($pid) && !empty($sem) && !empty($year) && !empty($tid) && !empty($course) && !empty($div))
        {
            $insert_QRY = "INSERT INTO Tb_CourseUsers(CRSE_USR_UID,CRSE_USR_PID,CRSE_USR_CourseID,CRSE_USR_Year,CRSE_USR_Sem,CRSE_USR_Division,CRSE_USR_Status)
                Values($tid,$pid,$course,$year,$sem,'$div',1)";
            $flag = mysqli_query($con,$insert_QRY);
            if(!$flag)
            {
                header("refresh:0;url=viewCourseTeacher.php?Status=1");
            }
            else
            {
                header("refresh:0;url=viewCourseTeacher.php?Status=2");
            }
        }
        else
        {
            header("refresh:0;url=viewCourseTeacher.php?Status=3");
        }
    } 
    else
    {
        echo "You Don't have previleges to access this page.<br/>This incident will be reported along with your IP.";
        header("refresh:2;url=../COMMON_FILES/logout.php");
    }
?>
