<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['Status']==1)
        {
            echo 
            '<script> 
              swal("Sorry", "This Teacher is already assigned to that course previously.", "info");
            </script>
            ';
        }
        else if($_GET['Status']==2)
        {
            echo 
            '<script> 
              swal("Success", "Course Teacher Assigned Successfully.", "success");
            </script>
            ';
        }
        else if($_GET['Status']==3)
        {
            echo 
            '<script> 
              swal("Alert", "All Fields are Compulsory.", "warning");
            </script>
            ';
        }
        $PRGM_QRY = "SELECT PID,PRGM_ID FROM Tb_ProgrammeCourseTypes,Mtb_Programme WHERE PRGM_CRSE_PID = PID GROUP BY PID";
        $PRGM_QRY_Data = mysqli_query($con,$PRGM_QRY);
        $Year_QRY = "SELECT PRGM_CRSE_AcademicYear FROM Tb_ProgrammeCourseTypes GROUP BY PRGM_CRSE_AcademicYear";
        $Year_QRY_Data = mysqli_query($con,$Year_QRY);
        $Sem_QRY = "SELECT PRGM_CRSE_Sem FROM Tb_ProgrammeCourseTypes GROUP BY PRGM_CRSE_Sem";
        $Sem_QRY_Data = mysqli_query($con,$Sem_QRY);
?>
<html>

    <head>
        <title>Course Students</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "assignCourseTeacher.php");
            }
        </script>
    </head>

    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding: 1.2% 1% 1% 1%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4>Assign Course Teacher</h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                </div>
                                <form method="POST" action="assignCourseTeacher_DB.php" style="margin-bottom:2.5%;">
                                    <div style="display:flex;flex-wrap:wrap;">
                                        <label class="col-form-label frmTxt">Programme</label>
                                        <select name='selProgramID' id='program' onchange="getCourse()" style="width:8%;margin-top:0.3%;height:2rem;margin-left:1%;">
                                        <option  value='x'>Select</option>
                                        <?php
                                            while($result = mysqli_fetch_assoc($PRGM_QRY_Data))
                                            {
                                                echo "<option  style='font-size:17px;'  value='".$result['PID']."'>".$result['PRGM_ID']."</option>";
                                            }
                                        ?>
                                        </select>
                                        <label class="col-form-label frmTxt" style="margin-left:3%;">Semester</label>&nbsp;&nbsp;
                                        <select name="selSem" id='sem' onchange="getCourse()" style="width:8%;height:2rem;margin-top:0.3%;border-top:none;
                                            border-left:none;border-right:none;margin-left:0.5%;">
                                        <option  value='x'>Select</option>
                                        <?php
                                            while($result1 = mysqli_fetch_assoc($Sem_QRY_Data))
                                            {
                                                echo "<option  style='font-size:17px;' value='".$result1['PRGM_CRSE_Sem']."'>".$result1['PRGM_CRSE_Sem']."</option>";
                                            }
                                        ?>
                                        </select>
                                        <label class="col-form-label frmTxt" style="margin-left:3%;">Enrollment Year</label>&nbsp;&nbsp;
                                        <select name="selYear" id='year' onchange="getCourse()" style="width:8%;height:2rem;margin-top:0.3%;margin-left:0.5%;
                                            border-left:none;border-right:none;border-top:none;">
                                        <option  value='x'>Select</option>
                                        <?php
                                            while($result = mysqli_fetch_assoc($Year_QRY_Data))
                                            {
                                                echo "<option  style='font-size:17px;' value='".$result['PRGM_CRSE_AcademicYear']."'>".$result['PRGM_CRSE_AcademicYear']."</option>";
                                            }
                                        ?>
                                        </select>
                                    </div>
                                    <br/>
                                <!-- </form>
                                <hr/>
                                <br/>
                                <form method="POST" action="" > -->
                                    <div id="divDisp" style="flex-wrap:wrap;display:none;">
                                        <label class="col-form-label frmTxt">Teacher ID</label>
                                        <select name='selTeacherID' style="width:11%;margin-top:0.3%;height:2rem;margin-left:1.65%;">
                                        <?php
                                            $teacherID_QRY = "SELECT UID,USR_ID,USR_FirstName,USR_LastName FROM Mtb_Users WHERE substring(USR_ID,1,1)='T' OR substring(USR_ID,1,1)='H'";
                                            $teacherID_Data = mysqli_query($con,$teacherID_QRY);
                                            while($result = mysqli_fetch_assoc($teacherID_Data))
                                            {
                                                echo "<option  style='font-size:17px;' value='".$result['UID']."'>".$result['USR_ID']."&nbsp;&nbsp;&nbsp;".$result['USR_FirstName']." ".$result['USR_LastName']."&nbsp;&nbsp;&nbsp;</option>";
                                            }
                                        ?>
                                        </select>
                                        <label class="col-form-label frmTxt" style="margin-left:3%;">Course</label>&nbsp;&nbsp;
                                        <span id="resCourse"></span>
                                        <script>
                                            function getCourse()
                                            {
                                                let program = document.getElementById("program").value;
                                                let year = document.getElementById("year").value;
                                                let sem = document.getElementById("sem").value;

                                                if(program == "Null" || year == "Null" || sem == "Null")
                                                {
                                                    // Do Nothing :)
                                                }
                                                else
                                                {
                                                    let xhr;

                                                    (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                    
                                                    let data = "program="+program+"&year="+year+"&sem="+sem;
                                                
                                                    xhr.open("POST","AJAX_AssignCourseTeacher_DB.php",true);
                                                    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                                    xhr.send(data);
                                                    xhr.onreadystatechange = display_data; 

                                                    function display_data()
                                                    {
                                                        if(xhr.readyState == 4)
                                                        {
                                                            if(xhr.status == 200)
                                                            {
                                                                document.getElementById("resCourse").innerHTML = xhr.responseText;
                                                                document.getElementById('divDisp').style.display="flex";
                                                                document.getElementById('submit').style.display="";
                                                                document.getElementById('reset').style.display="";
                                                            }
                                                            else
                                                            {
                                                                alert("There was a problem with the request");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        </script>
                                        <noscript>Your browser doesnot support JavaScript!</noscript>
                                       
                                        <label class="col-form-label frmTxt" style="margin-left:6.2%;">Division</label>&nbsp;&nbsp;
                                        <select name="selDivision" style="width:7.18%;height:2rem;margin-top:0.3%;margin-left:0.5%;">
                                        <?php
                                            echo "
                                                <option  style='font-size:17px;' value='A'> A </option>
                                                <option  style='font-size:17px;' value='B'> B </option>
                                            ";
                                        ?>
                                        </select>
                                        <label class="col-form-label frmTxt" style="margin-left:3%;">User Status : </label>&nbsp;&nbsp;&nbsp;
                                        <span style="font-size:18px;padding-top:0.5%;">
                                            Active <input type="radio" name="userStatus" value="1" checked/>&nbsp;&nbsp;
                                            Deactive <input type="radio" name="userStatus" value="0"/>
                                        <span>
                                    </div>
                                    <input type="submit" class="PGSubmit" id="submit" style="margin-top:2.3%;width:max-content;font-size:15px;height:2.5rem;padding-top:0.38%;display:none;" 
                                            onclick="return validate()" name="btnSubmit" value="Submit" />
                                    <input type="reset" class="PGSubmit" id="reset" style="margin-top:2.3%;width:max-content;margin-left:-4%;font-size:16px;height:2.5rem;display:none;
                                            padding-top:0.38%;padding-left:0.85%;padding-right:0.85%;" value="Reset" />
                                </form>
                                <script>
                                    function validate()
                                    {
                                        if(document.getElementById("program").value == "x")
                                        {
                                            swal("Alert", "Please Select a programme", "warning");
                                            return false;
                                        }
                                        if(document.getElementById("sem").value == "x")
                                        {
                                            swal("Alert", "Please Select Semester", "warning");
                                            return false;
                                        }
                                        if(document.getElementById("year").value == "x")
                                        {
                                            swal("Alert", "Please Select Year", "warning");
                                            return false;
                                        }
                                    }
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>