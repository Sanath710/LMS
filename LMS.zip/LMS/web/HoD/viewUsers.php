<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {   
    include_once("teacherNavbar.php");
    include("../COMMON_FILES/Connection.php");
    $query ="SELECT USR_ID,USR_FirstName,USR_LastName,USR_Role,USR_ContactNo,USR_EmailID FROM Mtb_Users";
    $data = mysqli_query($con,$query);

?>
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="../css/datatables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
  </head>
  <body>
  <div class="pcoded-content">
    <!-- <div class="page-header card">
     <div class="row align-items-end">
      <div class="col-lg-8">
        <div class="page-header-title">
          <i class="fa fa-book bg-c-blue" aria-hidden="true"></i>
          <div style="padding-top:1%;">
            <h5>View Programs</h5>
            <span></span>
          </div>
        </div>
      </div>
        <div class="col-lg-4">
          <div class="page-header-breadcrumb">
            <ul class=" breadcrumb breadcrumb-title">
              <li class="breadcrumb-item">
                <a href=""><i class="feather icon-home"></i></a>
              </li>
              <li class="breadcrumb-item"><a href="#!">View Programs</a> </li>
            </ul>
          </div>
        </div>
    </div>
  </div> -->
    <!-- Main Body Starts -->
    <div>
        <div class="main-body">
        <div class="page-wrapper subBodyProgram">
            <div class="page-body">
            <div class="card bodyStyling" style="margin-bottom:1.5%;">
                <div class="card-header" style="margin-top:0.5%;">
                <h4 style="font-weight:bold;">User Details</h4><hr style="width:97.8%; margin-left:0%;"/>
                </div>
                <div class="card-block">
                <div class="dt-responsive table-responsive tableView">
                    <table id="base-style" style="width:100%;font-size:17px;" class="table table-striped table-bordered nowrap tableViewProgram">
                    <thead>
                        <tr>
                          <th style="width:7%;height:4rem;padding-bottom:1.3%;">Sr No</th>
                          <th style="width:15%;height:4rem;padding-bottom:1.3%;">User ID</th>
                          <th style="width:23%;height:4rem;padding-bottom:1.3%;">User Name</th>
                          <th style="width:17%;height:4rem;padding-bottom:1.3%;">Contact No</th>
                          <th style="width:24%;height:4rem;padding-bottom:1.3%;">Email ID</th>
                          <th style="width:20%;height:4rem;padding-bottom:1.3%;">User Role</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        $cnt=1;
                        while ($result = mysqli_fetch_assoc($data)) 
                        {
                    ?>  
                        <tr style="height:3.1rem;">
                            <td ><?php echo $cnt; ?></td>
                            <td class="height_td">
                                <?php echo $result['USR_ID']; ?>
                            </td>
                            <td style="text-align:left;" >
                                <?php echo $result['USR_FirstName']." ".$result['USR_LastName']; ?>
                            </td>
                            <td style="text-align:left;" >
                                <?php echo $result['USR_ContactNo']; ?>
                            </td>
                            <td style="text-align:left;" >
                                <?php echo $result['USR_EmailID']; ?>
                            </td>
                            <td style="text-align:left;" >
                                <?php echo $result['USR_Role']; ?>
                            </td>
                        </tr>
                    <?php
                            $cnt++;
                        }
                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <script src="../js/jquery.datatables.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.buttons.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.bootstrap4.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.responsive.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/data-table-custom.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="06ff493bca0b4366a261bcf1-|49" defer=""></script>
  </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>