<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");
        $sql_Sem = "SELECT Distinct CRSE_USR_Sem FROM Tb_CourseUsers";
        $Sem_data = mysqli_query($con,$sql_Sem);
?>
<html>
    <head>
        <title>Course Students</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "studentEvaluationReport.php");
            }
        </script>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding: 1.2% 1% 1% 1%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4>Student Evaluation Report</h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                    <form method="POST" style="width:100%;">
                                        <div style="margin-left:1%;margin-top:-1%;display:flex;width:100%;">
                                            <h5> Select Semester : </h5>
                                            <select name="selSem" id='selSem' onchange="getSem()" style="margin-left:0.6%;margin-top:-0.3%;width:5%;">
                                                <option value="x">Select </option>
                                            <?php
                                                while($res = mysqli_fetch_assoc($Sem_data))
                                                {
                                                    echo "
                                                        <option value='".$res['CRSE_USR_Sem']."'>".$res['CRSE_USR_Sem']."</option>
                                                    ";
                                                }
                                            ?>
                                            </select>
                                            <h5 style="margin-left:1.3%;"> Student ID : </h5>
                                            <div id="resSem"></div>
                                            <!-- </select> -->
                                            <input type="submit" class="btnView" style="margin-top:-0.3%;margin-left:2%;" name="btnView" value="View" />
                                        </div>
                                    </form>
                                    <script>
                                            function getSem()
                                            {
                                                let sem = document.getElementById("selSem").value;

                                                if(sem == "Null")
                                                {
                                                    // Do Nothing :)
                                                }
                                                else
                                                {
                                                    let xhr;

                                                    (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                    
                                                    let data = "sem="+sem;
                                                    xhr.open("POST","AJAX_studentEvaluationReport.php",true);
                                                    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                                    xhr.send(data);
                                                    xhr.onreadystatechange = display_data; 

                                                    function display_data()
                                                    {
                                                        if(xhr.readyState == 4)
                                                        {
                                                            if(xhr.status == 200)
                                                            {
                                                                document.getElementById("resSem").innerHTML = xhr.responseText;
                                                            }
                                                            else
                                                            {
                                                                alert("There was a problem with the request");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        </script>
                                    <noscript>Your browser doesnot support JavaScript!</noscript>
                                    <table id="base-style" style="width:100%;" class="table table-striped table-bordered nowrap tableViewProgram">
                                        <thead>
                                            <tr>
                                                <th style="width:15%;">Course</th>
                                                <th style="width:15%;">Assessment</th>
                                                <th style="width:53%;">Submission Date</th>
                                                <th style="width:15%;">Grade</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            if($_POST['btnView'])
                                            {
                                                $sid = $_POST['sel_StudID'];
                                                $sem = $_POST['selSem'];
                                                $year = date("Y"); 
                                                $get_Assessments = "SELECT CRSE_ID, CRSE_Name, CRSE_Doc_DocName,CRSE_Doc_Submission,CRSE_Doc_Points FROM Mtb_Courses,
                                                                    Mtb_CourseDocs WHERE CRSE_Doc_USR_ID = '$sid' AND CRSE_Doc_Sem = $sem AND CRSE_Doc_Year = $year
                                                                    ORDER BY CRSE_ID";
                                                $assessment_data = mysqli_query($con,$get_Assessments);
                                                while($r = mysqli_fetch_assoc($assessment_data))
                                                {
                                        ?>
                                            <tr>
                                                <td><?php echo $r['CRSE_ID']." ".$r['CRSE_Name']; ?></td>
                                                <td><?php echo $r['CRSE_Doc_DocName'] ?></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        <?php
                                                }
                                            }
                                        ?>
                                        </tbody>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>