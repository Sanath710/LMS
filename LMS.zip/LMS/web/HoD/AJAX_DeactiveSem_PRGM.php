<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include("../COMMON_FILES/Connection.php");

        $stud = 0;
        $tchr = 0;
        
        $pid = $_POST['pid'];
        $year = $_POST['year'];
        $sem = $_POST['sem'];

        $query ="SELECT CRSE_USR_Sem FROM Tb_CourseUsers,Mtb_Programme 
                 WHERE PRGM_ID ='$pid' AND PID = CRSE_USR_PID GROUP BY CRSE_USR_Sem";
        $data = mysqli_query($con,$query);

        $countQry = "SELECT substring(USR_ID,1,1) AS user , count(*) AS cnt 
                     FROM Tb_courseusers, Mtb_Users, Mtb_Programme 
                     WHERE CRSE_USR_UID = UID AND CRSE_USR_PID = PID 
                     AND CRSE_USR_Sem = $sem  AND CRSE_USR_Status = 1 
                     AND PRGM_ID = '$pid' AND CRSE_USR_Year = '$year'
                     GROUP BY USR_ID
                     ORDER BY FIELD(substring(USR_ID,1,1), 'S', 'T', 'H')";
        $countData = mysqli_query($con,$countQry);

        while($res = mysqli_fetch_assoc($countData)) {
            if($res['user'] == "S") {
                $stud++;
            } else if ($res['user'] == "T" || $res['user'] == "H") {
                $tchr++;
            }
        }
        echo '<span id="totalUsers" style="display:none;">'.($stud+$tchr).'</span>';
        echo '<span id="totalTeachers" style="display:none;">'.$tchr.'</span>';
        echo '<span id="totalStudents" style="display:none;">'.$stud.'</span>';

        echo '
            <div style="display:block;margin-top:2%;">
                <h5 style="font-weight:550;">Choose Semester</h5>
                <hr style="margin-left:0%;"/>
            </div>
        ';
        echo '<div class="page-body" style="display:flex;flex-wrap:wrap;width:170%;margin-top:2%;margin-left:-3.7%;margin-right:-15%;">';
        while($batch = mysqli_fetch_assoc($data)) {
            # For checking locked / Unlocked Status
            $semester = $batch['CRSE_USR_Sem'];
            $check_Qry = "SELECT SemLock_Semester FROM Tb_SemesterLockdown WHERE SemLock_PRGMID = '$pid' AND SemLock_Batch = '$year' AND SemLock_Semester = $semester";
            $check_data = mysqli_query($con,$check_Qry);
            $r = mysqli_fetch_assoc($check_data);

            $lastStat_QRY = "SELECT SemLock_At, SemLock_CurStatus FROM Tb_SemesterLockdown 
                             WHERE SemLock_PRGMID = '$pid' AND SemLock_Batch = '$year' AND SemLock_Semester = $sem";
            $lastStat_Data = mysqli_query($con,$lastStat_QRY);
            $lastStat_Res = mysqli_fetch_assoc($lastStat_Data);
            echo ' 
                <div class="card sale-card PRGM_blocks" id="'.$batch['CRSE_USR_Sem'].'" onclick="dispBatch(\''.$batch['CRSE_USR_Sem'].'\')" style="height:9.7rem;margin-right:5%;cursor:pointer;margin-top:1%;padding-top:0.8%;">
                    <div class="text-center" style="width:100%;">
            ';      
                    if($r['SemLock_Semester'] != '') {
                        echo '<label class="label label-success" style="font-size:11px;margin-top:1rem;margin-bottom:10%">Locked</label>';
                        echo '<span id="lastLocked"style="display:none;">'.$lastStat_Res['SemLock_At'].'</span>';
                    } else {
                        echo '<label class="label label-danger" style="font-size:11px;margin-top:1rem;margin-bottom:10%">Unlocked</label>';
                    }
            echo '
                        <i class="fa fa-folder-o" style="font-size:45px;margin-right:1.7%;">
                            <h6 style="display:flex;padding:5%;margin-top:10%;">Sem '.$batch['CRSE_USR_Sem'].'</h6>
                        </i>
                    </div>
                </div>
            ';
        }
        echo '</div>';

    } else {
        header('Location:../COMMON_FILES/logout.php');
    }
?>