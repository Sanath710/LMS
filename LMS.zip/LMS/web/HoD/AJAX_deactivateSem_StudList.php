<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
        include("../COMMON_FILES/Connection.php");

        $Prgm = $_POST['pid'];
        $Year = $_POST['year'];
        $Sem = $_POST['sem'];

        $listQRY = "SELECT UID,USR_ID,USR_FirstName,USR_LastName,CRSE_USR_Division FROM Mtb_Users, Tb_CourseUsers, Mtb_Programme
                    WHERE CRSE_USR_UID = UID AND CRSE_USR_PID = PID AND PRGM_ID = '$Prgm' AND CRSE_USR_Year = '$Year'
                    AND CRSE_USR_Sem = $Sem AND CRSE_USR_Status = 1 AND USR_ID LIKE 'S%' GROUP BY USR_ID";
        $listData = mysqli_query($con,$listQRY);

        $checkData = mysqli_query($con,$listQRY);
        $checkList = mysqli_fetch_assoc($checkData);

        if($checkList != ''){
            $srno = 1;
            # Checkbox for selecting all students at once
            echo "<span style='font-size:15px;font-weight:bold;'>Select All Students ? &nbsp;<input type='checkbox' style='cursor:pointer;' id='CHK_all' onclick='all_CHK()'></span><br/><br/>";
            echo 
            "
                <table class='table table-striped' style='width:80%;border:1px solid rgba(0,0,0,.125);'>
                    <tr style='background-color:white;'>
                        <th style='width:13%;text-align:center;'>Sr No.</th>
                        <th style='width:13%;text-align:center;'>Select</th>
                        <th style='width:23%;padding-left:3%;'>Student ID</th>
                        <th style='padding-left:3%;'>Student Name</th>
                        <th style='padding-left:3%;'>Division</th>
                    </tr>
            ";
            while($resList = mysqli_fetch_assoc($listData))
            {
                echo 
                "   <tr>
                <td style='padding-left:6%;'>".($srno++)."</td>

                        <td style='text-align:center;'>
                            <input type='checkbox' class='chk_Stud' style='cursor:pointer;margin-top:8%;' value='".$resList['CRSE_USR_Division'].$resList['UID']."' name='chk_Stud[]'/>
                        </td>
                        <td style='padding-left:3%;'>".$resList['USR_ID']."</td>
                        <td style='padding-left:3%;'>".$resList['USR_FirstName']." ".$resList['USR_LastName']."</td>
                        <td style='padding-left:6%;'>".$resList['CRSE_USR_Division']."</td>
                    </tr>
                ";
            }
            echo "</table>";
        } else {
            echo "<h6 style='color:red;margin-top:-2%;font-weight:550;'>No Records Found.</h6>";
        }

        
    }
    else 
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>