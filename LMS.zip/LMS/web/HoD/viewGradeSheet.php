<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
?>
<html>
    <head>
        <title>Course Students</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "viewGradeSheet.php");
            }
        </script>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding: 1.2% 1% 1% 1%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4>Grade Sheet</h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>