<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");
        $year = date("Y");
        // LATER MODIFIED ADDED MTB_COURSES (REVERT BACK IF ANYTHING GOES WRONG)
        $sql = "SELECT CRSE_USR_CourseID,CRSE_Name FROM Tb_CourseUsers,Mtb_Users,Mtb_Courses 
                WHERE CRSE_USR_UID = UID AND CRSE_ID = CRSE_USR_CourseID 
                AND CRSE_USR_Year = $year GROUP BY CRSE_USR_CourseID";
?>
<html>
    <head>
        <title>Course Students</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "assessmentReport.php");
            }
        </script>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding: 1.2% 1% 1% 1%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4 style="font-weight:bold;">Assessments Report</h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                    <form method="POST" style="width:100%;">
                                        <div style="margin-left:1%;margin-top:-1%;display:flex;width:100%;">
                                            <h5 style="font-weight:550;"> Select Course : </h5>
                                            <select name="selCRSE" id='selCRSE'  onchange="getReport()" 
                                                style="cursor:pointer;width:10%;max-width:90%;margin-left:0.6%;margin-top:-0.3%;border: 1px solid rgba(81, 203, 238, 1);">
                                                <option value="x">Select &nbsp;&nbsp; </option>
                                            <?php
                                                $CRSE_data = mysqli_query($con,$sql);
                                                while($r = mysqli_fetch_assoc($CRSE_data))
                                                {
                                                    echo "
                                                        <option value='".$r['CRSE_USR_CourseID']."'>&nbsp;".$r['CRSE_USR_CourseID']."&nbsp;&nbsp;&nbsp;".$r['CRSE_Name']."&nbsp;&nbsp;&nbsp;&nbsp;</option>
                                                    ";
                                                }
                                            ?>
                                            </select>
                                            <!-- For dynamic sizing (width) for select element -->
                                            <script src="../js/jquery.min.js"></script>
                                            <script>
                                                $('select').change(function(){
                                                    var text = $(this).find('option:selected').text()
                                                    var $aux = $('<select/>').append($('<option/>').text(text))
                                                    $(this).after($aux)
                                                    $(this).width($aux.width())
                                                    $aux.remove()
                                                }).change()
                                            </script>
                                            <!-- <div id="resDIV" style="width:17%;"></div> -->
                                        </div>
                                    </form>
                                    <div id="resReport" style="width:100%;overflow-x:scroll;margin-left:1%;margin-top:0.5%;"></div>
                                    <script>
                                        // function getDiv()
                                        // {
                                        //     let CRSE = document.getElementById("selCRSE").value;

                                        //     if(CRSE == "x")
                                        //     {
                                        //         // Do Nothing :)
                                        //         document.getElementById("resDIV").style.display="none";
                                        //     }
                                        //     else
                                        //     {
                                        //         let xhr;

                                        //         (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                
                                        //         let data = "CRSE="+CRSE;
                                        //         xhr.open("POST","AJAX_assessmentReport.php",true);
                                        //         xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                        //         xhr.send(data);
                                        //         xhr.onreadystatechange = display_data; 

                                        //         function display_data()
                                        //         {
                                        //             if(xhr.readyState == 4)
                                        //             {
                                        //                 if(xhr.status == 200)
                                        //                 {
                                        //                     document.getElementById("resDIV").style.display="";
                                        //                     document.getElementById("resDIV").innerHTML = xhr.responseText;
                                        //                 }
                                        //                 else
                                        //                 {
                                        //                     alert("There was a problem with the request");
                                        //                 }
                                        //             }
                                        //         }
                                        //     }
                                        // }
                                        function getReport()
                                        {
                                            let CRSE = document.getElementById("selCRSE").value;

                                            if(CRSE == "x")
                                            {
                                                // Do Nothing :)
                                                // document.getElementById("resReport").style.display="none";
                                            }
                                            else
                                            {
                                                let xhr;
                                                (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                
                                                let data = "CRSE="+CRSE;
                                                xhr.open("POST","AJAX_assessmentReport.php",true);
                                                xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                                xhr.send(data);
                                                xhr.onreadystatechange = display; 
                                                
                                                function display()
                                                {
                                                    if(xhr.readyState == 4)
                                                    {
                                                        if(xhr.status == 200)
                                                        {
                                                            // document.getElementById("resReport").style.display="";
                                                            document.getElementById("resReport").innerHTML = xhr.responseText;
                                                        }
                                                        else
                                                        {
                                                            alert("There was a problem with the request");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    </script>
                                    <noscript>Your browser doesnot support JavaScript!</noscript>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>