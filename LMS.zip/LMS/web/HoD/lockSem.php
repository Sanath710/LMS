<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include("../COMMON_FILES/Connection.php");

        $pid = $_POST['L_pid'];
        $year = $_POST['L_year'];
        $sem = $_POST['L_sem'];
        $manualSelection_UID = $_POST['chk_Stud'];
        $flag = false;
        $userStatus = 1;

        $insert_QRY = "INSERT INTO Tb_CourseUsers(CRSE_USR_UID,CRSE_USR_PID,CRSE_USR_CourseID,CRSE_USR_Year,CRSE_USR_Sem,CRSE_USR_Division,CRSE_USR_Status) 
                       Values(?,?,?,?,?,?,?)";
        $stmt = mysqli_stmt_init($con);
        if(isset($manualSelection_UID)) 
        {
            if(!mysqli_stmt_prepare($stmt,$insert_QRY)) {
                echo "Error in Prepare Statement";
                header("refresh:0;url=../HoD/deactivateSemester.php?s=1");  # Prepared Stmt Error
            }
            else {
                $sql = "SELECT PID FROM Mtb_Programme WHERE PRGM_ID ='$pid'";
                $data = mysqli_query($con,$sql);
                $res = mysqli_fetch_assoc($data);
                $prgmID = $res['PID'];

                foreach($manualSelection_UID as $uid_div)
                {
                    $div = substr($uid_div,0,1);
                    $uid = intval(substr($uid_div,1,));
                    $semester = intval($sem+1);

                    $course_Qry = "SELECT CRSE_ID FROM Mtb_Courses WHERE substring(CRSE_ID,5,2) = ($sem+1)";
                    $course_Data = mysqli_query($con,$course_Qry); 
                    while($course = mysqli_fetch_assoc($course_Data)) {
                        $crse = $course['CRSE_ID'];
                        mysqli_stmt_bind_param($stmt,"iiiiisi",$uid,$prgmID,$crse,$year,$semester,$div,$userStatus);
                        if(!mysqli_stmt_execute($stmt))
                        {
                            $flag = true;
                            # For displaying error message along with Student ID, if student is already enrolled into that course previously.
                            $sql = "SELECT USR_ID FROM Mtb_Users WHERE UID = $uid";
                            $data = mysqli_query($con,$sql);
                            $result = mysqli_fetch_assoc($data);
                            $error_id = $result['USR_ID'];
                        }
                        else
                        {
                            $flag = false;
                        }
                    }
                }
                $semlck_Qry = "INSERT INTO Tb_SemesterLockdown(SemLock_PRGMID, SemLock_Batch, SemLock_Semester, SemLock_At, SemLock_CurStatus) 
                               VALUES ('$pid','$year',$sem,now(),'L')";
                if(!mysqli_query($con,$semlck_Qry)) {
                    $flag = true;
                }

                if($flag == false)
                {
                    header("refresh:0;url=../HoD/deactivateSemester.php?s=2");  # success
                }
                else
                {
                    header("refresh:0;url=../HoD/deactivateSemester.php?s=3");  # Error (DATA RECORD ISSUE)
                }
            }
        } 
        else 
        {
            if(!mysqli_stmt_prepare($stmt,$insert_QRY)) {
                echo "Error in Prepare Statement";
                header("refresh:0;url=../HoD/deactivateSemester.php?s=1");  # Prepared Stmt Error
            }
            else {
                # As we have received programme name (i.e : BCA, MCA) instead of their ID from database so for getting Programme ID, firing below query.
                $sql = "SELECT PID FROM Mtb_Programme WHERE PRGM_ID ='$pid'";
                $data = mysqli_query($con,$sql);
                $res = mysqli_fetch_assoc($data);
                $prgmID = $res['PID'];

                $user_Qry =  "SELECT CRSE_USR_UID, CRSE_USR_Division FROM Tb_CourseUsers,Mtb_Programme,Mtb_Users 
                            WHERE CRSE_USR_PID = PID AND CRSE_USR_UID = UID AND USR_ID LIKE 'S%' 
                            AND PRGM_ID = '$pid' AND CRSE_USR_Sem = $sem AND CRSE_USR_Year = '$year' AND CRSE_USR_Status = 1 
                            GROUP BY CRSE_USR_UID";
                $user_Data = mysqli_query($con,$user_Qry);

                # For enrolling multiple students at once using data received from form
                while($uid = mysqli_fetch_assoc($user_Data))
                {
                    $div = $uid['CRSE_USR_Division'];
                    $uid = intval($uid['CRSE_USR_UID']);
                    $semester = intval($sem+1);

                    $course_Qry = "SELECT CRSE_ID FROM Mtb_Courses WHERE substring(CRSE_ID,5,2) = ($sem+1)";
                    $course_Data = mysqli_query($con,$course_Qry); 
                    while($course = mysqli_fetch_assoc($course_Data)) {
                        $crse = $course['CRSE_ID'];
                        mysqli_stmt_bind_param($stmt,"iiiiisi",$uid,$prgmID,$crse,$year,$semester,$div,$userStatus);
                        if(!mysqli_stmt_execute($stmt))
                        {
                            $flag = true;
                            # For displaying error message along with Student ID, if student is already enrolled into that course previously.
                            # Not Currently in use => $error_id.
                            $sql = "SELECT USR_ID FROM Mtb_Users WHERE UID = $uid";
                            $data = mysqli_query($con,$sql);
                            $result = mysqli_fetch_assoc($data);
                            $error_id = $result['USR_ID'];
                        }
                        else
                        {
                            $flag = false;
                        }
                    }
                }
                $semlck_Qry = "INSERT INTO Tb_SemesterLockdown(SemLock_PRGMID, SemLock_Batch, SemLock_Semester, SemLock_At, SemLock_CurStatus) 
                               VALUES ('$pid','$year',$sem,now(),'L')";
                if(!mysqli_query($con,$semlck_Qry)) {
                    $flag = true;
                }
                if($flag == false)
                {
                    header("refresh:0;url=../HoD/deactivateSemester.php?s=2");  # success
                }
                else
                {
                    header("refresh:0;url=../HoD/deactivateSemester.php?s=3");  # Error (DATA RECORD ISSUE)
                }
            }
        
        }
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>