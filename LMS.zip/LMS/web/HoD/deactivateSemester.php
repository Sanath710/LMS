<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");
        $query ="SELECT PID,PRGM_ID FROM Mtb_Programme";
        $data = mysqli_query($con,$query);
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['s'] == 1)
        {
            echo '
                <script> 
                    swal("Alert", "Error in Prepared Statement", "warning");
                </script>
            ';
        }
        else if($_GET['s'] == 2)
        {
            echo '
                <script> 
                    swal("Success", "Semester Locked down Successfully", "success");
                </script>
            ';
        }
        else if($_GET['s'] == 3)
        {
            echo '
                <script> 
                    swal("Alert", "Something went wrong. Please Contact this issue to Administrator.", "warning");
                </script>
            ';
        } 
?>
<html>
    <head>
        <title>LMS | Deactivate Semester</title>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "deactivateSemester.php");
            }
        </script>
        <script src="../COMMON_FILES/sweetalert.min.js"></script>
        <style>
            .PRGM_blocks {
                border: 1px solid white;
            }
            .PRGM_blocks:hover {
                border: 1px solid rgba(81, 203, 238, 1);
            }
            th, td {
                padding: 7px;
            }
            td {
                padding-right:180;
                padding-left:30;
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper" style="display:flex;">
                        <div class="card mainBody" style="min-height:54.7rem;padding:2%;padding-bottom:0%;margin-bottom:0%;width:31%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-10">
                                        <h4 style="font-weight:bold;">Semester Lockdown (Deactivate)</h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-10" style="display:flex;flex-wrap:wrap;">
                                        <div style="width:45%;margin-right:8%;margin-top:5%;">
                                            <h5 style="font-weight:bold;">Choose Year </h5>
                                            <hr style="margin-left:0%;width:45%;" />
                                            <select name="selYear" id="selYear" onChange="dispBatch(0)" style="background-color:#4099ff;color:white;width:90%;padding:2%;cursor:pointer;">
                                                <option value="x">Select</option>
                                                <?php
                                                    $yearQRY = "SELECT CRSE_USR_Year FROM Tb_CourseUsers GROUP BY CRSE_USR_Year ORDER BY CRSE_USR_Year DESC";
                                                    $yearData = mysqli_query($con, $yearQRY);
                                                    while($res = mysqli_fetch_assoc($yearData)) {
                                                        echo '<option style="background-color:white;color:black;" value="'.$res['CRSE_USR_Year'].'">'.$res['CRSE_USR_Year'].'</option>';
                                                    }
                                                ?>
                                            </select>
                                        </div>
                                        <div style="width:45%;margin-top:5%;">
                                            <h5 style="font-weight:550;">Select Program</h5>
                                            <hr style="width:50%;margin-left:0%;"/>
                                            <select name="selPRGM" id="selPRGM" onChange="dispBatch(0)" style="background-color:#4099ff;color:white;width:93%;padding:2%;cursor:pointer;">
                                                <option value="x">Select</option>
                                                <?php
                                                    $PRGMName_data = mysqli_query($con,$query);
                                                    while($prgms = mysqli_fetch_assoc($PRGMName_data))
                                                    {
                                                        echo '<option style="background-color:white;color:black;" value="'.$prgms['PRGM_ID'].'">'.$prgms['PRGM_ID'].'</option>';
                                                    }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <br/>
                                <div class="row" id='ajaxDispBatch' style="margin:0px 0.5%; 0px 0.5%;">
                                    <!-- AJAX Block -->
                                </div>
                            </div>
                        </div>
                        <div style="margin-left:1%;width:75%;background-color:white;border-radius:5px;
                                    box-shadow: 0 1px 2.94px 0.06px rgb(4 26 55 / 16%); border: none;">
                            <div class="mainBody m-l-5 m-r-5" style="padding:3%;padding-bottom:0%;margin-top:2.3%;">
                                <div class="card-block">
                                    <div class="row">
                                        <div class="col-sm-12 col-xl-12 m-b-10" id="tblBatchInfo">
                                            <h4 style="font-weight:bold;">Batch Information</h4>
                                            <hr style="margin-left:0%;" />
                                            <table>
                                                <thead>
                                                    <tr>
                                                        <th>Batch Name </th>
                                                        <td id="batchName"></td>
                                                        <th>Total Users </th>
                                                        <td id="total_Users"></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Batch Year </th>
                                                        <td id="batchYear"></td>
                                                        <th>Total Students </th>
                                                        <td id="total_Students"></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Semester </th>
                                                        <td id="batchSem"></td>
                                                        <th>Total Teachers </th>
                                                        <td id="total_Teachers"></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Last Locked </th>
                                                        <td><?php echo '<span id="semLocked"></span>'; ?></td>
                                                    </tr>
                                                </thead>
                                            </table>
                                            <div class="row m-t-5" id="selOpt">
                                                <div class="col-sm-12 col-xl-12 m-b-10 m-t-15">
                                                    <h5 style="font-weight:bold;">Choose one</h5>
                                                    <hr style="margin-left:0%;" />
                                                    <span id ="customLock">
                                                        <label class="border-checkbox-label" for="checkbox0" style="font-weight:550;">Would you like to custom lock ?</label> 
                                                        <i class="fa fa-info-circle f-18 m-l-5" style="cursor:pointer;" data-toggle="tooltip" data-placement="right" title="You can unenroll non-eligible students from list."></i>
                                                        <script>
                                                            $(function () {
                                                                $('[data-toggle="tooltip"]').tooltip()
                                                            })
                                                        </script>
                                                        <br/>
                                                        <label style="cursor:pointer;font-weight:550;margin-top:0.1%;">
                                                            <input type="radio" onChange="dispList()" id="rdBtn_Yes" style="cursor:pointer;" name="radio" value="Yes">
                                                            <i class="helper"></i>Yes
                                                        </label>
                                                        <label style="cursor:pointer;margin-left:1%;font-weight:550;">
                                                            <input type="radio" onChange="hideList()" name="radio" id="rdBtn_No" style="cursor:pointer;" value="No" checked="checked">
                                                            <i class="helper"></i>No
                                                        </label>
                                                    </span>
                                                    <form action="" method="POST" id="formLock">
                                                        <button class="btn btn-danger btn-round waves-effect waves-light" 
                                                                style="margin-left:-0.5%;margin-top:0.5%;" name="btnUnlock">
                                                            <i class="fa fa-unlock"></i>&nbsp;Unlock
                                                        </button>
                                                        <input type="hidden" id="ID_pid" name="pid" /> <br/>
                                                        <input type="hidden" id="ID_year" name="year" /> <br/>
                                                        <input type="hidden" id="ID_sem" name="sem" /> <br/>
                                                    </form>
                                                    <form action="lockSem.php" method="POST" id="formUnlock">
                                                        <button class="btn btn-success btn-round waves-effect waves-light" 
                                                                style="margin-left:-0.5%;margin-top:0.5%;" name="btnLock">
                                                            <i class="fa fa-lock"></i>&nbsp;Lock
                                                        </button>
                                                        <input type="hidden" id="ID_UL_pid" name="L_pid" /> <br/>
                                                        <input type="hidden" id="ID_UL_year" name="L_year" /> <br/>
                                                        <input type="hidden" id="ID_UL_sem" name="L_sem" /> <br/>
                                                        <?php
                                                            if(isset($_POST['btnUnlock'])) {
                                                                $pid = $_POST['pid'];
                                                                $year = $_POST['year'];
                                                                $sem = $_POST['sem'];
                                                                $getPID = "SELECT PID FROM Mtb_Programme WHERE PRGM_ID='$pid'";
                                                                $getPID_Data = mysqli_query($con,$getPID);
                                                                $PID = mysqli_fetch_assoc($getPID_Data);
                                                                $PID = $PID["PID"];
                                                                $ul_Update_Qry = "DELETE FROM Tb_CourseUsers
                                                                                   WHERE CRSE_USR_PID = $PID AND CRSE_USR_Sem = ($sem+1)
                                                                                   AND CRSE_USR_Year = '$year'";
                                                                if(mysqli_query($con,$ul_Update_Qry)) {
                                                                    $update_SemLock = "DELETE FROM Tb_SemesterLockdown
                                                                                       WHERE SemLock_PRGMID = '$pid' AND SemLock_Batch = '$year' AND SemLock_Semester = $sem";
                                                                    if(mysqli_query($con,$update_SemLock)) {
                                                                        echo '<script>swal("Success","Semester Unlocked Successfully.","success");</script>';
                                                                    } else {
                                                                        echo '<script>swal("Alert","Transaction Update Failed. Something went wrong.","warning");</script>';
                                                                    }
                                                                } else {
                                                                    echo '<script>swal("Alert","Either No User/s Selected OR User/s had already Enrolled into that semester.","warning");</script>';
                                                                }
                                                            }
                                                        ?>

                                                        <div id="studList" style="margin-top:-2.7%;">
                                                            <!-- AJAX Stud List -->
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            document.getElementById("tblBatchInfo").style.display="none";
            document.getElementById("selOpt").style.display="none";

            document.getElementById("formLock").style.display="none";
            document.getElementById("formUnlock").style.display="none";

            function dispStatus(semester) {
                document.getElementById("batchName").innerHTML=document.getElementById("selPRGM").value;
                document.getElementById("batchYear").innerHTML=document.getElementById("selYear").value;
                document.getElementById("batchSem").innerHTML=semester;

                document.getElementById("rdBtn_No").click();
                document.getElementById("studList").style.display="none";

                try {
                    document.getElementById("total_Users").innerHTML=document.getElementById("totalUsers").innerHTML;
                    document.getElementById("total_Teachers").innerHTML=document.getElementById("totalTeachers").innerHTML;
                    document.getElementById("total_Students").innerHTML=document.getElementById("totalStudents").innerHTML;
                    document.getElementById("semLocked").innerHTML=document.getElementById("lastLocked").innerHTML;
                } catch(e) {
                    // Do Nothing.
                }

                document.getElementById("tblBatchInfo").style.display="";
                document.getElementById("selOpt").style.display="";
            }

            function dispBatch(semester) {

                let pid = document.getElementById("selPRGM").value;
                let year = document.getElementById("selYear").value;
                
                if(year == "x" || pid == "x") {
                    document.getElementById("ajaxDispBatch").style.display="none";
                } else {

                    let xhr;
                    (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");

                    let data = "pid="+pid+"&year="+year+"&sem="+semester;
                    xhr.open("POST","AJAX_DeactiveSem_PRGM.php",true);
                    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                    xhr.send(data);
                    xhr.onreadystatechange = display; 

                    function display()
                    {
                        if(xhr.readyState == 4)
                        {
                            if(xhr.status == 200)
                            {
                                document.getElementById("ajaxDispBatch").style.display="";
                                document.getElementById("ajaxDispBatch").innerHTML = xhr.responseText;

                                document.getElementById("ID_pid").value=document.getElementById("selPRGM").value;
                                document.getElementById("ID_year").value=document.getElementById("selYear").value;
                                document.getElementById("ID_UL_pid").value=document.getElementById("selPRGM").value;
                                document.getElementById("ID_UL_year").value=document.getElementById("selYear").value;
                                document.getElementById("ID_UL_sem").value=semester;
                                document.getElementById("ID_sem").value=semester;

                                if(semester != 0) {
                                    document.getElementById("formUnlock").style.display="";
                                    document.getElementById("customLock").style.display="";
                                    document.getElementById("formLock").style.display="none";
                                } else {
                                    document.getElementById("formUnlock").style.display="none";
                                    document.getElementById("formLock").style.display="none";
                                }

                                try {
                                    if(document.getElementById("lastLocked").innerHTML != "") {
                                        document.getElementById("customLock").style.display="none";
                                        document.getElementById("formLock").style.display="";
                                        document.getElementById("formUnlock").style.display="none";
                                    }
                                } catch (e) {
                                    // Do Nothing.
                                }
                            }
                            else
                            {
                                alert("There was a problem with the request");
                            }
                            dispStatus(semester);
                        }
                    }
                }
                
            }

            // For implementing select all student's record at once functionality using checkbox.
            function all_CHK()
            {
                let chks = document.getElementsByClassName('chk_Stud');
                let main_CHK = document.getElementById('CHK_all');
                if(main_CHK.checked == true)
                {
                    for(i = 0; i < chks.length; i++)
                    {
                        chks[i].checked=true;
                    }
                }
                else
                {
                    for(i = 0; i < chks.length; i++)
                    {
                        chks[i].checked=false;
                    }
                }
            }

            function hideList() {
                document.getElementById("studList").style.display="none";
            }

            function dispList() {

                let pid = document.getElementById("selPRGM").value;
                let year = document.getElementById("selYear").value;
                let sem =  document.getElementById("batchSem").innerHTML;

                if(year == "x" || pid == "x" || sem == 0) {
                    document.getElementById("studList").style.display="none";
                } else {

                    let xhr;
                    (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");

                    let data = "pid="+pid+"&year="+year+"&sem="+sem;
                    xhr.open("POST","AJAX_deactivateSem_StudList.php",true);
                    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                    xhr.send(data);
                    xhr.onreadystatechange = display; 

                    function display()
                    {
                        if(xhr.readyState == 4)
                        {
                            if(xhr.status == 200)
                            {
                                // document.getElementById("Yes").click();
                                document.getElementById("studList").style.display="";
                                document.getElementById("studList").innerHTML = xhr.responseText;
                            }
                            else
                            {
                                alert("There was a problem with the request");
                            }
                        }
                    }
                }
                
            }
        </script>
        <noscript>Your browser doesnot support JavaScript!</noscript>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>