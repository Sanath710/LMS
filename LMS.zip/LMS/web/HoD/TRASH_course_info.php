<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");
        $cid = base64_decode($_GET['id']);
        include_once("../COMMON_FILES/course_info_method.php");
        $req_SQL = "SELECT PRGM_ID,CRSE_USR_Year,CRSE_USR_Sem FROM Tb_CourseUsers,Mtb_Programme,Mtb_Users WHERE PID = CRSE_USR_PID AND USR_ID = '".$_SESSION['Sess_USR_ID']."'
                    AND UID = CRSE_USR_UID AND CRSE_USR_Status = 1 AND CRSE_USR_CourseID = $cid";
        $req_Data = mysqli_query($con,$req_SQL);
        $req_Result = mysqli_fetch_assoc($req_Data);
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['s']==1)
        {
            echo 
            '<script> 
              swal("Success", "Assessment Uploaded Successfully.", "success");
            </script>
            ';
        }
        else if($_GET['s']==2)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While uploading File into Database.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==3)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While inserting values in description relation.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==4)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While inserting values of assessments availability & visibility in database.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==5)
        {
            echo 
            '<script> 
              swal("Info", "Assessment Upload Failed.\nSome Error Occured While inserting values in database.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==6)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While moving file to destination folder.!\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==7)
        {
            echo 
            '<script> 
              swal("Info", "File Size must be lesser than 5 MB.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==8)
        {
            echo 
            '<script> 
              swal("Info", "File Size must be greater than 20 KB.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==9)
        {
            echo 
            '<script> 
              swal("Info", "Invalid file format.\nAccepted formats are PDF & DOCX.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==10)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While Uploading File", "warning");
            </script>
            ';
        }
        else if($_GET['s']==11)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured. Assessment Upload Failed.", "warning");
            </script>
            ';
        }
?>
<html>
    <head>
        <title>Dashboard</title>
        <style>
            table tr,table,td {border:none!important;}
            col-auto
            {
                font-size:18.5px;
            }
        </style>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "course_info.php?id=<?php echo base64_encode($cid);?>");
            }
        </script>
        <link rel="stylesheet" type="text/css" href="../css/boxicons.min.css">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4><?php echo $cid." : ".$result['CRSE_Name'];?></h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                    <!-- Menu Hyperlink starts -->
                                    <div style="width:100%!important;margin-left:1%;">
                                        <div class="tab-content tabs-right-content card-block" style="width:100%;">
                                            <div class="tab-pane active show" id="menu1" role="tabpanel">

                                                <!-- Dashboard Starts -->
                                                <div style="display:flex;flex-wrap:wrap;margin-left:-3%;">
                                                    <div class="col-xl-4 col-md-12">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25">Total Students</h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $stud_CNT; ?></h3>
                                                                        <p class="m-b-0">Enrolled in Course</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fas fa-users bg-c-green"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25">Total Assignments</h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $assign_CNT['total']; ?></h3>
                                                                        <p class="m-b-0">assigned by you to students</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-pdf-o bg-c-blue"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25">Total Materials</h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $material_CNT['total']; ?></h3>
                                                                        <p class="m-b-0">Materials uploaded</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-archive-o bg-c-yellow"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25">Total Homework</h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $homewrk_CNT['total']; ?></h3>
                                                                        <p class="m-b-0">assigned</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-text-o bg-c-blue"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25">Total Journals</h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $journal_CNT['total']; ?></h3>
                                                                        <p class="m-b-0">allocated to students</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-code bg-c-blue"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25">Total Other Files</h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $other_CNT['total']; ?></h3>
                                                                        <p class="m-b-0">uploaded</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-word-o bg-c-red"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Dashboard Ends -->
                                            </div>
                                            <div class="tab-pane" id="menu2" role="tabpanel">
                                                <!-- Assessment Form -->
                                                <div>
                                                    <!-- Form Starts -->
                                                    <form method="POST" action="course_info_DB.php" enctype="Multipart/form-data">

                                                        <input type="hidden" name ="cid" value="<?php echo $cid; ?>"/>
                                                        <input type="hidden" name ="pid" value="<?php echo $req_Result['PRGM_ID']; ?>"/>
                                                        <input type="hidden" name ="year" value="<?php echo $req_Result['CRSE_USR_Year'];; ?>"/>
                                                        <input type="hidden" name ="sem" value="<?php echo $req_Result['CRSE_USR_Sem']; ?>"/>

                                                    <table id="base-style" style="width:89%;margin-left:-2%;font-size:18px;margin-top:-3.5%;margin-bottom:-4%;" class="table table-striped table-bordered nowrap tableViewProgram">
                                                        <thead>
                                                            <tr>
                                                                <td colspan="2" style="font-weight:bold;">New Assessment</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Assessment Name : </td>
                                                                <td><input type="text" name="a_Name" style="margin-top:-0.5%;font-size:20px; border: 1px solid rgba(113,113,113);width:50%;" autocomplete="off" required/></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Assessment Type : </td>
                                                                <td>
                                                                    Assignment <input type="radio" name="ASType" value="Assignment" required /> &nbsp;&nbsp;&nbsp;
                                                                    HomeWork <input type="radio" name="ASType" value="Homework"/> &nbsp;&nbsp;&nbsp;
                                                                    Journal <input type="radio" name="ASType" value="Journal"/> &nbsp;&nbsp;&nbsp;
                                                                    Material <input type="radio" name="ASType" value="Material"/> &nbsp;&nbsp;&nbsp;
                                                                    Other <input type="radio" name="ASType" value="Other" />
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>Available From : </td>
                                                                <td><input type="date" name="A_Date" style="width:24%;" required/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="time" name="A_Time" style="width:24%;" required/></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Due Event : </td>
                                                                <td><input type="date" name="D_Date" style="width:24%;" required/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="time" name="D_Time"  style="width:24%;" required/></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Description/Instructions : </td>
                                                                <td>
                                                                    <textarea  style="width:70.5%;height:8.5rem;" name="A_Desc" required></textarea>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>Upload File : </td>
                                                                <td><input type="file" name="A_Upload"/></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Total Points : </td>
                                                                <td>
                                                                    <input type="number" name="A_Points" min="0" style="width:14%;" pattern="[0-9]{0,}"/>
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                                    Internal Weightage : &nbsp;&nbsp;<input type="number" placeholder="Points" name="Weightage_Points" min="0" style="width:14%;" pattern="[0-9]{0,}"/>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>Visibility on Student Panel : </td>
                                                                <td>
                                                                    Visible <input type="radio" name="Show_Hide" value="1" checked/>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                    Hidden <input type="radio" name="Show_Hide" value="0" />
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="height:2rem;" colspan="2">
                                                                    <input type="submit" class="PGSubmit" id="submit" style="width:max-content;font-size:15px;height:2.5rem;padding-top:0.38%;
                                                                            padding-left:1.3%;padding-right:1.3%;" name="btnSubmit" value="Submit" />
                                                                    <input type="reset" class="PGSubmit" id="reset" style="width:max-content;margin-left:-4%;font-size:16px;height:2.5rem;
                                                                            padding-top:0.38%;padding-left:1.55%;padding-right:1.55%;margin-bottom:0.5%;" value="Reset" />
                                                                </td>
                                                            </tr>
                                                        </thead>
                                                    </table>
                                                    </form>
                                                    <!-- Form Ends -->
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="students" role="tabpanel" style="background-lightgreen!important;margin-top:-3%;margin-left:-2%;width:105%;">
                                                <div class="dt-responsive table-responsive tableView">
                                                    <h5 style="margin-top:-1%;margin-bottom:2%;margin-left:-2%;font-weight:bold;">Enrolled Students :</h5>
                                                    <table id="base-style" style="width:100%;margin-left:-2%;" class="table table-striped table-bordered nowrap tableViewProgram">
                                                        <thead>
                                                            <tr>
                                                            <th style="width:10%;border-left:none;">Sr No</th>
                                                            <th style="width:17%;">Student ID</th>
                                                            <th style="width:23%;">Student Name</th>
                                                            <th style="width:20%;">Contact No.</th>
                                                            <th style="width:25%;border-right:none;">Email ID</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php
                                                            $cnt=1;
                                                            $flag = false;
                                                            while ($res = mysqli_fetch_assoc($stud_Data)) 
                                                            {
                                                                $flag = true;
                                                        ?>  
                                                                <tr class="RowHeight" style="border:none;">
                                                                    <td ><?php echo $cnt; ?></td>
                                                                    <td ><?php echo $res['USR_ID'];?></td>
                                                                    <td ><?php echo $res['USR_FirstName']." ".$res['USR_LastName'];?></td>
                                                                    <td><?php echo $res['USR_ContactNo'];?></td>
                                                                    <td><?php echo $res['USR_EmailID'];?></td>
                                                                </tr>
                                                            <?php
                                                                $cnt++;
                                                                }
                                                                if(!$flag)
                                                                {
                                                                    echo "<tr><td colspan='5'>No students are being enrolled in this course</td></tr>";
                                                                }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="menu4" role="tabpanel">
                                                <p>
                                                    Work in Progress &nbsp; :)
                                                </p>
                                            </div>
                                        </div>
                                        <!-- Tab Menu -->
                                        <ul class="nav nav-tabs md-tabs tabs-right b-none" role="tablist" 
                                            style="font-weight:bold;border-left: 1px solid grey;overflow:hidden;">
                                            <li class="nav-item">
                                            <a class="nav-link active show" data-toggle="tab" href="#menu1" role="tab" aria-selected="true">Dashboard</a>
                                            <div class="slide"></div>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#menu2" role="tab" aria-selected="false">Assessment</a>
                                                <div class="slide"></div>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#students" role="tab" aria-selected="false">Students</a>
                                                <div class="slide"></div>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#menu4" role="tab" aria-selected="false">Material</a>
                                                <div class="slide"></div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>