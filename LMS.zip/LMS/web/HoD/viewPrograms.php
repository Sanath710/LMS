<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {   
    include_once("teacherNavbar.php");
    include("../COMMON_FILES/Connection.php");
    $query ="SELECT * FROM Mtb_Programme";
    $data = mysqli_query($con,$query);

?>
<html lang="en">

  <head>
    <link rel="stylesheet" type="text/css" href="../css/datatables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <!-- <style>table,td,table {border:none!important;}</style> -->
    <style>
      table tr,table,td {border:none!important;}
    </style>
  </head>

  <body>
    <div class="pcoded-content">
      <!-- <div class="page-header card">
      <div class="row align-items-end">
        <div class="col-lg-8">
          <div class="page-header-title">
            <i class="fa fa-book bg-c-blue" aria-hidden="true"></i>
            <div style="padding-top:1%;">
              <h5>View Programs</h5>
              <span></span>
            </div>
          </div>
        </div>
          <div class="col-lg-4">
            <div class="page-header-breadcrumb">
              <ul class=" breadcrumb breadcrumb-title">
                <li class="breadcrumb-item">
                  <a href=""><i class="feather icon-home"></i></a>
                </li>
                <li class="breadcrumb-item"><a href="#!">View Programs</a> </li>
              </ul>
            </div>
          </div>
      </div>
    </div> -->
    <!-- Main Body Starts -->
    <div>
    <div class="main-body">
      <div class="page-wrapper subBodyProgram">
        <div class="page-body">
          <div class="card bodyStyling" style="min-height:54.7rem;">
            <div class="card-header" style="margin-top:0.5%;">
              <h4 style="font-weight:bold;">Programme Details</h4><hr style="width:97.8%; margin-left:0%;"/>
            </div>
            <div class="card-block">
              <div class="dt-responsive table-responsive tableView">
                <br/>
                <table id="base-style" style="width:100%;" class="table table-striped table-bordered nowrap tableViewProgram">
                  <thead>
                    <tr>
                      <th style="width:7%;">Sr No</th>
                      <th style="width:15%;">Programme ID</th>
                      <th style="width:50%;">Programme Name</th>
                      <th style="width:10%;text-align:center;">Programme Status</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                    $cnt=1;
                    while ($result = mysqli_fetch_assoc($data)) 
                    {
                  ?>  
                        <tr class="RowHeight" onclick="edit(this)">
                            <td ><?php echo $cnt; ?></td>
                            <td class="height_td"><?php echo $result['PRGM_ID'];?></td>
                            <td style="text-align:left;" ><?php echo $result['PRGM_Name'];?></td>
                            <td style="text-align:center;"> 
                                <?php
                                  if($result['PRGM_Status'] == "1") 
                                  {
                                    echo "<label class='label label-md bg-success' style='font-size:15px;padding-left:11.5%;padding-right:12.5%;'>Active</label>";
                                  }
                                  else if($result['PRGM_Status'] == "0")
                                  {
                                    echo "<label class='label label-md bg-danger' style='font-size:15px;'>Deactive</label>";
                                  }
                                ?>
                            </td>
                        </tr>
                       <?php
                        $cnt++;
                        }
                      ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <script src="../js/jquery.datatables.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.buttons.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.bootstrap4.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.responsive.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/data-table-custom.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="06ff493bca0b4366a261bcf1-|49" defer=""></script>
  </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>