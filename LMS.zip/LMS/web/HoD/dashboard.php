<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");

        $sql = "SELECT CRSE_ID, CRSE_Name FROM Mtb_Courses,Tb_CourseUsers,Mtb_Users WHERE CRSE_USR_CourseID = CRSE_ID 
                AND UID = CRSE_USR_UID AND USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_USR_Status = 1";
        $data = mysqli_query($con,$sql);

        $year = date("Y");
        $uid = $_SESSION['Sess_USR_ID'];
?>
<html>
    <head>
        <title>Dashboard</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "Dashboard.php");
            }
        </script>
        <style>
            ::-webkit-scrollbar {
                width:0px;  /* Remove scrollbar space */
                background: rgb(4 26 55 / 16%);  /* Make scrollbar invisible */
            }
            .show-semester:hover {
                text-decoration : underline;
            }
        </style>
        <!-- Radial chart -->
        <link rel="stylesheet" href="../css/radial.css" type="text/css" media="all">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper" style="display:flex;min-height:56.1rem;">
                        <div class="card mainBody" style="width:75%;padding:2%;padding-bottom:0%;margin-bottom:0.5%;">
                            <div class="card-block">
                                <div class="row" style="display:block;">
                                    <div class="col-sm-12 col-xl-12 m-b-25">
                                        <h4 style="font-weight:bold;">Dashboard<span style="font-weight:bold;margin-left:69%;">Welcome : </span> <?php echo $_SESSION['Sess_USR_ID'];?></h4>
                                        <hr style="margin-left:0%;margin-top:2%;margin-bottom:0%;" />
                                    </div>
                                    <!-- Card blocks -->
                                    <h4 style="font-weight:bold;margin-left:2%;">My Courses : &nbsp;<i class="fa fa-cube"></i></h4>
                                    <div style="margin-top:0%;display:flex;flex-wrap:wrap;margin-left:2%;margin-right:-2%;margin-top:1.5%;margin-bottom:-1.5%;">
                                        <?php
                                            $cnt = 0;
                                            # For getting all images from folder named "Course_Pic" automatically for courses
                                            $auto_Imgs = glob("../Course_Pic/*.*");
                                            while($r = mysqli_fetch_assoc($data))
                                            {
                                                # Getting individual images
                                                // $image = $auto_Imgs[array_rand($auto_Imgs)]; # For auto image
                                                $image = $auto_Imgs[$cnt];
                                                # Valid image formats
                                                $valid_Formats = array('gif','jpg','jpeg','png');
                                                # For getting choosed image format
                                                $image_ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));

                                                $cid = base64_encode($r['CRSE_ID']);
                                                echo'
                                                <a href="../HoD/course_info.php?id='.$cid.'" style="width:30.3%;margin-top:0.5%;" class="ahref_CRSE">
                                                    <div class="course-cards" style="width:100%;">
                                                '; 
                                                        # If image is valid then showing them
                                                        if (in_array($image_ext, $valid_Formats))
                                                        {
                                                            echo '<img style="height:62%;width:100%;" src="../Course_Pic/'.$image .'" alt="Course Image" />';
                                                        }
                                                echo '
                                                        <br/><br/>
                                                        <h4 class="CRSE_id" style="text-align:center;font-weight:550;">'.$r['CRSE_ID'].'</h4>
                                                        <h5 class="CRSE_Name">
                                                            <span class="CRSE_Label">Course : </span>'.$r['CRSE_Name'].'</h5>
                                                    </div>
                                                </a>';
                                                $cnt ++ ;
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Side Cards Starts -->
                        <div class="card mainBody m-t-4" style="box-shadow:none;width:24.5%;margin-left:0.8%;background:transparent;margin-bottom:0%;">
                        <!-- Side Top Card -->
                            <div style="background-color:white;width:109%;margin-top:-6.6%;border-radius:5px;height:auto;min-height:18rem;margin-bottom:0%;
                                    box-shadow: 0 1px 2.94px 0.06px rgb(4 26 55 / 16%); border: none;padding:2%;" >
                                <h4 style="font-weight:bold;text-align:center;margin-top:12.5%;margin-bottom:7%;"><i class="fa fa-star-half-empty"></i> &nbsp;Internal Evaluations</h4>
                                <hr style="margin-left:5%;margin-right:5%;margin-top:2%;margin-bottom:5%;" />
                                <div style="margin-left:2%;font-size:18px;padding:2%;margin-right:1%;margin-bottom:-1%;">
                                    <?php
                                        $prgm_qry  = "SELECT PID, PRGM_ID, PRGM_Name FROM Mtb_Programme WHERE PRGM_Status = 1";
                                        $prgm_data = mysqli_query($con,$prgm_qry);
                                        $cnt = 0;
                                        while($res_prgm = mysqli_fetch_assoc($prgm_data)) {
                                            $course_qry = "SELECT count(PRGM_CRSE_CourseID) as crse FROM Tb_ProgrammeCourseTypes WHERE PRGM_CRSE_PID = ".$res_prgm['PID']." AND PRGM_CRSE_AcademicYear='$year'";
                                            $course_data = mysqli_query($con,$course_qry);
                                            $course = mysqli_fetch_assoc($course_data);
                                            $course = $course['crse'];
                                            if($cnt % 2 == 0) {
                                                echo
                                                '
                                                <div class="card proj-t-card">
                                                    <div class="card-body">
                                                        <div class="row align-items-center m-b-25">
                                                            <div class="col-auto">
                                                                <i class="fas fa-lightbulb text-c-blue f-30"></i>
                                                            </div>
                                                            <div class="col p-l-0">
                                                                <h6 class="m-b-5" style="color:black;font-weight:510;word-wrap:break-word;">
                                                                    '.$res_prgm['PRGM_Name'].'
                                                                </h6>
                                                                <h6 class="m-b-0 text-c-blue show-semester m-t-10" data-toggle="collapse" data-target="#'.$res_prgm['PRGM_ID'].'" 
                                                                aria-expanded="false" aria-controls="collapseExample" style="cursor:pointer;color:blue;">
                                                                View Semesters
                                                                </h6>
                                                            </div>
                                                        </div>
                                                        <div class="row align-items-center text-center">
                                                            <div class="col m-b-10">
                                                                <h6 class="m-b-0" style="font-weight:510;">Courses</h6>
                                                            </div>
                                                            <div class="col">
                                                                <i class="fas fa-arrow-right text-c-blue f-18"></i>
                                                            </div>
                                                            <div class="col">
                                                                <h6 class="m-b-0" style="font-weight:510;">'.$course.'</h6>
                                                            </div>
                                                        </div>

                                                        <div class="collapse m-t-15" id="'.$res_prgm['PRGM_ID'].'">
                                                            <div class="">
                                                ';
                                                $sem_qry = "SELECT PRGM_CRSE_Sem  FROM Tb_ProgrammeCourseTypes WHERE PRGM_CRSE_PID = ".$res_prgm['PID']." AND PRGM_CRSE_AcademicYear='$year' GROUP BY PRGM_CRSE_Sem"; 
                                                $sem_data = mysqli_query($con,$sem_qry);
                                                while($sem_res = mysqli_fetch_assoc($sem_data))
                                                {
                                                    echo 
                                                    '
                                                    <div class="card proj-t-card">
                                                        <div class="card-body">
                                                            <div class="row align-items-center m-b-5">
                                                                <div class="col p-l-0 m-l-15">
                                                                    <h6 class="m-b-5" style="color:black;font-weight:510;">
                                                                        <i class="fa fa-caret-square-o-right"></i> &nbsp;
                                                                        Semester  : 
                                                                        '.$sem_res['PRGM_CRSE_Sem'].'
                                                                    </h6>
                                                                    <h6 class="m-b-0 text-c-blue show-semester m-t-10" data-toggle="collapse" data-target="#'.$res_prgm['PID'].$sem_res['PRGM_CRSE_Sem'].'" 
                                                                        aria-expanded="false" aria-controls="collapseExample" style="cursor:pointer;color:blue;">
                                                                    View Courses
                                                                    </h6>
                                                                </div>
                                                            </div>
                                                            <div class="collapse m-t-15" id="'.$res_prgm['PID'].$sem_res['PRGM_CRSE_Sem'].'">
                                                                <div class="">
                                                    ';
                                                    $crses_qry = "SELECT PRGM_CRSE_CourseID FROM Tb_ProgrammeCourseTypes 
                                                                  WHERE PRGM_CRSE_PID = ".$res_prgm['PID']." AND PRGM_CRSE_AcademicYear='$year' AND PRGM_CRSE_Sem = ".$sem_res['PRGM_CRSE_Sem'].""; 
                                                    $crse_data = mysqli_query($con,$crses_qry);
                                                    while($crese_res = mysqli_fetch_assoc($crse_data))
                                                    {
                                                        $internal_QRY = "SELECT sum(CRSE_DOC_TCHR_Weightage) as total FROM mtb_coursedocs_new,tb_coursedoctchr 
                                                                        WHERE CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_DOC_Year = '$year' AND CRSE_DOC_CourseID = ".$crese_res['PRGM_CRSE_CourseID']."";
                                                        $internal_Data = mysqli_query($con,$internal_QRY);
                                                        $internal = mysqli_fetch_assoc($internal_Data);
                                                        echo "<span style='font-weight:505;font-size:16px;'>".$crese_res['PRGM_CRSE_CourseID'].'</span>&nbsp;&nbsp;&nbsp;<progress style="margin-top:0.5%;width:41%;" value="'.$internal['total'].'" max="40"></progress>&nbsp;<span class="m-l-10" style="font-weight:505">'.round((($internal['total']*100)/40),2).'%</span><br/>';
                                                    }
                                                    echo '
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    ';
                                                }
                                                echo '
                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                ';
                                            } 
                                            else {
                                                echo
                                                '
                                                <div class="card proj-t-card">
                                                    <div class="card-body">
                                                        <div class="row align-items-center m-b-25">
                                                            <div class="col-auto">
                                                                <i class="fas fa-lightbulb text-c-red f-30"></i>
                                                            </div>
                                                            <div class="col p-l-0">
                                                                <h6 class="m-b-5" style="color:black;font-weight:510;word-wrap:break-word;">
                                                                    '.$res_prgm['PRGM_Name'].'
                                                                </h6>
                                                                <h6 class="m-b-0 text-c-red show-semester m-t-10" data-toggle="collapse" data-target="#'.$res_prgm['PRGM_ID'].'" 
                                                                aria-expanded="false" aria-controls="collapseExample" style="cursor:pointer;color: #ff5370;">
                                                                View Semesters
                                                                </h6>
                                                            </div>
                                                        </div>
                                                        <div class="row align-items-center text-center">
                                                            <div class="col m-b-10">
                                                                <h6 class="m-b-0" style="font-weight:510;">Courses</h6>
                                                            </div>
                                                            <div class="col">
                                                                <i class="fas fa-arrow-right text-c-red f-18"></i>
                                                            </div>
                                                            <div class="col">
                                                                <h6 class="m-b-0" style="font-weight:510;">'.$course.'</h6>
                                                            </div>
                                                        </div>

                                                        <div class="collapse m-t-15" id="'.$res_prgm['PRGM_ID'].'">
                                                            <div class="">
                                                ';
                                                $sem_qry = "SELECT PRGM_CRSE_Sem  FROM Tb_ProgrammeCourseTypes WHERE PRGM_CRSE_PID = ".$res_prgm['PID']." AND PRGM_CRSE_AcademicYear='$year' GROUP BY PRGM_CRSE_Sem"; 
                                                $sem_data = mysqli_query($con,$sem_qry);
                                                while($sem_res = mysqli_fetch_assoc($sem_data))
                                                {
                                                    echo 
                                                    '
                                                    <div class="card proj-t-card">
                                                        <div class="card-body">
                                                            <div class="row align-items-center m-b-5">
                                                                <div class="col p-l-0 m-l-15">
                                                                    <h6 class="m-b-5" style="color:black;font-weight:510;">
                                                                        <i class="fa fa-caret-square-o-right"></i> &nbsp;
                                                                        Semester  : 
                                                                        '.$sem_res['PRGM_CRSE_Sem'].'
                                                                    </h6>
                                                                    <h6 class="m-b-0 text-c-blue show-semester m-t-10" data-toggle="collapse" data-target="#'.$res_prgm['PID'].$sem_res['PRGM_CRSE_Sem'].'" 
                                                                        aria-expanded="false" aria-controls="collapseExample" style="cursor:pointer;color: #ff5370;;">
                                                                    View Courses
                                                                    </h6>
                                                                </div>
                                                            </div>
                                                            <div class="collapse m-t-15" id="'.$res_prgm['PID'].$sem_res['PRGM_CRSE_Sem'].'">
                                                                <div class="">
                                                                
                                                    ';
                                                     $crses_qry = "SELECT PRGM_CRSE_CourseID FROM Tb_ProgrammeCourseTypes 
                                                                  WHERE PRGM_CRSE_PID = ".$res_prgm['PID']." AND PRGM_CRSE_AcademicYear='$year' AND PRGM_CRSE_Sem = ".$sem_res['PRGM_CRSE_Sem'].""; 
                                                    $crse_data = mysqli_query($con,$crses_qry);
                                                    while($crese_res = mysqli_fetch_assoc($crse_data))
                                                    {
                                                        $internal_QRY = "SELECT sum(CRSE_DOC_TCHR_Weightage) as total FROM mtb_coursedocs_new,tb_coursedoctchr 
                                                                        WHERE CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_DOC_Year = '$year' AND CRSE_DOC_CourseID = ".$crese_res['PRGM_CRSE_CourseID']."";
                                                        $internal_Data = mysqli_query($con,$internal_QRY);
                                                        $internal = mysqli_fetch_assoc($internal_Data);
                                                        echo "<span style='font-weight:505;font-size:16px;'>".$crese_res['PRGM_CRSE_CourseID'].'</span>&nbsp;&nbsp;&nbsp;<progress style="margin-top:0.5%;width:41%;" value="'.$internal['total'].'" max="40"></progress>&nbsp;<span class="m-l-10" style="font-weight:505">'.round((($internal['total']*100)/40),2).'%</span><br/>';
                                                    }
                                                    echo '
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    ';
                                                }
                                                echo '
                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                ';
                                            }
                                           $cnt ++;
                                        }
                                    ?>
                                    <!-- </div> -->
                                </div>
                            </div>
                        <!-- Side Card bottom Starts-->
                            <div style="background-color:white;width:109%;margin-top:3.6%;border-radius:5px;margin-bottom:2.3%;min-height:23.1rem;
                                box-shadow: 0 1px 2.94px 0.06px rgb(4 26 55 / 16%); border: none;" >
                                <h4 style="font-weight:bold;text-align:center;margin-top:10.5%;margin-bottom:5%;">
                                    <i class="fa fa-users"></i>&nbsp; Scheduled Meetings 
                                </h4>
                                <hr style="margin-left:5%;margin-right:5%;margin-top:2%;margin-bottom:2%;" />
                                <div class="latest-update-card">
                                    <div class="card-header">
                                        <div class="card-block">
                                            <div class="slimScrollDiv" style="position: relative; overflow: scroll; width: 105%; height: 12.95rem;">
                                            <?php
                                                                // echo "*************************";
                                                                    $cnt = 0; #colored circle purpose
                                                                    $getSched_Qry = "SELECT PRGM_ID, CRSE_SCHED_CourseID,  CRSE_SCHED_Division, substring(CRSE_SCHED_CourseID, 5, 2) as semester, 
                                                                                            CRSE_SCHED_StartTime, CRSE_SCHED_EndTime, CRSE_SCHED_LectureLink
                                                                                     FROM mtb_courseschedule, mtb_programme WHERE mtb_programme.PID = CRSE_SCHED_PID 
                                                                                     AND time(now()) <= time(CRSE_SCHED_EndTime) AND DAYNAME(now()) = CRSE_SCHED_Day 
                                                                                     ORDER BY (CRSE_SCHED_StartTime)";
                                                                    $getSchedData = mysqli_query($con, $getSched_Qry);
                                                                    while($schedule = mysqli_fetch_array($getSchedData))
                                                                    {
                                                                        if($cnt%2 == 0)
                                                                        {
                                                                            echo '
                                                                            <div class="row p-b-30">
                                                                                <div class="col-auto text-right update-meta p-r-0">
                                                                                    <i class="b-danger update-icon ring"></i>
                                                                                </div>
                                                                                <div class="col p-l-10">
                                                                                    <a href="../Video_Conferencing/TeachersVC.php?div='.$schedule[2].'&day=Tuesday&course='.$schedule[1].'&start='.$schedule[4].'&CS='.$schedule[6].'">
                                                                                        <h6 style="font-size:17px;font-weight:bold;">'.$schedule[0].'&nbsp; - '.$schedule[1].'&nbsp; ('.date("g:i a", strtotime($schedule[4])).' - '.date("g:i a", strtotime($schedule[5])).')</h6>
                                                                                    </a>
                                                                                    <p class="text-muted m-b-0">Semester : '.$schedule[3].' &nbsp; Division : '.$schedule[2].'</p>
                                                                                </div>
                                                                            </div>
                                                                            ';
                                                                        }
                                                                        else
                                                                        {
                                                                            echo '
                                                                            <div class="row p-b-30">
                                                                                <div class="col-auto text-right update-meta p-r-0">
                                                                                    <i class="b-primary update-icon ring"></i>
                                                                                </div>
                                                                                <div class="col p-l-10">
                                                                                    <a href="../Video_Conferencing/TeachersVC.php?div='.$schedule[2].'&day=Tuesday&course='.$schedule[1].'&start='.$schedule[4].'&CS='.$schedule[6].'">
                                                                                        <h6 style="font-size:17px;font-weight:bold;">'.$schedule[0].'&nbsp; - '.$schedule[1].'&nbsp; ('.date("g:i a", strtotime($schedule[4])).' - '.date("g:i a", strtotime($schedule[5])).')</h6>
                                                                                    </a>
                                                                                    <p class="text-muted m-b-0">Semester : '.$schedule[3].' &nbsp; Division : '.$schedule[2].'</p>
                                                                                </div>
                                                                            </div>
                                                                            ';
                                                                        }
                                                                        $cnt++;
                                                                    }
                                                                    echo '
                                                                    <div class="row">
                                                                        <div class="col-auto text-right update-meta p-r-0">
                                                                            <i class="b-success update-icon ring"></i>
                                                                        </div>
                                                                        <div class="col p-l-10" style="font-size:15.5px;margin-bottom:0%;font-weight:bold;">
                                                                            That\'s all for the day.
                                                                        </div>
                                                                    </div>
                                                                    ';
                                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>