<?php
    session_start();
    error_reporting(0);
    include_once("teacherNavbar.php");
?>
<html lang="en">
    <head>
        <style>
            .div1 {
                float: left;
                width: 20%;
                height: 5rem;
                padding-top: 1.8%;
                text-align:center;
                border: 1px solid black;
            }
            .draggable
            {
                background-color:whitesmoke;
                font-size:20px;
                margin:0%;
                cursor:pointer;
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
        <!-- Main Body Starts -->
        <div class="main-body">
            <div class="page-wrapper subBodyProgram">
            <!-- <div class="page-body"> -->
            <div class="card bodyStyling" style="padding-left:0.5%;">
                <div class="card-header" style="margin-top:0.5%;">
                <h4>Create Schedule</h4>
                <hr style="width:97.5%; margin-left:0%;" />
                </div>
                <div class="card-block">
                <div class="dt-responsive table-responsive tableView">
                    <?php
                        $cnt = $id = 0;
                        while($cnt != 7)
                        {
                            for($i = 0; $i < 5; $i++)
                            {
                                echo 
                                '
                                <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                                    <div draggable="true" class="draggable" ondragstart="drag(event)" id="drag'.$id++.'">'.$id.'</div>
                                </div>
                                ';
                            }
                            $cnt++;
                        }
                    ?>
                    <!-- <br />
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag1">0</div>
                    </div>
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag2">1</div>
                    </div>
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag3">2</div>
                    </div>
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag4">3</div>
                    </div>
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag5">4</div>
                    </div>
                </div>
                <div style="margin-top:2%;margin-left:2%;margin-right:2%;">
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag6"></div>
                    </div>
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag7"></div>
                    </div>
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag8"></div>
                    </div>
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag9"></div>
                    </div>
                    <div class="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
                        <div draggable="true" ondragstart="drag(event)" id="drag10"></div>
                    </div>
                </div> -->
                <script>
                    function allowDrop(ev) {
                        ev.preventDefault();
                    }

                    function drag(ev) {
                        ev.dataTransfer.setData("text", ev.target.id);
                    }

                    function drop(ev) {
                        ev.preventDefault();
                        var data = ev.dataTransfer.getData("text");
                        ev.target.appendChild(document.getElementById(data));
                    }
                </script>
                </div>
            </div>
        </div>
    </body>
</html>