<?php
    session_start();
    error_reporting(0);

    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H" || substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {  
        include("../COMMON_FILES/Connection.php");

        $program = $_POST['program'];
        // $year = $_POST['year'];
        $sem = $_POST['sem'];
        // AND PRGM_CRSE_AcademicYear = $year AND 
        $crse_QRY = "SELECT PRGM_CRSE_CourseID FROM Tb_ProgrammeCourseTypes WHERE PRGM_CRSE_PID = $program  AND PRGM_CRSE_Sem = $sem";
        $data_QRY = mysqli_query($con,$crse_QRY);

        echo '<select name="selCourse" style="width:24%;height:2rem;margin-left:13%;cursor:pointer;">';

        while($res = mysqli_fetch_array($data_QRY))
        {
            echo "&nbsp;&nbsp;&nbsp;<option style='font-size:17px;' value='".$res['PRGM_CRSE_CourseID']."'>".$res['PRGM_CRSE_CourseID']."</option>";
        }
        echo "</select>";
    }
    else
    {
        header('Location: ../COMMON_FILES/logout.php');
    }
?>