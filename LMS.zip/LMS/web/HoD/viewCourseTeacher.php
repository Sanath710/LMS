<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {   
        if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
        include_once("../admin/adminNavbar.php");

        else if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
        include_once("teacherNavbar.php");

        include("../COMMON_FILES/Connection.php");
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';

        $query ="SELECT USR_ID,UID,USR_FirstName,USR_LastName,CRSE_USR_CourseID,CRSE_USR_Sem,CRSE_USR_Division,CRSE_USR_Year,CRSE_Name,CRSE_USR_Status 
                 FROM Mtb_Users,Tb_CourseUsers,Mtb_Courses 
                 WHERE CRSE_USR_UID = Mtb_Users.UID AND CRSE_ID = CRSE_USR_CourseID AND USR_ID NOT LIKE 'S%'";
        $data = mysqli_query($con,$query);

        if($_GET['Status']==1)
        {
            echo 
            '<script> 
              swal("Sorry", "This Teacher is already assigned to that course previously.", "info");
            </script>
            ';
        }
        else if($_GET['Status']==2)
        {
            echo 
            '<script> 
              swal("Success", "Course Teacher Assigned Successfully.", "success");
            </script>
            ';
        }
        else if($_GET['Status']==3)
        {
            echo 
            '<script> 
              swal("Alert", "All Fields are Compulsory.", "warning");
            </script>
            ';
        }

?>
<html lang="en">

    <head>
        <title>LMS | Course Teachers</title>
        <link rel="stylesheet" type="text/css" href="../css/datatables.bootstrap4.min.css" />
        <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "viewCourseTeacher.php");
            }
        </script>
        <style>
            table td {
                padding:0.62%!important;
            }
        </style>
    </head>

    <body>
    <div class="pcoded-content">
    <!-- <div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
        <div class="page-header-title">
            <i class="fa fa-book bg-c-blue" aria-hidden="true"></i>
            <div style="padding-top:1%;">
            <h5>View Programs</h5>
            <span></span>
            </div>
        </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
            <ul class=" breadcrumb breadcrumb-title">
                <li class="breadcrumb-item">
                <a href=""><i class="feather icon-home"></i></a>
                </li>
                <li class="breadcrumb-item"><a href="#!">View Programs</a> </li>
            </ul>
            </div>
        </div>
    </div>
    </div> -->
    <!-- Main Body Starts -->
    <div>
        <div class="main-body">
        <div class="page-wrapper subBodyProgram">
            <div class="page-body">
            <div class="card bodyStyling" style="min-height:54.7rem;">
                <div class="card-header" style="margin-top:0.5%;">
                <h4 style="font-weight:bold;">Course Teachers</h4><hr style="width:97.8%; margin-left:0%;"/>
                <span style="color:red;display:flex;margin-left:0.4%;">
                    <span style="padding-top:0.5%;font-size:15.5px;font-weight:520;">TO EDIT A RECORD, CLICK ON IT</span>
                    <!-- <button style="height:2rem;margin-left:73.5%;padding-bottom:2.2%;margin-top:0%;" 
                        class="btn btn-primary waves-effect waves-light" data-toggle="modal" data-target="#default-Modal">
                        New Record
                    </button>  -->
                    <button style="margin-left:76.5%;height:2rem;padding-bottom:2.2%;padding-right:0.4%;padding-left:0.7%;display:flex;margin-top:0.8%;" 
                        class="btn btn-primary waves-effect" data-toggle="modal" data-target="#default-Modal"> Add &nbsp;<i class='bx bx-plus-circle f-24'></i></button> 
                </span>
                
                </div>
                <div class="card-block">
                    <div class="dt-responsive table-responsive tableView" style="margin-top:1%;margin-bottom:-0.7%;min-height:43.7rem;">
                        <table id="base-style" style="width:100%;border-collpase:collapse;cursor:pointer;" class="table table-striped wrap">
                        <thead>
                            <tr>
                                <th style="width:7%;border-bottom:none;text-align:center;">Sr No</th>
                                <th style="width:10%;border-bottom:none;">User ID</th>
                                <th style="width:18%;border-bottom:none;text-align:left;">User Name</th>
                                <th style="width:12%;border-bottom:none;text-align:center">Course</th>
                                <th style="width:8%;border-bottom:none;text-align:center;">Semester</th>
                                <th style="width:8%;border-bottom:none;text-align:center;">Div</th>
                                <th style="width:8%;border-bottom:none;text-align:center;">Year</th>
                                <th style="width:9%;border-bottom:none;text-align:center;">Status</th>
                                <th id="hideTH" style="text-align:center;">Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $cnt=1;
                            while ($result = mysqli_fetch_assoc($data)) 
                            {
                        ?>  
                            <tr onclick="edit(this)">
                            <!-- Update Form Starts -->
                            <form method="POST">
                                <td style="text-align:center;"><?php echo $cnt; ?></td>
                                <td>
                                    <!-- Span tag for sorting  -->
                                    <span class="dispID"><?php echo $result['USR_ID'];?></span>
                                    <?php echo $result['USR_ID']; ?>
                                </td>
                                <td style="text-align:left;padding-left:1%;" >
                                    <!-- Span tag for sorting  -->
                                    <span class="dispName"><?php echo $result['USR_FirstName']." ".$result['USR_LastName'];?></span>
                                    <?php echo $result['USR_FirstName']." ".$result['USR_LastName']; ?>
                                </td>
                                <td style="text-align:center;" >
                                    <!-- Span tag for sorting  -->
                                    <span class="dispName dispID"><?php echo $result['CRSE_USR_CourseID'];?></span>
                                    <?php echo $result['CRSE_USR_CourseID']; ?>
                                </td>
                                <td style="text-align:center;" >
                                    <!-- Span tag for sorting  -->
                                    <span class="dispName dispID"><?php echo $result['CRSE_USR_Sem'];?></span>
                                    <?php echo $result['CRSE_USR_Sem']; ?>
                                </td>
                                <td style="text-align:center;" >
                                    <!-- Span tag for sorting  -->
                                    <span class="dispName dispID"><?php echo $result['CRSE_USR_Division'];?></span>
                                    <?php echo $result['CRSE_USR_Division']; ?>
                                </td>
                                <td style="text-align:center;" >
                                    <!-- Span tag for sorting  -->
                                    <span class="dispName dispID"><?php echo $result['CRSE_USR_Year'];?></span>
                                    <?php echo $result['CRSE_USR_Year']; ?>
                                </td>
                                <td style="text-align:center;" >
                                    <!-- Span tag for sorting  -->
                                    <span class="dispName dispID">
                                        <?php 
                                            if($result['CRSE_USR_Status'] == 1)
                                                echo '<label class="label label-md bg-success" style="font-size:15px;padding-left:11.5%;padding-right:12.5%;">Active</label>';
                                            else
                                                echo '<label class="label label-md bg-danger" style="font-size:15px;">Deactive</label>';
                                        ?>
                                    </span>
                                    <span class="radio-labels">
                                        <?php 
                                            if($result['CRSE_USR_Status'] == 1)
                                                echo '<label class="label label-md bg-success" style="font-size:15px;padding-left:11.5%;padding-right:12.5%;">Active</label>';
                                            else
                                                echo '<label class="label label-md bg-danger" style="font-size:15px;">Deactive</label>';
                                        ?>
                                    </span>
                                    <span class="editStatus">
                                        <?php
                                            if($result['CRSE_USR_Status'] == 1)
                                            {
                                                echo "
                                                    <input type='radio' name='status' checked value='1'/>&nbsp;Active &nbsp;
                                                    <input type='radio' name='status' value='0'/>&nbsp;Deactive
                                                ";
                                            }
                                            else
                                            {
                                                echo "
                                                    <input type='radio' name='status' value='1'/>&nbsp;Active &nbsp;
                                                    <input type='radio' name='status' value='0'checked/>&nbsp;Deactive
                                                ";
                                            }
                                        ?>
                                    </span>
                                </td>
                                <!-- Hidden Fields -->
                                <input type="hidden" name="userID" value="<?php echo $result['UID']; ?>" />
                                <input type="hidden" name="course" value="<?php echo $result['CRSE_USR_CourseID']; ?>" />
                                <input type="hidden" name="sem" value="<?php echo $result['CRSE_USR_Sem']; ?>" />
                                <input type="hidden" name="div" value="<?php echo $result['CRSE_USR_Division']; ?>" />
                                <input type="hidden" name="year" value="<?php echo $result['CRSE_USR_Year']; ?>" />
                                <!-- ------------- -->
                                <td class="hideTD" id="tbl_btns"> 
                                    <div style="display:flex;">
                                        <button type="submit" class="PGSubmit FormBtn Update" style="margin-left:1.2%;" name="btnUpdate" value="Update">
                                            &nbsp;<i class="fa fa-check-circle"></i>&nbsp;
                                        </button>
                                        &nbsp;
                                        <button type="submit" class="PGSubmit FormBtn Remove" style="width:100%;padding-bottom:2%;" name="btnUpdate" value="Remove">
                                            &nbsp;<i class="fa fa-trash" style="font-size:17px;"></i>&nbsp;
                                        </button>
                                        &nbsp;
                                        <i class='bx bx-x editIcon close' onclick="history.go(0);"></i>
                                    </div>
                                </td>
                            </form>
                            </tr>
                        <?php
                                $cnt++;
                            }
                        ?>
                        </tbody>
                    </table>
                    <?php
                        if(isset($_POST['btnUpdate']))
                        {
                            $uid = $_POST['userID'];
                            $sem = $_POST['sem'];
                            $div = $_POST['div'];
                            $year = $_POST['year'];
                            $course = $_POST['course'];
                            $status = $_POST['status'];
                            $operation = $_POST['btnUpdate'];
                            if($operation == "Update")
                            {
                                $update_QRY = "UPDATE Tb_CourseUsers  SET CRSE_USR_Status = $status 
                                               WHERE CRSE_USR_UID = $uid AND CRSE_USR_Sem = $sem AND CRSE_USR_Division = '$div' 
                                                     AND CRSE_USR_Year = $year AND CRSE_USR_CourseID = $course";
                                if(!mysqli_query($con,$update_QRY))
                                {
                                    echo 
                                    '<script> 
                                      swal("Alert", "Some Error Occured.\nOperation Failed.", "warning");
                                      setTimeout(function(){
                                        window.location.reload(1);
                                      }, 2000);
                                    </script>
                                    ';
                                }
                                else
                                {
                                    echo 
                                    '<script> 
                                      swal("Success", "Record Updated Successfully.", "success");
                                      setTimeout(function(){
                                        window.location.reload(1);
                                      }, 2000);
                                    </script>
                                    ';
                                }
                            }
                            else
                            {
                                $delete_QRY = "DELETE FROM Tb_CourseUsers WHERE CRSE_USR_UID = $uid AND CRSE_USR_Sem = $sem 
                                               AND CRSE_USR_Division = '$div' AND CRSE_USR_Year = $year AND CRSE_USR_CourseID = $course";
                                if(!mysqli_query($con,$delete_QRY))
                                {
                                    echo 
                                    '<script> 
                                      swal("Alert", "Some Error Occured.\nOperation Failed.", "warning");
                                      setTimeout(function(){
                                        window.location.reload(1);
                                      }, 2000);
                                    </script>
                                    ';
                                }
                                else
                                {
                                    echo 
                                    '<script> 
                                      swal("Success", "Record Removed Successfully.", "success");
                                      setTimeout(function(){
                                        window.location.reload(1);
                                      }, 2000);
                                    </script>
                                    ';
                                }
                            }
                        }
                    ?>
                    <script>
                        dispID = document.getElementsByClassName("dispID");
                        dispName = document.getElementsByClassName("dispName");

                        // For Update Form
                        hideTH = document.getElementById("hideTH").style.display = "none";
                        hideTD = document.getElementsByClassName("hideTD");
                        radioBtns = document.getElementsByClassName("editStatus");
                        radioLabels = document.getElementsByClassName("radio-labels");
                        UpdateBtn = document.getElementsByClassName("Update");
                        RemoveBtn = document.getElementsByClassName("Remove");
                        editClose = document.getElementsByClassName("close");

                        for(i = 0 ; i < dispID.length; i++)
                        {
                            dispID[i].style.display="none";
                            dispName[i].style.display="none";
                        }

                        for(i = 0 ; i < UpdateBtn.length; i++)
                        {
                            UpdateBtn[i].style.display = "none";
                            RemoveBtn[i].style.display = "none";
                            radioBtns[i].style.display = "none";
                            editClose[i].style.display = "none";
                            hideTD[i].style.display = "none";
                        }

                        function edit(id) 
                        { 
                            UpdateBtn[id.rowIndex-1].removeAttribute("style");
                            RemoveBtn[id.rowIndex-1].removeAttribute("style");
                            editClose[id.rowIndex-1].removeAttribute("style");
                            radioBtns[id.rowIndex-1].removeAttribute("style");
                            hideTD[id.rowIndex-1].removeAttribute("style");
                            radioLabels[id.rowIndex-1].style.display = "none";
                            document.getElementById("hideTH").removeAttribute("style");
                        }
                    </script>
                    </div>
                </div>
            </div>
        </div>
         <!-- New Assigning of Course Teacher -->
         <div class="card-block">
          <ul>
            <li>
              <div class="modal fade" id="default-Modal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width:120%;">
                    <div class="modal-header">
                        <h4 class="modal-title" style="font-weight:bold;margin-left:1.5%;">Assign Course Teacher</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php
                        $PRGM_QRY = "SELECT PID,PRGM_ID FROM Tb_ProgrammeCourseTypes,Mtb_Programme WHERE PRGM_CRSE_PID = PID GROUP BY PID";
                        $PRGM_QRY_Data = mysqli_query($con,$PRGM_QRY);
                        $Year_QRY = "SELECT PRGM_CRSE_AcademicYear FROM Tb_ProgrammeCourseTypes GROUP BY PRGM_CRSE_AcademicYear";
                        $Year_QRY_Data = mysqli_query($con,$Year_QRY);
                        $Sem_QRY = "SELECT PRGM_CRSE_Sem FROM Tb_ProgrammeCourseTypes GROUP BY PRGM_CRSE_Sem";
                        $Sem_QRY_Data = mysqli_query($con,$Sem_QRY);
                    ?>
                    <form method="POST" action="assignCourseTeacher_DB.php" style="margin-bottom:2.5%;">
                        <div style="margin-left:1%;margin-top:4%;">
                            <label class="col-form-label frmTxt" style="margin-left:3%;font-weight:550;">Programme</label>
                            <select name='selProgramID' id='program' onchange="getCourse()" style="width:17%;border:1px solid;cursor:pointer;margin-top:0.3%;height:2rem;margin-left:7.5%;">
                            <option  value='x'>Select</option>
                            <?php
                                while($result = mysqli_fetch_assoc($PRGM_QRY_Data))
                                {
                                    echo "<option  style='font-size:17px;'  value='".$result['PID']."'>".$result['PRGM_ID']."</option>";
                                }
                            ?>
                            </select>
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <label class="col-form-label frmTxt" style="margin-left:4.5%;cursor:pointer;font-weight:550;">Semester</label>&nbsp;&nbsp;
                            <select name="selSem" id='sem' onchange="getCourse()" style="width:17%;height:2rem;margin-top:0.3%;
                                margin-left:0.5%;cursor:pointer;">
                            <option  value='x'>Select</option>
                            <?php
                                while($result1 = mysqli_fetch_assoc($Sem_QRY_Data))
                                {
                                    echo "<option  style='font-size:17px;' value='".$result1['PRGM_CRSE_Sem']."'>".$result1['PRGM_CRSE_Sem']."</option>";
                                }
                            ?>
                            </select>
                             <!-- <br/>
                            <label class="col-form-label frmTxt" style="margin-left:3%;margin-top:1.5%;">Enrollment Year</label>&nbsp;&nbsp;
                            <select name="selYear" id='year' onchange="getCourse()" style="width:17%;height:2rem;margin-top:0.3%;margin-left:0.5%;">
                            <option  value='x'>Select</option>
                            <?php
                                // while($result = mysqli_fetch_assoc($Year_QRY_Data))
                                // {
                                //     echo "<option  style='font-size:17px;' value='".$result['PRGM_CRSE_AcademicYear']."'>".$result['PRGM_CRSE_AcademicYear']."</option>";
                                // }
                            ?>
                            </select> -->
                        </div>
                        <!-- <br/> -->
                        <!-- </form>
                        <hr/>
                        <br/>
                        <form method="POST" action="" > -->
                        <!-- <div id="divDisp" style="display:none;"> -->
                            <label class="col-form-label frmTxt" style="margin-left:4.2%;margin-top:2.5%;font-weight:550;">Teacher ID</label>
                            <select name='selTeacherID' style="width:58%;margin-top:0.3%;height:2rem;margin-left:9%;cursor:pointer;">
                            <?php
                                $teacherID_QRY = "SELECT UID,USR_ID,USR_FirstName,USR_LastName FROM Mtb_Users WHERE substring(USR_ID,1,1)='T' OR substring(USR_ID,1,1)='H'";
                                $teacherID_Data = mysqli_query($con,$teacherID_QRY);
                                while($result = mysqli_fetch_assoc($teacherID_Data))
                                {
                                    echo "<option  style='font-size:17px;' value='".$result['UID']."'>".$result['USR_ID']."&nbsp;&nbsp;&nbsp;".$result['USR_FirstName']." ".$result['USR_LastName']."&nbsp;&nbsp;&nbsp;</option>";
                                }
                            ?>
                            </select>
                            <br/>
                            <label class="col-form-label frmTxt" style="margin-left:4.3%;margin-top:1.5%;font-weight:550;">Course</label>&nbsp;&nbsp;
                            <span id="resCourse"></span>
                            <script>
                                function getCourse()
                                {
                                    let program = document.getElementById("program").value;
                                    // let year = document.getElementById("year").value;
                                    let sem = document.getElementById("sem").value;

                                    if(program == "Null" && sem == "Null")
                                    {
                                        // Do Nothing :)
                                    }
                                    else
                                    {
                                        let xhr;

                                        (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                        
                                        // "&year="+year+
                                        let data = "program="+program+"&sem="+sem;
                                    
                                        xhr.open("POST","AJAX_AssignCourseTeacher_DB.php",true);
                                        xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                        xhr.send(data);
                                        xhr.onreadystatechange = display_data
                                        function display_data()
                                        {
                                            if(xhr.readyState == 4)
                                            {
                                                if(xhr.status == 200)
                                                {
                                                    document.getElementById("resCourse").innerHTML = xhr.responseText;
                                                    document.getElementById('divDisp').style.display="flex";
                                                    document.getElementById('submit').style.display="";
                                                    document.getElementById('reset').style.display="";
                                                }
                                                else
                                                {
                                                    alert("There was a problem with the request");
                                                }
                                            }
                                        }
                                    }
                                }
                            </script>
                            <noscript>Your browser doesnot support JavaScript!</noscript>
                           
                            <label class="col-form-label frmTxt" style="margin-left:10%;font-weight:550;margin-top:2.5%;">Division</label>&nbsp;&nbsp;
                            <select name="selDivision" style="width:9.18%;height:2rem;cursor:pointer;margin-top:0.3%;margin-left:0.5%;">
                            <?php
                                echo "
                                    <option  style='font-size:17px;' value='A'> A </option>
                                    <option  style='font-size:17px;' value='B'> B </option>
                                    <option  style='font-size:17px;' value='C'> C </option>
                                    <option  style='font-size:17px;' value='D'> D </option>
                                    <option  style='font-size:17px;' value='E'> E </option>
                                ";
                            ?>
                            </select>
                            <!-- <label class="col-form-label frmTxt" style="margin-left:3%;">User Status : </label>&nbsp;&nbsp;&nbsp;
                            <span style="font-size:18px;padding-top:0.5%;">
                                Active <input type="radio" name="userStatus" value="1" checked/>&nbsp;&nbsp;
                                Deactive <input type="radio" name="userStatus" value="0"/>
                            <span> -->
                        <br/>
                        <!-- <input type="submit" class="PGSubmit" id="submit" style="margin-left:4%;padding:2%;margin-top:1.3%;width:max-content;font-size:15px;height:2.5rem;padding-top:1.25%;" 
                                onclick="return validate()" name="btnSubmit" value="Submit" /> &nbsp; -->
                        <!-- <input type="reset" class="PGSubmit" id="reset" style="margin-top:2.7%;padding:2%;width:max-content;margin-left:-4%;font-size:16px;height:2.5rem;
                                padding-top:1%;margin-bottom:3%;" value="Reset" /> -->
                        <br/>
                            <div class="modal-footer">
                                <input type="reset" class="btn btn-default waves-effect" data-dismiss="modal" value="Cancel"/>
                                <input type="submit" class="btn btn-primary waves-effect waves-light" name="btnSubmit" value="Add" onclick="return validate()"/>
                            </div>
                        </div>
                    </form>
                    <script>
                        function validate()
                        {
                            if(document.getElementById("program").value == "x")
                            {
                                swal("Alert", "Please Select a programme", "warning");
                                return false;
                            }
                            if(document.getElementById("sem").value == "x")
                            {
                                swal("Alert", "Please Select Semester", "warning");
                                return false;
                            }
                            if(document.getElementById("year").value == "x")
                            {
                                swal("Alert", "Please Select Year", "warning");
                                return false;
                            }
                        }
                    </script>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <script src="../js/jquery.datatables.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.buttons.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.bootstrap4.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.responsive.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/data-table-custom.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="06ff493bca0b4366a261bcf1-|49" defer=""></script>
    </body>
</html>
<?php
  }
  else
  {
      header('Location:../COMMON_FILES/logout.php');
  }
?>