<?php
    session_start();
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
        include("../COMMON_FILES/Connection.php");
        $sem = $_POST['sem'];
        $sql = "SELECT UID, USR_ID, USR_FirstName, USR_LastName FROM Mtb_Users,Tb_CourseUsers WHERE UID = CRSE_USR_UID AND USR_Role not in ('HoD','Teacher','Admin') 
        AND CRSE_USR_Sem = $sem AND CRSE_USR_Status = 1 GROUP BY USR_ID";
        $data = mysqli_query($con,$sql);
        
        echo '<select name="sel_StudID"  style="margin-left:4.1%;margin-top:-1%;font-size:18px;">';
        while($r = mysqli_fetch_assoc($data))
        {
            echo "
                <option value='".$r['UID']."'>".$r['USR_ID']."&nbsp;&nbsp;&nbsp;".$r['USR_FirstName']."&nbsp;".$r['USR_LastName']."</option>
            ";
        }
        echo '</select>';
    }
?>