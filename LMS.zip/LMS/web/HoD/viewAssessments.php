<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");

        $uid = $_SESSION['Sess_USR_ID'];
        $cid = base64_decode($_GET['id']);
        $type = base64_decode($_GET['type']); 
        $year = date("Y");

        # For Course Name for title of page
        $sql = "SELECT CRSE_Name FROM Mtb_Courses WHERE CRSE_ID = $cid";
        $data = mysqli_query($con,$sql);
        $result = mysqli_fetch_assoc($data);

        # Assessment Submission Students List Query
        $assess_QRY = "SELECT CRSE_DOC_DocID, USR_ID, USR_FirstName, USR_LastName, CRSE_DOC_Points, CRSE_DOC_Submission 
                       FROM Mtb_Users, Mtb_CourseDocs_New 
                       WHERE CRSE_DOC_USR_ID = USR_ID AND CRSE_DOC_CourseID = $cid AND CRSE_DOC_Type = '$type' AND CRSE_DOC_Sem = substring($cid,5,2) 
                       AND CRSE_DOC_Year = $year AND USR_ID LIKE 'S%' ORDER BY USR_ID";
        $assess_Data = mysqli_query($con,$assess_QRY);

        # For assessment uploaded by teacher
        $due_QRY = "SELECT CRSE_DOC_DocID, CRSE_DOC_DocName, CRSE_DOC_DESC_Description, CRSE_DOC_TCHR_DueDate, CRSE_DOC_TCHR_DueTime, CRSE_DOC_Points, 
                    CRSE_DOC_TCHR_AvailableFromDate, CRSE_DOC_TCHR_Weightage, CRSE_DOC_TCHR_DocVisibility 
                    FROM Mtb_CourseDocs_New, Tb_CourseDocTCHR, Tb_CourseDocDesc
                    WHERE CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_DOC_DocID = CRSE_DOC_DESC_DocID AND CRSE_DOC_CourseID = $cid 
                    AND CRSE_DOC_Type = '$type' AND CRSE_DOC_Sem = substring($cid,5,2) AND CRSE_DOC_Year = $year AND CRSE_DOC_USR_ID = '$uid'";
        $due_Data = mysqli_query($con,$due_QRY);
        $due_Result = mysqli_fetch_assoc($due_Data);
        $dueDate = $due_Result['CRSE_DOC_TCHR_DueDate'];
        $dueTime = $due_Result['CRSE_DOC_TCHR_DueTime'];
        $total_submissions = mysqli_num_rows($assess_Data);

        # For late Submission Count (Could me better coded but due to time constraint coded this way)
        $late = 0;
        $repeat = mysqli_query($con,$assess_QRY);
        while($r = mysqli_fetch_assoc($repeat))
        {
            # For Date
            $stud_sub = substr($r['CRSE_DOC_Submission'],0,10);
            $dt1=date_create("$stud_sub");
            $dt2=date_create("$dueDate");
            $differnce = date_diff($dt1,$dt2);
            
            # For Time difference
            $due = $dueDate." ".$dueTime;
            $submission = $r['CRSE_DOC_Submission'];
            $diff_tim=(strtotime($due)-strtotime($submission))/60;

            if($differnce->format("%R%a") >= 0)
            {
                if($diff_tim < 0)
                {
                    $late++;
                }
            }
            else
            {
                $late++;
            }
        }
        # For Non-Submission Student's List & Count
        $nonSub_QRY = "SELECT USR_ID, USR_FirstName, USR_LastName, USR_EmailID FROM mtb_users LEFT JOIN mtb_coursedocs_new ON USR_ID = CRSE_DOC_USR_ID WHERE USR_ID LIKE 'S%' AND USR_ID NOT IN 
                      (SELECT CRSE_DOC_USR_ID FROM mtb_coursedocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_DOC_Type = '$type' AND CRSE_DOC_Sem = substring($cid,5,2) AND CRSE_DOC_Year = $year AND USR_ID LIKE 'S%')
                      GROUP BY USR_ID";
        $nonSub_Data = mysqli_query($con,$nonSub_QRY);
        $nonSub_Count = mysqli_num_rows($nonSub_Data);
?>
<html>
    <head>
        <title>LMS | Course View <?php echo $type; ?></title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "viewAssessments.php?id=<?php echo base64_encode($cid);?>&type=<?php echo base64_encode($type);?>");
            }
        </script>
        <!-- Sweet Alert -->
        <script src="../COMMON_FILES/sweetalert.min.js"></script>
         <!-- File Icons -->
         <link href="../css/css-file-icons.css?v=<?php echo time(); ?>" rel="stylesheet">
        <style>
            .main-card 
            {
                border : 1px solid white;
            }
            .main-card:hover 
            {
                border: 1px solid rgba(81, 203, 238, 1);
            }
            .assess_Details
            {
                /* height:24rem; */
                padding:1%;
                border-radius:2px;
                box-shadow: 0 0 5px rgba(81, 203, 238, 1);
            }
            .nonSubmission:hover
            {
                cursor: pointer;
                color:blue;
            }
            .nonSubmission
            {
                color:red;
            }
            .editbtn:hover, .mybtn:hover
            {
                background-color: rgb(3, 231, 3);
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-15">
                                        <h4 style="font-weight:bold;"><?php echo $cid." : ".$result['CRSE_Name'];?></h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                </div>
                                <h4 style="font-weight:bold;margin-top:0.5%;margin-bottom:0%;"><?php echo $type; ?>&nbsp; <i class="fa fa-file-text-o"></i></h4>
                                <!-- Edit Button -->
                                <label class="label label-md label-primary editbtn" data-toggle='modal' data-target='#editForm' style="font-size:17px;margin-left:94.35%;margin-bottom:1.5%;cursor:pointer;">
                                    <i class="fa fa-pencil-square-o"></i> Edit 
                                </label>
                                <!-- Assessment Details -->
                                <div class="assess_Details m-b-20 p-l-5">
                                    <h5 style="font-weight:bold;"> Assessment Name : &nbsp; 
                                    <?php 

                                        # For file icon
                                        $id = $due_Result['CRSE_DOC_DocID'];
                                        $file_Qry = "SELECT CRSE_DOC_Attach_Path FROM Tb_CourseDOCAttached WHERE CRSE_Doc_Attach_DocID = $id";
                                        $file_Data = mysqli_query($con,$file_Qry);
                                        $file_Res = mysqli_fetch_assoc($file_Data);

                                        if(@$file_Res['CRSE_DOC_Attach_Path'])
                                        {
                                            echo '
                                                    <a style="margin-left:8%;" href="../'.$file_Res['CRSE_DOC_Attach_Path'].'">
                                            ';
                                        }
                                            echo '      <span style="font-size:18px;">'.$due_Result['CRSE_DOC_DocName'].'</span> &nbsp;&nbsp;';
                                        if(@$file_Res['CRSE_DOC_Attach_Path'])
                                        {
                                            echo '
                                                        <span style="width:35px;height:38px;padding-top:0.8%;margin-bottom:-2%;padding-left:0%;" class="fi fi-'.end(explode(".",@$file_Res['CRSE_DOC_Attach_Path'])).'">&nbsp;
                                                            <div class="fi-content">'.end(explode(".",@$file_Res['CRSE_DOC_Attach_Path'])).'</div>
                                                        </span>
                                                    </a>
                                            ';
                                        }
                                        else
                                        {
                                            echo '
                                                <br/><br/>
                                                <div style="width:100%";>'.$due_Result['CRSE_DOC_DESC_Description'].'</div>
                                            ';
                                        }
                                        echo '
                                                <br/><br/>
                                                Assigned On : <span style="margin-left:12%;">'.date("d-m-Y",strtotime($due_Result['CRSE_DOC_TCHR_AvailableFromDate'])).'</span>
                                                <br/><br/>
                                                Due On : <span style="margin-left:15.2%;">'.date("d-m-Y",strtotime($due_Result['CRSE_DOC_TCHR_DueDate'])).'&nbsp;&nbsp;'.date("g:i A", strtotime($due_Result['CRSE_DOC_TCHR_DueTime'])).'</span>
                                                <br/><br/>
                                                Total Points : <span style="margin-left:12.68%;">'.$due_Result['CRSE_DOC_Points'].' Points.</span>
                                                <br/><br/>
                                                Internal Weightage : <span style="margin-left:8.75%;">'.$due_Result['CRSE_DOC_TCHR_Weightage'].' marks.</span>
                                                <br/><br/>
                                                Visibility for Students : 
                                                    <span style="margin-left:7%;">
                                        ';
                                                    # For Document Visibility (1 = visible, 0 = hidden from students)
                                                    if($due_Result['CRSE_DOC_TCHR_DocVisibility'] == 1)
                                                    {
                                                        echo '<i class="fa fa-eye"></i>';
                                                    }
                                                    else
                                                    {
                                                        echo '<i class="fa fa-eye-slash"></i>';
                                                    }
                                        echo '
                                                    </span>
                                                <br/><br/><br/>
                                                Late Submissions : <span style="margin-left:9.15%;">'.$late.'</span>
                                                <br/><br/>
                                        ';
                                        ?>
                                                <span class="nonSubmission" data-toggle="modal" data-target="#default-Modal2" ><Span style="text-decoration:underline;"> Non Submissions</span> : </span><span style="margin-left:9.25%;color:red;"><?php echo $nonSub_Count; ?></span>
                                        <?php
                                                echo '  <br/><br/>
                                                Total Received Submissions : <span style="margin-left:3%;">'.$total_submissions.'</span>
                                            </h5>
                                        ';
                                    ?>
                                </div>
                                <h4 style="font-weight:bold;margin-top:3.5%;margin-bottom:2%;margin-left:0.5%;"> Submissions Received : </h4>
                                <hr/>
                                <br/>
                                <div style="margin-left:-1%;width:100%;display:flex;flex-wrap:wrap;">
                                <?php
                                    while($res = mysqli_fetch_assoc($assess_Data))
                                    {
                                        echo '
                                            <div class="col-md-6 col-lg-4 m-t-10">
                                                <div class="card main-card" style="width:auto%;">
                                                    <div class="card-header" style="margin-left:3.6%;">
                                                        <h5 style="font-size:18px;">'.$res['USR_ID'].' : '.$res['USR_FirstName'].'&nbsp;&nbsp;'.$res['USR_LastName'].'</h5>
                                        ';
                                        # For Date
                                        $stud_submissionDate = substr($res['CRSE_DOC_Submission'],0,10);
                                        $date1=date_create("$stud_submissionDate");
                                        $date2=date_create("$dueDate");
                                        $diff = date_diff($date1,$date2);

                                        # For Time difference
                                        $due_On = $dueDate." ".$dueTime;
                                        $start = date_create("$due_On");
                                        $submission_time = $res['CRSE_DOC_Submission'];
                                        $end = date_create("$submission_time");
                                        $time_diff = date_diff($end,$start);
                                        $diff_time=(strtotime($due_On)-strtotime($submission_time))/60;

                                        if($diff->format("%R%a") >= 0)
                                        {
                                            if($diff_time > 0)
                                            {
                                                echo '<label class="label label-success" style="font-size:16px;margin-top:8%;margin-bottom:2.5%;">'.$diff->format("%a days ").$time_diff->format("%h hours & %i minutes %s seconds ").'Earlier </label>
                                                <span style="font-size:16px;">'.date("d-m-Y",strtotime($stud_submissionDate)).'&nbsp;@ '.date("g:i A", strtotime($submission_time)).'</span>';
                                            }
                                            else
                                            {
                                                echo '<label class="label label-warning" style="font-size:17px;margin-top:8%;margin-bottom:2.5%;">'.$diff->format("%a days ").$time_diff->format("%h hours & %i minutes %s seconds ").'Late </label>
                                                <span style="font-size:16px;">'.date("d-m-Y",strtotime($stud_submissionDate)).'&nbsp;@ '.date("g:i A", strtotime($submission_time)).'</span>';
                                            }
                                        }
                                        else
                                        {
                                            echo '<label class="label label-warning" style="font-size:17px;margin-top:8%;margin-bottom:2.5%;">'.$diff->format("%a days ").$time_diff->format("%h hours & %i minutes %s seconds ").'Late</label>
                                            <span style="font-size:16px;">'.date("d-m-Y",strtotime($stud_submissionDate)).'&nbsp;@ '.date("g:i A", strtotime($submission_time)).'</span>';
                                        }

                                        # Points for Assessment
                                        if(@$res['CRSE_DOC_Points'] != null)
                                            echo 'Points : <label style="margin-top:2%;">'.$res['CRSE_DOC_Points'].'</label>';
                                        else
                                            echo 'Points : <label style="margin-top:2%;color:red;">Not allocated yet.</span></label>';

                                        # For getting file if submitted.
                                        $docID = $res['CRSE_DOC_DocID'];
                                        $attach_QRY = "SELECT CRSE_DOC_Attach_Path FROM Tb_CourseDOCAttached WHERE CRSE_DOC_Attach_DocID = $docID";
                                        $attach_Data = mysqli_query($con,$attach_QRY);
                                        $attach_Result = mysqli_fetch_assoc($attach_Data);

                                        # For online text Submission
                                        $text_QRY = "SELECT CRSE_DOC_DESC_Description FROM Tb_CourseDOCDESC WHERE CRSE_DOC_DESC_DocID = $docID";
                                        $text_Data = mysqli_query($con,$text_QRY);
                                        $text_Result = mysqli_fetch_assoc($text_Data);


                                        echo "
                                                    </div>
                                                    <div class='card-block' style='margin-top:0%;'>
                                        ";


                                        if(@$attach_Result['CRSE_DOC_Attach_Path'])
                                        {
                                            echo "    <a href='../".$attach_Result['CRSE_DOC_Attach_Path']."' class='btn waves-effect waves-light btn-linkedin'>View Submission</a>";
                                        }
                                        else if (@$text_Result['CRSE_DOC_DESC_Description'])
                                        {
                                            echo "<a href='viewAssess_TextualAns.php?id=".base64_encode($cid)."&type=".base64_encode($type)."&did=".base64_encode($docID)."&uid=".base64_encode($res['USR_ID'])."' 
                                                        class='btn waves-effect waves-light btn-linkedin'>View Submission</a>";
                                        }
                                        
                                    ?>
                                                <button class='m-l-5 btn waves-effect waves-light btn-dribbble' data-toggle='modal' data-target='#default-Modal1' 
                                                    value="<?php echo $res['USR_ID']; ?>" onclick="setComment(this,<?php echo $res['CRSE_DOC_DocID']; ?>)">Comment</button>
                                                
                                                <button class='m-l-5 btn waves-effect waves-light btn-square' data-toggle='modal' data-target='#default-Modal' 
                                                    value="<?php echo $res['USR_ID']; ?>" onclick="get_USR_ID(this)">Grade</button>
                                    <?php 
                                            # For Comments if any
                                            $getComment_QRY = "SELECT CRSE_DOC_RMKS_Remarks FROM Tb_CourseDocRemarks WHERE CRSE_DOC_RMKS_DocID = $docID";
                                            $getComment_Data = mysqli_query($con,$getComment_QRY);
                                            $comment = mysqli_fetch_assoc($getComment_Data);
                                            if(@$comment['CRSE_DOC_RMKS_Remarks'])
                                            {
                                    ?>
                                                <i class='fa fa-commenting-o btn waves-effect waves-light btn-success' data-toggle='modal' data-target='#viewComments' 
                                                    style='margin-left:0.2%;padding:2%;font-size:25px;' onclick="get_comments('<?php echo $res['USR_ID']; ?>','<?php echo htmlentities($comment['CRSE_DOC_RMKS_Remarks']); ?>')"></i>
                                    <?php
                                            }
                                            
                                        echo "
                                                    </div>
                                                </div>
                                            </div>
                                        ";
                                    }
                                ?>
                                </div>
                                <!--  -->
                                <script>
                                    // Function to Get User ID for grading
                                    function get_USR_ID(id)
                                    {
                                        let myid = id.value;
                                        document.getElementById("myID").innerHTML = myid;
                                        document.getElementById("user").value = myid;
                                    }
                                    // Function for getting user id and document id of submitted document by user.
                                    function setComment(id,doc)
                                    {
                                        let myid = id.value;
                                        let docid = doc;
                                        document.getElementById("userid").innerHTML = myid;
                                        document.getElementById("DID").value = docid;
                                    }
                                    // Function for getting comments on post if any
                                    function get_comments(id,comment)
                                    {
                                        document.getElementById("user-id").innerHTML = id;
                                        document.getElementById("comment-body").innerHTML = comment;
                                    }
                                </script>
                                <!--  -->
                                <!-- Grade Allocation -->
                                <div class="card-block">
                                    <ul>
                                        <li>
                                        <div class="modal fade" id="default-Modal" tabindex="-1" role="dialog">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content" style="width:60%;">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" style="font-weight:bold;">Grade For <span id="myID"></span></h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <!-- Form For Grade Allocation -->
                                                    <form id="main" method="POST">
                                                        <div class="modal-body">
                                                            <div class="form-group row">
                                                                <div style="display:flex;margin-top:6%;">
                                                                    <label class="col-form-label frmTxt" style="margin-left:9%;margin-right:4%;">Enter Grade : </label>
                                                                    <input type="hidden" name="user" id="user" />
                                                                    <input type="hidden" name="course" value="<?php echo $cid; ?>" />
                                                                    <input type="hidden" name="doctype" value="<?php echo $type; ?>" />
                                                                    <input type="number" step="any" class="form-control frmTxt" style='width:35%;font-size:17px;padding-left:4%;' 
                                                                        name="Grade" autocomplete="off" id="Grade" required
                                                                        title="Enter value greater than 0 and should be lesser than <?php echo $due_Result['CRSE_DOC_Points']; ?>" 
                                                                        min="0" max="<?php echo $due_Result['CRSE_DOC_Points']; ?>" placeholder="Grade"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- New Programme Buttons -->
                                                        <div class="modal-footer" style="margin-bottom:-2.3%!important;">
                                                            <input type="reset" class="btn btn-default waves-effect" data-dismiss="modal" value="Cancel"/>
                                                            <input type="submit" class="btn btn-primary waves-effect waves-light" name="btnAllocate" value="Allocate" onclick="return inputCheck()"/>
                                                        </div>
                                                    </form>
                                                    <?php
                                                        if(isset($_POST['btnAllocate']))
                                                        {
                                                            $user = $_POST['user'];
                                                            $doctype = $_POST['doctype'];
                                                            $grade = $_POST['Grade'];
                                                            $course = $_POST['course'];
                                                            $C_Year = date("Y");

                                                            $sql = "UPDATE Mtb_CourseDocs_New SET CRSE_DOC_Points = $grade 
                                                                    WHERE CRSE_DOC_USR_ID = '$user' AND CRSE_DOC_CourseID = $course AND CRSE_DOC_Sem = substring($course,5,2) AND CRSE_DOC_Year = $C_Year
                                                                    AND CRSE_Doc_Type = '$doctype'";
                                                            if(!mysqli_query($con,$sql))
                                                            {
                                                                echo 
                                                                '<script> 
                                                                    swal("Alert", "Something went Wrong. Grade not allocated.", "warning");
                                                                </script>
                                                                ';
                                                            }
                                                            else
                                                            {
                                                                echo 
                                                                '<script> 
                                                                    setTimeout(function(){
                                                                        window.location.reload();
                                                                    }, 2000);
                                                                    swal("Success", "Grade allocated.", "success");
                                                                </script>
                                                                ';
                                                            }
                                                        }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Comment on Submission -->
                                <div class="card-block">
                                    <ul>
                                        <li>
                                        <div class="modal fade" id="default-Modal1" tabindex="-1" role="dialog">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content" style="width:200%;">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" style="font-weight:bold;">Comment On <span id="userid"></span> Submission</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <!-- Form For Comment on Submission-->
                                                    <form id="main" method="POST">
                                                        <div class="modal-body">
                                                            <div class="form-group row">
                                                                <div style="display:flex;margin-top:2%;width:95%;">
                                                                    <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:2%;">Enter Your Comments </label>
                                                                    <input type="hidden" name="DID" id="DID" />
                                                                    <textarea style="width:500%;height:7rem;padding-left:1%;" name="comment" placeholder="Enter Less than 256 Characters" require></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- New Programme Buttons -->
                                                        <div class="modal-footer" style="margin-bottom:-2.3%!important;">
                                                            <input type="reset" class="btn btn-default waves-effect" data-dismiss="modal" value="Cancel"/>
                                                            <input type="submit" class="btn btn-primary waves-effect waves-light" name="btnComment" value="Ok" onclick="return inputCheck()"/>
                                                        </div>
                                                    </form>
                                                    <?php
                                                        if(isset($_POST['btnComment']))
                                                        {
                                                            $doc = $_POST['DID'];
                                                            $rmks = $_POST['comment'];

                                                            # For deleting previous comment if done to avoid any further issues in insert query if multiple attempts are done for comment
                                                            $dlt_Previous = "DELETE FROM Tb_CourseDocRemarks WHERE CRSE_DOC_RMKS_DocID = $doc";
                                                            mysqli_query($con,$dlt_Previous);

                                                            # Acts as new insert query for comment done.
                                                            $sql = "INSERT INTO Tb_CourseDocRemarks(CRSE_DOC_RMKS_DocID,CRSE_DOC_RMKS_Remarks) VALUES ($doc,'$rmks')";
                                                            if(!mysqli_query($con,$sql))
                                                            {
                                                                echo 
                                                                '<script> 
                                                                    swal("Alert", "Something went Wrong. Please try again.", "warning");
                                                                </script>
                                                                ';
                                                            }
                                                            else
                                                            {
                                                                echo 
                                                                '<script> 
                                                                    setTimeout(function(){
                                                                        window.location.reload();
                                                                    }, 2000);
                                                                    swal("Success", "Comment Added to the Submission.", "success");
                                                                </script>
                                                                ';
                                                            }
                                                        }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Non Submission Student's List -->
                                <div class="card-block">
                                    <ul>
                                        <li>
                                            <div class="modal fade" id="default-Modal2" tabindex="-1" role="dialog" style="margin-left:0%;">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content" style="width:120%;">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" style="font-weight:bold;">Non-Submission Student's List</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div style="overflow:contain;">
                                                            <table style="margin:4%;width:92%;" class="table table-striped table-bordered wrap">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Student ID</th>
                                                                        <th>Name</th>
                                                                        <th>Email ID</th>
                                                                    </tr>
                                                                </thead>
                                                            <?php
                                                                while($non = mysqli_fetch_assoc($nonSub_Data))
                                                                {
                                                                    echo 
                                                                    '
                                                                    <tr>
                                                                        <td>'.$non['USR_ID'].'</td>
                                                                        <td>'.$non['USR_FirstName'].'&nbsp;'.$non['USR_LastName'].'</td>
                                                                        <td>'.$non['USR_EmailID'].'</td>
                                                                    </tr>
                                                                    ';
                                                                }
                                                            ?>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Assessment Edit Form -->
                                <div class="card-block">
                                    <ul>
                                        <li>
                                            <div class="modal fade" id="editForm" tabindex="-1" role="dialog" style="margin-left:0%;">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content" style="width:120%;">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" style="font-weight:bold;">Edit Form : <?php echo $cid." ".$type; ?></h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div style="overflow:contain;">
                                                            <table style="margin:4%;width:92%;margin-bottom:3%;" class="table wrap">
                                                                <!-- Update Form of Assessment -->
                                                                <form method="POST">
                                                                    <!-- <thead> -->
                                                                        <tr>
                                                                            <input type="hidden" name="docid" value="<?php echo $due_Result['CRSE_DOC_DocID']; ?>" />
                                                                            <th style="width:25%;">Assessment Name </th>
                                                                            <td>
                                                                                <input type="text" name="a_Name" value='<?php echo $due_Result['CRSE_DOC_DocName']?>'
                                                                                    style="margin-top:-0.5%;font-size:19px; border: 1px solid rgba(113,113,113);width:100%;" autocomplete="off" required/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th>Due Event </th>
                                                                            <td>
                                                                                <input type="date" name="D_Date" style="width:46%;" value='<?php echo $due_Result['CRSE_DOC_TCHR_DueDate'];?>' required/>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                                <input type="time" name="D_Time"  style="width:46%;" value='<?php echo $due_Result['CRSE_DOC_TCHR_DueTime'];?>' required/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th>Total Points </th>
                                                                            <td>
                                                                                <input type="number" placeholder="Total Points" name="A_Points" required min="0" style="width:50%;" value='<?php echo $due_Result['CRSE_DOC_Points'];?>' pattern="[0-9]{0,}"/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th>Internal Weightage </th>
                                                                            <td>
                                                                                <input type="number" step="any" placeholder="Points" required value='<?php echo $due_Result['CRSE_DOC_TCHR_Weightage'];?>' name="Weightage_Points" min="0" style="width:50%;" pattern="[0-9]{0,}"/>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th>Visibility for Students </th>
                                                                            <td>
                                                                                <?php
                                                                                    # Visibility = 1 (then visible), Visibility = 0 (then hidden)
                                                                                    if($due_Result['CRSE_DOC_TCHR_DocVisibility'] == 1)
                                                                                    {
                                                                                        echo '
                                                                                            Visible <input type="radio" name="Show_Hide" value="1" checked/>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                                            Hidden <input type="radio" name="Show_Hide" value="0" />
                                                                                        ';
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        echo '
                                                                                            Visible <input type="radio" name="Show_Hide" value="1"/>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                                            Hidden <input type="radio" name="Show_Hide" value="0" checked/>
                                                                                        ';
                                                                                    }
                                                                                    
                                                                                ?>
                                                                            </td>
                                                                        </tr>
                                                                    <!-- </thead> -->
                                                            </table>
                                                            <div style="display:flex;">
                                                                    <input type="submit" id="btnSubmit" name="btnAsUpdate" style="font-size:16px;border-radius:7%;margin-bottom:3%;margin-left:4%;" 
                                                                        class="btn btn-primary btn waves-effect waves-light mybtn" value="Submit">&nbsp;&nbsp;&nbsp;
                                                                    <input type="reset" id="btnReset" style="padding-left:4%;font-size:16px;padding-right:3.5%;margin-bottom:3%;border-radius:7%;" 
                                                                        class="btn btn-primary btn waves-effect waves-light mybtn" value="Reset">
                                                                </form>
                                                                &nbsp;&nbsp;

                                                                <form method="POST">
                                                                    <input type="hidden" name="DOCID" value="<?php echo $due_Result['CRSE_DOC_DocID'] ;?>"/>
                                                                    <input type="submit" style="padding-left:2.6%;font-size:16px;padding-right:2.6%;padding:16%;margin-left:5%;margin-bottom:1.4%;margin-top:0.5%;border-radius:7%;" 
                                                                        class="btn btn-danger btn waves-effect waves-light mybtn" name="btnRemove" value="Remove">
                                                                </form>
                                                            </div>
                                                            <?php
                                                                if(isset($_POST['btnAsUpdate']))
                                                                {
                                                                    $as_DocID = $_POST['docid'];
                                                                    $as_Name = $_POST['a_Name'];
                                                                    $as_DueDate = $_POST['D_Date'];
                                                                    $as_DueTime = $_POST['D_Time'];
                                                                    $as_TotalPoints = $_POST['A_Points'];
                                                                    $as_IntWeightage = $_POST['Weightage_Points'];
                                                                    $as_Visibility = $_POST['Show_Hide'];

                                                                    $sql_mst_Update_QRY = "UPDATE Mtb_CourseDocs_New SET CRSE_DOC_DocName = '$as_Name',CRSE_DOC_Points = $as_TotalPoints, CRSE_DOC_Submission = now()
                                                                                            WHERE CRSE_DOC_DocID = $as_DocID";
                                                                    if(!mysqli_query($con,$sql_mst_Update_QRY))
                                                                    {
                                                                        echo 
                                                                        '<script>
                                                                            swal("Alert", "Some Error Occured. Operation Failed for Master table.", "warning");
                                                                        </script>
                                                                        ';
                                                                    }
                                                                    else
                                                                    {
                                                                        $transaction_Update_QRY = "UPDATE Tb_CourseDocTCHR SET CRSE_DOC_TCHR_DueDate = '$as_DueDate', CRSE_DOC_TCHR_DueTime = '$as_DueTime', CRSE_DOC_TCHR_Weightage = $as_IntWeightage,
                                                                                        CRSE_DOC_TCHR_DocVisibility = $as_Visibility WHERE CRSE_DOC_TCHR_DocID = $as_DocID";
                                                                        if(!mysqli_query($con,$transaction_Update_QRY))
                                                                        {
                                                                            echo 
                                                                            '<script> 
                                                                                swal("Alert", "Some Error Occured. Operation Failed for Transaction table.", "warning");
                                                                            </script>
                                                                            ';
                                                                        }
                                                                        else
                                                                        {
                                                                            echo 
                                                                            '<script>
                                                                                setTimeout(function(){
                                                                                    window.location.reload();
                                                                                }, 2000);  
                                                                                swal("Success", "Assessment Updated Successfully.", "success");
                                                                            </script>
                                                                            ';
                                                                        }
                                                                    }
                                                                }
                                                                if(isset($_POST['btnRemove']))
                                                                {
                                                                    $docID = $_POST['DOCID'];
                                                                    $dlt_QRY = "DELETE FROM Mtb_CourseDocs_new WHERE CRSE_DOC_DocID = $docID";
                                                                    if(!mysqli_query($con,$dlt_QRY))
                                                                    {
                                                                        echo 
                                                                        '<script> 
                                                                            swal("Alert", "Some error occured.\n Please try again.", "warning");
                                                                        </script>
                                                                        ';
                                                                    }
                                                                    else
                                                                    {
                                                                        echo 
                                                                        '<script> 
                                                                            swal("Success", "'.$type.' removed successfully.", "success");
                                                                            setTimeout(function () {
                                                                                history.go(-2);
                                                                            }, 2000);
                                                                        </script>
                                                                        ';
                                                                    }
                                                                }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <!-- Displaying Comments -->
                                <div class="card-block">
                                    <ul>
                                        <li>
                                            <div class="modal fade" id="viewComments" tabindex="-1" role="dialog" style="margin-left:0%;">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content" style="width:120%;">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" style="font-weight:bold;">Comments on <span id="user-id"></span> Submission</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div id='comment-body' style="padding:2%;margin:2% 1% 2% 1%;">
                                                            <!-- Displaying commment passed thorugh JS -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>