<?php
    session_start();
    error_reporting(0);

    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {  
        include("../COMMON_FILES/Connection.php");

        $program = $_POST['program'];
        $year = $_POST['year'];
        $PRGM = 0;

        // Server side validation
        if($program != "x" && $year != "x")
        {
            // For fetching student records based on Username allocated to them (i.e : 03, 02)
            // if($program == "BCA")
            // {
            //     $PRGM = 3;
            // }
            // else if($program == "MCA")
            // {
            //     $PRGM = 2;
            // }
            // // Just optional kept
            // else if($program == "IMCA")
            // {
            //     $PRGM = 5;
            // }
            $QRY = "SELECT UID,USR_ID,USR_FirstName,USR_LastName FROM Mtb_Users Where substring(USR_ID,2,4) = $year AND substring(USR_ID,6,3) = $program AND 
                    substring(USR_ID,1,1) = 'S'";
            $Data = mysqli_query($con,$QRY);
            // Checkbox for selecting all students at once
            echo "<span style='font-size:15px;font-weight:bold;'>Select All Students ? &nbsp;<input type='checkbox' id='CHK_all' onclick='all_CHK()'></span><br/><br/>";
            echo 
            "
                <table class='table table-striped' style='width:45%;border:1px solid rgba(0,0,0,.125);'>
                    <tr style='background-color:white;'>
                        <th style='width:17%;text-align:center;'>Select</th>
                        <th style='width:27%;padding-left:3%;'>Student ID</th>
                        <th style='padding-left:3%;width:40;'>Student Name</th>
                    </tr>
            ";
            while($result = mysqli_fetch_assoc($Data))
            {
                echo 
                "   <tr>
                        <td style='text-align:center;'>
                            <input type='checkbox' class='chk_Stud' style='margin-top:8%;' value='".$result['UID']."' name='chk_Stud[]'/>
                        </td>
                        <td style='padding-left:3%;'>".$result['USR_ID']."</td>
                        <td style='padding-left:3%;'>".$result['USR_FirstName']." ".$result['USR_LastName']."</td>
                    </tr>
                ";
            }
            echo "</table>";
        }
    }
    else
    {
        header('Location: ../COMMON_FILES/logout.php');
    }
?>
