<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");
        $cid = base64_decode($_GET['id']);
        $year = date("Y");
        include_once("../COMMON_FILES/course_info_method.php");

        $req_SQL = "SELECT PRGM_ID,CRSE_USR_Year,CRSE_USR_Sem FROM Tb_CourseUsers,Mtb_Programme,Mtb_Users WHERE PID = CRSE_USR_PID AND USR_ID = '".$_SESSION['Sess_USR_ID']."'
                    AND UID = CRSE_USR_UID AND CRSE_USR_Status = 1 AND CRSE_USR_CourseID = $cid";
        $req_Data = mysqli_query($con,$req_SQL);
        $req_Result = mysqli_fetch_assoc($req_Data);

        // Pie Assignment
        $PIE_assign_QRY = "SELECT sum(CRSE_DOC_TCHR_Weightage) as total FROM mtb_coursedocs_new,tb_coursedoctchr WHERE CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_Doc_Type LIKE 'Assignment%' 
                AND CRSE_DOC_CourseID = $cid AND CRSE_DOC_Year = '$year'";
        $PIE_assign_Data = mysqli_query($con,$PIE_assign_QRY);
        $PIE_assign_Result = mysqli_fetch_assoc($PIE_assign_Data);
        $PIE_assign_Result = $PIE_assign_Result['total'];

        // Pie Journal
        $PIE_journal_QRY = "SELECT sum(CRSE_DOC_TCHR_Weightage) as total FROM mtb_coursedocs_new,tb_coursedoctchr WHERE CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_Doc_Type LIKE 'Journal%' 
                AND CRSE_DOC_CourseID = $cid AND CRSE_DOC_Year = '$year'";
        $PIE_journal_Data = mysqli_query($con,$PIE_journal_QRY);
        $PIE_journal_Result = mysqli_fetch_assoc($PIE_journal_Data);
        $PIE_journal_Result = $PIE_journal_Result['total'];

         // Pie Other
         $PIE_Other_QRY = "SELECT sum(CRSE_DOC_TCHR_Weightage) as total FROM mtb_coursedocs_new,tb_coursedoctchr WHERE CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_Doc_Type LIKE 'Other%' 
         AND CRSE_DOC_CourseID = $cid AND CRSE_DOC_Year = '$year'";
        $PIE_Other_Data = mysqli_query($con,$PIE_Other_QRY);
        $PIE_Other_Result = mysqli_fetch_assoc($PIE_Other_Data);
        $PIE_Other_Result = $PIE_Other_Result['total'];

        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['s']==1)
        {
            echo 
            '<script> 
              swal("Success", "Assessment Uploaded Successfully.", "success");
            </script>
            ';
        }
        else if($_GET['s']==2)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While uploading File into Database.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==3)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While inserting values in description relation.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==4)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While inserting values of assessments availability & visibility in database.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==5)
        {
            echo 
            '<script> 
              swal("Info", "Assessment Upload Failed.\nSome Error Occured While inserting values in database.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==6)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While moving file to destination folder.!\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==7)
        {
            echo 
            '<script> 
              swal("Info", "File Size must be lesser than 5 MB.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==8)
        {
            echo 
            '<script> 
              swal("Info", "File Size must be greater than 20 KB.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==9)
        {
            echo 
            '<script> 
              swal("Info", "Invalid file format.\nAccepted formats are PDF & DOCX.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==10)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While Uploading File", "warning");
            </script>
            ';
        }
        else if($_GET['s']==11)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured. Assessment Upload Failed.", "warning");
            </script>
            ';
        }
?>
<html>
    <head>
        <title>LMS | Dashboard</title>
        <style>
            table tr,table,td {border:none!important;}
            .assess_tbl > th, td {
                padding:16px;
            }
            col-auto {
                font-size:18.5px;
            }
            .comp-card {
                border : 1px solid white;
                color:black;
            }
            .comp-card:hover {
                cursor:pointer;
                border: 1px solid rgba(81, 203, 238, 1);
            }
            .cnt-stud:hover,.custom-chart {
                border : 1px solid white!important;
            }
            ::-webkit-scrollbar {
                width:0px;
            }
        </style>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "course_info.php?id=<?php echo base64_encode($cid);?>");
            }
        </script>
        <link rel="stylesheet" type="text/css" href="../css/boxicons.min.css">
        <link rel="stylesheet" href="../css/radial.css" type="text/css" media="all">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:1%;min-height:54.5rem;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4 style="font-weight:bold;"><?php echo $cid." : ".$result['CRSE_Name'];?></h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                    <!-- Menu Hyperlink starts -->
                                    <div style="width:100%!important;margin-left:1%;">
                                        <div class="tab-content tabs-right-content card-block" style="width:100%;">
                                            <div class="tab-pane active show" id="menu1" role="tabpanel">
                                                <h4 style="font-weight:bold;margin-top:-2.5%;margin-bottom:2.6%;margin-left:-1.8%;">Course Dash</h4>
                                                <!-- Dashboard Starts -->
                                                <div style="display:flex;flex-wrap:wrap;margin-left:-3%;margin-bottom:-2.1%;">
                                                    <div class="col-xl-4 col-md-12">
                                                        <div class="card comp-card custom-chart" style="cursor:auto;">
                                                            <div class="card-body">
                                                                <div class="row align-items-left">
                                                                    <div class="col">
                                                                        <h6 class="m-b-0">
                                                                            <span style="font-weight:bold;">Internal Evaluation out of 40 marks</span><br/><br/>
                                                                            Evaluated : <?php echo $PIE_assign_Result+$PIE_journal_Result+$PIE_Other_Result." marks";?>
                                                                            <br/>
                                                                            Remaining : <?php echo 40-($PIE_assign_Result+$PIE_journal_Result+$PIE_Other_Result)." marks";?>
                                                                        </h6>
                                                                    </div>
                                                                    <div style="margin-top:0%;margin-left:-1%;overflow:hidden;">
                                                                        <script type="text/javascript" src="../js/google_loader.js"></script>
                                                                        <script type="text/javascript">
                                                                            google.charts.load("current", {packages:["corechart"]});
                                                                            google.charts.setOnLoadCallback(drawChart);
                                                                            function drawChart() {
                                                                                var data = google.visualization.arrayToDataTable([
                                                                                ['Assessment Type', 'Weightage'],
                                                                                ['Assignment', <?php if($PIE_assign_Result) echo $PIE_assign_Result; else echo 0;?>],
                                                                                ['Journal', <?php if($PIE_journal_Result) echo $PIE_journal_Result; else echo 0;?>],
                                                                                ['Other', <?php if($PIE_Other_Result) echo $PIE_Other_Result; else echo 0;?>]
                                                                                ]);

                                                                                var options = {
                                                                                // title: 'Internal Evaluation',
                                                                               pieHole: 0.5,
                                                                                };

                                                                                var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
                                                                                chart.draw(data, options);
                                                                            }
                                                                        </script>
                                                                        <div id="donutchart" style="width:600px;height:25rem;margin-left:-15%;margin-top:-15%;margin-bottom:-15%;"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                        <a href="assessment.php?id=<?php echo base64_encode($cid);?>&type=<?php echo base64_encode("Assignment");?>">
                                                            <div class="card comp-card" style="height:11.4rem;">
                                                                <div class="card-body">
                                                                    <div class="row align-items-center">
                                                                        <div class="col">
                                                                            <h6 class="m-b-40"><span style="font-weight:bold;">Total Assignments</span></h6>
                                                                            <h3 class="f-w-700 text-c-blue"><?php echo $assign_CNT['total']; ?></h3>
                                                                            <br/>
                                                                            <p class="m-b-0">assigned by you to students</p>
                                                                        </div>
                                                                        <div class="col-auto">
                                                                            <i class="fa fa-file-pdf-o bg-c-blue"></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    <!-- </div>
                                                    <div class="col-xl-4 col-md-12"> -->
                                                    <a href="assessment.php?id=<?php echo base64_encode($cid);?>&type=<?php echo base64_encode("Other");?>">
                                                        <div class="card comp-card" style="height:11.4rem;">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-40"><span style="font-weight:bold;">Total Other Files</span></h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $other_CNT['total']; ?></h3>
                                                                        <br/>
                                                                        <p class="m-b-0">uploaded</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-word-o bg-c-red"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    </div>
                                                <a href="assessment.php?id=<?php echo base64_encode($cid);?>&type=<?php echo base64_encode("Journal");?>">
                                                    <div class="col-xl-4 col-md-12">
                                                        <div class="card comp-card" style="height:11.4rem;">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-40"><span style="font-weight:bold;">Total Journals</span></h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $journal_CNT['total']; ?></h3>
                                                                        <br/>
                                                                        <p class="m-b-0">allocated to students</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-code bg-c-yellow"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                </a>
                                                    <!-- </div>
                                                    <div class="col-xl-4 col-md-12"> -->
                                                <a href="assessment.php?id=<?php echo base64_encode($cid);?>&type=<?php echo base64_encode("Homework");?>">
                                                        <div class="card comp-card" style="height:11.4rem;">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-40"><span style="font-weight:bold;">Total Homework</span></h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $homewrk_CNT['total']; ?></h3>
                                                                        <br/>
                                                                        <p class="m-b-0">assigned</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-text-o bg-c-blue"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                                <div class="col-xl-4 col-md-12 m-t-15">
                                                    <a href="assessment.php?id=<?php echo base64_encode($cid);?>&type=<?php echo base64_encode("Material");?>" style="margin-bottom:-5%;">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-40"><span style="font-weight:bold;">Total Materials</span></h6>
                                                                        <h3 class="f-w-700 text-c-blue"><?php echo $material_CNT['total']; ?></h3>
                                                                        <br/>
                                                                        <p class="m-b-0">Materials uploaded</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-archive-o bg-c-blue"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                                <div class="col-xl-4 col-md-12 m-t-15">
                                                    <div class="card comp-card cnt-stud" style="cursor:auto;">
                                                        <div class="card-body">
                                                            <div class="row align-items-center">
                                                                <div class="col">
                                                                    <h6 class="m-b-40"><span style="font-weight:bold;">Total Students</span></h6>
                                                                    <h3 class="f-w-700 text-c-blue"><?php echo $stud_CNT; ?></h3>
                                                                    <br/>
                                                                    <p class="m-b-0">Enrolled in Course</p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <i class="fas fa-users bg-c-green"></i>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                                <!-- Dashboard Ends -->
                                            </div>
                                            <div class="tab-pane" id="menu2" role="tabpanel">
                                                <!-- Assessment Form -->
                                                <div style="min-height:44.45rem;margin-bottom: -1.6%;">
                                                    <!-- Form Starts -->
                                                    <form method="POST" action="course_info_DB.php" enctype="Multipart/form-data">

                                                        <input type="hidden" name ="cid" value="<?php echo $cid; ?>"/>
                                                        <input type="hidden" name ="pid" value="<?php echo $req_Result['PRGM_ID']; ?>"/>
                                                        <input type="hidden" name ="year" value="<?php echo $req_Result['CRSE_USR_Year'];; ?>"/>
                                                        <input type="hidden" name ="sem" value="<?php echo $req_Result['CRSE_USR_Sem']; ?>"/>
                                                    <table id="base-style" class="assess_tbl" style="width:89%;margin-left:-2%;font-size:18px;margin-top:-3.3%;margin-bottom:-4%;" class="table table-striped table-bordered nowrap tableViewProgram">
                                                        <thead>
                                                            <tr>
                                                                <td colspan="2" style="font-weight:bold;margin-bottom:1%;">New Assessment</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:550;">Assessment Name : </td>
                                                                <td><input type="text" name="a_Name" style="margin-top:-0.5%;font-size:20px; border: 1px solid rgba(113,113,113);width:50%;" autocomplete="off" required/></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:550;">Assessment Type : </td>
                                                                <td>
                                                                    Assignment <input type="radio" name="ASType" value="Assignment" required /> &nbsp;&nbsp;&nbsp;
                                                                    HomeWork <input type="radio" name="ASType" value="Homework"/> &nbsp;&nbsp;&nbsp;
                                                                    Journal <input type="radio" name="ASType" value="Journal"/> &nbsp;&nbsp;&nbsp;
                                                                    Material <input type="radio" name="ASType" value="Material"/> &nbsp;&nbsp;&nbsp;
                                                                    Other <input type="radio" name="ASType" value="Other" />
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:550;">Available From : </td>
                                                                <td><input type="date" name="A_Date" style="width:24%;" required/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="time" name="A_Time" style="width:24%;" required/></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:550;">Due Event : </td>
                                                                <td><input type="date" name="D_Date" style="width:24%;" required/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="time" name="D_Time"  style="width:24%;" required/></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:550;">Description/Instructions : </td>
                                                                <td>
                                                                    <textarea  style="width:70.5%;height:8.5rem;" name="A_Desc" required></textarea>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:550;">Upload File : </td>
                                                                <td><input type="file" name="A_Upload"/></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:550;">Total Points : </td>
                                                                <td>
                                                                    <input type="number" placeholder="Total Points" name="A_Points" min="0" style="width:15%;" pattern="[0-9]{0,}"/>
                                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                                    Internal Weightage : &nbsp;&nbsp;<input type="number" step="any" placeholder="Points" name="Weightage_Points" min="0" style="width:14%;" pattern="[0-9]{0,}"/>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:550;">Visibility on Student Panel : </td>
                                                                <td>
                                                                    Visible <input type="radio" name="Show_Hide" value="1" checked/>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                    Hidden <input type="radio" name="Show_Hide" value="0" />
                                                                </td>
                                                            </tr>
                                                            <tr style="display:flex;">
                                                                <td style="height:3rem;" colspan="2">
                                                                    <input type="submit" class="btn btn-primary waves-effect" id="submit" style="width:max-content;font-size:15px;height:2.5rem;
                                                                           padding-bottom:18%; " name="btnSubmit" value="Submit" />
                                                                    &nbsp;
                                                                    <input type="reset" class="btn btn-primary waves-effect" id="reset" style="width:max-content;font-size:16px;height:2.5rem;
                                                                             padding-bottom:18%;" value="Reset" />
                                                                </td>
                                                            </tr>
                                                        </thead>
                                                    </table>
                                                    </form>
                                                    <!-- Form Ends -->
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="students" role="tabpanel" style="background-lightgreen!important;margin-top:-3%;min-height:42.8rem;margin-left:-2%;minwidth:105%;">
                                                <div class="dt-responsive table-responsive tableView">
                                                    <h5 style="margin-top:-1%;margin-bottom:2%;margin-left:-2%;font-weight:bold;">Enrolled Students :</h5>
                                                    <table id="base-style" style="width:100%;margin-left:-2%;" class="table table-striped table-bordered nowrap tableViewProgram">
                                                        <thead>
                                                            <tr>
                                                            <th style="width:10%;border-left:none;">Sr No</th>
                                                            <th style="width:17%;">Student ID</th>
                                                            <th style="width:23%;">Student Name</th>
                                                            <th style="width:20%;">Contact No.</th>
                                                            <th style="width:25%;border-right:none;">Email ID</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php
                                                            $cnt=1;
                                                            $flag = false;
                                                            while ($res = mysqli_fetch_assoc($stud_Data)) 
                                                            {
                                                                $flag = true;
                                                        ?>  
                                                                <tr class="RowHeight" style="border:none;">
                                                                    <td ><?php echo $cnt; ?></td>
                                                                    <td ><?php echo $res['USR_ID'];?></td>
                                                                    <td ><?php echo $res['USR_FirstName']." ".$res['USR_LastName'];?></td>
                                                                    <td><?php echo $res['USR_ContactNo'];?></td>
                                                                    <td><?php echo $res['USR_EmailID'];?></td>
                                                                </tr>
                                                            <?php
                                                                $cnt++;
                                                                }
                                                                if(!$flag)
                                                                {
                                                                    echo "<tr><td colspan='5'>No students are being enrolled in this course</td></tr>";
                                                                }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <!-- <div class="tab-pane" id="menu4" role="tabpanel">
                                                <p>
                                                    Work in Progress
                                                </p>
                                            </div> -->
                                        </div>
                                        <!-- Tab Menu -->
                                        <ul class="nav nav-tabs md-tabs tabs-right b-none" role="tablist" 
                                            style="font-weight:bold;border-left: 1px solid grey;overflow:hidden;">
                                            <li class="nav-item">
                                            <a class="nav-link active show" data-toggle="tab" href="#menu1" role="tab" aria-selected="true">Dashboard</a>
                                            <div class="slide"></div>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#menu2" role="tab" aria-selected="false">Assessment</a>
                                                <div class="slide"></div>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#students" role="tab" aria-selected="false">Students</a>
                                                <div class="slide"></div>
                                            </li>
                                            <!-- <li class="nav-item">
                                                <a class="nav-link" data-toggle="tab" href="#menu4" role="tab" aria-selected="false">Material</a>
                                                <div class="slide"></div>
                                            </li> -->
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>