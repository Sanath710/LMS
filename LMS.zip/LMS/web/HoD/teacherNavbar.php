<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="H" || substr($_SESSION['Sess_USR_Role'],0,1)=="T")
  {  
    include_once("../COMMON_FILES/Connection.php");
    $sql_Pic = "SELECT USR_Pic FROM Mtb_Users WHERE USR_ID='".$_SESSION['Sess_USR_ID']."'";
    $data_Pic =  mysqli_query($con,$sql_Pic);
    $res_Pic = mysqli_fetch_assoc($data_Pic);
?>
<html lang="en">
  <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
  <head>
    <!-- To avoid report name change -->
    <!-- <title>Admin Navbar</title>  -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="Sanath" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="../css/waves.min.css" type="text/css" media="all"> -->
    <link rel="stylesheet" type="text/css" href="../css/feather.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome-n.min.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/chartist.css" type="text/css" media="all">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" type="text/css" href="../css/widget.css">
    <style>
    .header-navbar {
      min-height: 60px!important;
    }
    </style>
  </head>

  <body>
    <!-- Loader -->
    <div class="loader-bg">
      <div class="loader-bar"></div>
      <!-- <div style="text-align:center;margin-left:6%;margin-top:20%;"><img src="../gif/loader.gif" style="width:25%;height:10rem;"/></div> -->
    </div>
    <div id="pcoded" class="pcoded">
      <!-- <div class="pcoded-overlay-box"></div> -->
      <div class="pcoded-container navbar-wrapper">
        <!-- Top Navbar Starts -->
        <nav class="navbar header-navbar pcoded-header" style="height:0rem;">
          <div class="navbar-wrapper">
            <!-- Hamburger Menu Starts -->
            <div class="navbar-logo">
              <a href="#" class="logo" id="mobile-collapse">
                  LMS&nbsp;
                  <i class="fa fa-bars" aria-hidden="true"></i>
              </a>
          </div>
          <!-- Hamburger Menu ENDS -->
            <div class="navbar-container container-fluid">
              <ul class="nav-right"style="margin-top:-0.3%;">
                <li class="user-profile header-notification">
                  <div class="dropdown-primary dropdown">
                    <div class="dropdown-toggle" data-toggle="dropdown">
                      <img src="../<?php echo $res_Pic['USR_Pic']; ?>" class="img-radius" alt="User-Profile-Image">
                      <span><?php echo $_SESSION['Sess_USR_Name']; ?></span>
                      <i class="feather icon-chevron-down"></i>
                    </div>
                    <ul class="show-notification profile-notification dropdown-menu" data-dropdown-in="fadeIn"
                      data-dropdown-out="fadeOut">
                      <li>
                        <a href="#!">
                          <i class="feather icon-settings"></i> Settings
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i class="feather icon-user"></i> Profile
                        </a>
                      </li>
                      <li>
                        <a href="#!" onclick="if (!window.__cfRLUnblockHandlers) return false; javascript:toggleFullScreen()" class="waves-effect waves-light">
                          <i class="full-screen feather icon-maximize"></i>&nbsp;Switch to Full Screen
                        </a>
                      </li>
                      <li>
                        <a href="email-inbox.html">
                          <i class="feather icon-mail"></i> My Messages
                        </a>
                      </li>
                      <!-- <li>
                        <a href="auth-lock-screen.html">
                          <i class="feather icon-lock"></i> Lock Screen
                        </a>
                      </li> -->
                      <li>
                        <a href="../COMMON_FILES/logout.php">
                          <i class="feather icon-log-out"></i> Logout
                        </a>
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </nav>
  <!-- Top Navbar Ends -->
        <div class="pcoded-main-container">
          <div class="pcoded-wrapper">
            <!-- Side Navbar starts -->
            <nav class="pcoded-navbar">
              <div class="nav-list">
                <!-- Main Sidebar Menu Starts-->
                <?php
                if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
                {
                  // Dashboard For HoD
                  echo'<div class="pcoded-inner-navbar main-menu">
                    <div class="pcoded-navigation-label">Quick Links</div>
                    <!-- Seperator Dashbord Starts-->
                    <div class="pcoded-navigation-label"> Dashboard </div>
                    <ul class="pcoded-item pcoded-left-item">
                      <li class="">
                        <a href="../HoD/dashboard.php" class="waves-effect waves-dark">
                          <span class="pcoded-micon">
                            <i class="fa fa-th-large" aria-hidden="true"></i>
                          </span>
                          <span class="pcoded-mtext">Dashboard</span>
                        </a>
                      </li>
                    </ul>';
                  // Seperator Dashbord Ends
                  // Seperator Program Starts
                  echo '<div class="pcoded-navigation-label">Programs</div>
                  <ul class="pcoded-item pcoded-left-item">
                    <li class="pcoded-hasmenu ">
                      <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                          <i class="fa fa-book" aria-hidden="true"></i>
                        </span>
                        <span class="pcoded-mtext">Programme</span>
                      </a>
                      <ul class="pcoded-submenu">
                        <!-- <li class="">
                          <a href="newProgram.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">New Programme</span>
                          </a>
                        </li> -->
                        <li class="">
                          <a href="../HoD/viewPrograms.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">View Programs</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>';
                  // Seperator Program Ends
                  // Seperator Course Starts
                  echo'<div class="pcoded-navigation-label">Courses</div>
                  <ul class="pcoded-item pcoded-left-item">
                    <li class="pcoded-hasmenu ">
                      <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                          <!-- <i class="fa fa-list" aria-hidden="true"></i> -->
                          <i class="fa fa-tasks"></i>
                        </span>
                        <span class="pcoded-mtext">Course</span>
                      </a>
                      <ul class="pcoded-submenu">
                        <li class="">
                          <a href="../HoD/viewCourses.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">View Courses</span>
                          </a>
                        </li>
                        <li class="">
                          <a href="../HoD/viewCourseTeacher.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">Course Teachers</span>
                          </a>
                        </li>
                        <li class="">
                          <a href="../Teacher/enrollStudents.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">Manage Students</span>
                          </a>
                        </li>
                        <li class="">
                          <a href="../HoD/deactivateSemester.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">Semester Lockdown</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>';
                  // Seperator Course Ends
                   // Seperator User Starts
                   echo '<div class="pcoded-navigation-label">Users</div>
                   <ul class="pcoded-item pcoded-left-item">
                     <li class="pcoded-hasmenu ">
                       <a href="javascript:void(0)" class="waves-effect waves-dark">
                         <span class="pcoded-micon">
                           <i class="fa fa-users" aria-hidden="true"></i>
                         </span>
                         <span class="pcoded-mtext">Users</span>
                       </a>
                       <ul class="pcoded-submenu">
                         <!-- <li class="">
                           <a href="enrollUser.php" class="waves-effect waves-dark">
                             <span class="pcoded-mtext">Enroll User</span>
                           </a>
                         </li> -->
                         <!-- <li class="">
                           <a href="../HoD/viewUsers.php" class="waves-effect waves-dark">
                             <span class="pcoded-mtext">View Users</span>
                           </a>
                         </li> -->
                         <li class="">
                           <a href="../admin/viewUsers.php" class="waves-effect waves-dark">
                             <span class="pcoded-mtext">View Users</span>
                           </a>
                         </li>
                       </ul>
                     </li>
                   </ul>';
                 // Seperator User Ends
                  // Seperator Assessment Starts
                  // echo'<div class="pcoded-navigation-label">Assessment</div>
                  // <ul class="pcoded-item pcoded-left-item">
                  //   <li class="pcoded-hasmenu ">
                  //     <a href="javascript:void(0)" class="waves-effect waves-dark">
                  //       <span class="pcoded-micon">
                  //         <i class="fa fa-list-alt" aria-hidden="true"></i>
                  //       </span>
                  //       <span class="pcoded-mtext">Assessment</span>
                  //     </a>
                  //     <ul class="pcoded-submenu">
                  //       <li class="">
                  //         <a href="../Teacher/newAssessment.php" class="waves-effect waves-dark">
                  //           <span class="pcoded-mtext">New Assessment</span>
                  //         </a>
                  //       </li>
                  //       <li class="">
                  //         <a href="" class="waves-effect waves-dark">
                  //           <span class="pcoded-mtext">View Assessment</span>
                  //         </a>
                  //       </li>
                  //     </ul>
                  //   </li>
                  // </ul>';
                  // Seperator Assessment Ends
                  // Seperator Schedule Starts 
                  echo'<div class="pcoded-navigation-label">Schedule</div>
                  <ul class="pcoded-item pcoded-left-item">
                    <li class="pcoded-hasmenu ">
                      <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                          <i class="fa fa-list-alt" aria-hidden="true"></i>
                        </span>
                        <span class="pcoded-mtext">Schedule</span>
                      </a>
                      <ul class="pcoded-submenu">
                        <li class="">
                          <a href="../admin/newSchedule.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">New Schedule</span>
                          </a>
                        </li>
                        <li class="">
                          <a href="../admin/viewSchedule.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">View Schedule</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>';
                  // Seperator Schedule Ends
                  // Report Menu For HoD
                  echo' <div class="pcoded-navigation-label">Reports</div>
                    <ul class="pcoded-item pcoded-left-item">
                      <li class="pcoded-hasmenu ">
                        <a href="javascript:void(0)" class="waves-effect waves-dark">
                          <span class="pcoded-micon">
                          <i class="fa fa-file-text-o"></i>
                          </span>
                          <span class="pcoded-mtext">Reports</span>
                        </a>
                        <ul class="pcoded-submenu">
                        <!--<li class="">
                            <a href="../HoD/submissionReport.php" class="waves-effect waves-dark">
                              <span class="pcoded-mtext">Individual Assessment</span>
                            </a>
                          </li>-->
                          <li class="">
                            <a href="../HoD/assessmentReport.php" class="waves-effect waves-dark">
                              <span class="pcoded-mtext">Overall Assessment</span>
                            </a>
                          </li>
                    ';
                          // <li class="">
                          //   <a href="../HoD/studentEvaluationReport.php" class="waves-effect waves-dark">
                          //     <span class="pcoded-mtext">Student Evaluation Report</span>
                          //   </a>
                          // </li>
                          // <li class="">
                          //   <a href="../HoD/viewGradeSheet.php" class="waves-effect waves-dark">
                          //     <span class="pcoded-mtext">Grade Sheet</span>
                          //   </a>
                          // </li>
                  echo'
                        </ul>
                      </li>
                    </ul>';
                }
                else if(substr($_SESSION['Sess_USR_Role'],0,1)=="T")
                {
                  // Dashboard for Teacher
                  echo'<div class="pcoded-inner-navbar main-menu">
                  <div class="pcoded-navigation-label">Quick Links</div>
                  <!-- Seperator Dashbord Starts-->
                  <div class="pcoded-navigation-label"> Dashboard </div>
                  <ul class="pcoded-item pcoded-left-item">
                    <li class="">
                      <a href="../Teacher/dashboard.php" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                          <i class="fa fa-th-large" aria-hidden="true"></i>
                        </span>
                        <span class="pcoded-mtext">Dashboard</span>
                      </a>
                    </li>
                  </ul>';
                  // Course Menu For Teacher
                  echo'
                  <div class="pcoded-navigation-label">Courses</div>
                  <ul class="pcoded-item pcoded-left-item">
                    <li class="pcoded-hasmenu ">
                      <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                          <!-- <i class="fa fa-list" aria-hidden="true"></i> -->
                          <i class="fa fa-tasks"></i>
                        </span>
                        <span class="pcoded-mtext">Course</span>
                      </a>
                      <ul class="pcoded-submenu">';
                        // <li class="">
                        //   <a href="" class="waves-effect waves-dark">
                        //     <span class="pcoded-mtext">View Course</span>
                        //   </a>
                        // </li>
                  echo'      <li class="">
                          <a href="../Teacher/enrollStudents.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">Enroll Students</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>';
                // Schedule Menu For Teacher
                echo' <div class="pcoded-navigation-label">Schedule</div>
                  <ul class="pcoded-item pcoded-left-item">
                    <li class="pcoded-hasmenu ">
                      <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                          <i class="fa fa-list-alt" aria-hidden="true"></i>
                        </span>
                        <span class="pcoded-mtext">Schedule</span>
                      </a>
                      <ul class="pcoded-submenu">
                        <li class="">
                          <a href="../Teacher/viewSchedule.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">View Schedule</span>
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>';
                // Report Menu For Teacher
                echo' <div class="pcoded-navigation-label">Reports</div>
                  <ul class="pcoded-item pcoded-left-item">
                    <li class="pcoded-hasmenu ">
                      <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon">
                        <i class="fa fa-file-text-o"></i>
                        </span>
                        <span class="pcoded-mtext">Reports</span>
                      </a>
                      <ul class="pcoded-submenu">
                      <!--  <li class="">
                          <a href="../Teacher/submissionReport.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">Individual Assessment</span>
                          </a>
                        </li> -->
                        <li class="">
                          <a href="../Teacher/assessmentReport.php" class="waves-effect waves-dark">
                            <span class="pcoded-mtext">Overall Assessment</span>
                          </a>
                        </li>
                        <!--<li class="">
                            <a href="" class="waves-effect waves-dark">
                              <span class="pcoded-mtext">Grade Sheet</span>
                            </a>
                          </li>-->
                      </ul>
                    </li>
                  </ul>';
                }
                ?>
                <!-- Seperator Program Ends-->
                </div>
              </div>
            </nav>
  <!-- Side Navbar Ends -->

    <script data-cfasync="false" src="js/email-decode.min.js"></script>
    <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="../js/jquery.min.js"></script>
    <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="../js/jquery-ui.min.js"></script>
    <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="../js/popper.min.js"></script>
    <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="../js/bootstrap.min.js"></script>
    <script src="../js/waves.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="../js/jquery.slimscroll.js"></script>
    <script src="../js/jquery.flot.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/jquery.flot.categories.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/curvedlines.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/jquery.flot.tooltip.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/chartist.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/amcharts.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/serial.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/light.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/pcoded.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script src="../js/vertical-layout.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="../js/custom-dashboard.min.js"></script>
    <script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="../js/script.min.js"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"
      type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
    <script type="d2d1d6e2f87cbebdf4013b26-text/javascript">
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-23581568-13');
    </script>
    <script src="../js/rocket-loader.min.js" data-cf-settings="d2d1d6e2f87cbebdf4013b26-|49" defer=""></script>
  </body>
</html>
<?php
    }
    else
    {
        header('Location: ../COMMON_FILES/logout.php');
    }
?>