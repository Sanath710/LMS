<?php
  session_start();
  error_reporting(0);
?>
<html>
    <head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <style>
      body
      {
        height: 100%;
        background-repeat: no-repeat; 
        background-image: linear-gradient(rgb(100, 65, 236),rgb(99, 130, 177));
        position: relative;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div id="login-box">
        <div class="controls">
          <form action="" method="POST">
            <div class="login_Form_Title">Welcome to <br/><b style="font-size:23px;">"Learning Management System"</b><br/><br/>Please Provide Username</div>
            <span class="UserName">Username<br/></span>
            <input type="text" name="user_Name" placeholder="Enter Username" pattern="[A-Z]{1,}[0-9]{10}" title="Enter Correct Username" required autocomplete="off" 
                  style="font-size:20px;border:3px solid white;padding-left:0.5%;" class="form-control usernameInp" />
            <hr/>
            <br/>
            <input type="Submit" value="Next" name="btn_Login" style="font-size:18px;" class="btn btn-primary btnLOGIN"/>
          </form>
          <?php
              if(isset($_POST['btn_Login']))
              {
                  include("Connection.php");
                  $username = strtoupper($_POST['user_Name']);
                  $query = "SELECT USR_ID,USR_Role,USR_FirstName,USR_LastName FROM Mtb_Users WHERE UPPER(USR_ID) = '$username'";
                  $data = mysqli_query($con,$query);
                  $total = mysqli_num_rows($data);
                  $result = mysqli_fetch_assoc($data);
                  if($total==1)
                  {
                    $uName = $result['USR_FirstName']." ".$result['USR_LastName'];
                    $_SESSION['Sess_USR_Name']=$uName;
                    $_SESSION['Sess_USR_ID']=$username;
                    $_SESSION['Sess_USR_Role']=$result['USR_Role'];
                    header("Location: loginPass.php");
                    // echo '<script type="text/javascript"> location.replace("admin_Navbar.php"); </script>';
                  }
                  else
                  {
                      unset($_SESSION['USR_ID']);
                      echo '<p style="color:red">No User Found</p>';
                  }
              }
          ?>
        </div>
      </div>
    </div>
    <div id="particles-js"></div>
    <script>
        if ( window.history.replaceState ) 
        {
          window.history.replaceState( null, null, "login.php");
        }
        $.getScript("../js/particles.min.js", function(){
        particlesJS('particles-js',
          {
            "particles": {
              "number": {
                "value": 85,
                "density": {
                  "enable": true,
                  "value_area": 900
                }
              },
              "color": {
                "value": "#ffffff"
              },
              "shape": {
                "type": "circle",
                "stroke": {
                  "width": 1,
                  "color": "green"
                },
                "polygon": {
                  "nb_sides": 10
                },
                "image": {
                  "width": 10,
                  "height": 100
                }
              },
              "opacity": {
                "value": 0.8,
                "random": false,
                "anim": {
                  "enable": false,
                  "speed": 0.2,
                  "opacity_min": 0.1,
                  "sync": false
                }
              },
              "size": {
                "value": 5,
                "random": true,
                "anim": {
                  "enable": false,
                  "speed": 40,
                  "size_min": 0.1,
                  "sync": false
                }
              },
              "line_linked": {
                "enable": true,
                "distance": 110,
                "color": "#ffffff",
                "opacity": 0.4,
                "width": 3
              },
              "move": {
                "enable": true,
                "speed": 0.8,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "attract": {
                  "enable": false,
                  "rotateX": 600,
                  "rotateY": 1200
                }
              }
            },
            "interactivity": {
              "detect_on": "canvas",
              "events": {
                "onhover": {
                  "enable": true,
                  "mode": "repulse"
                },
                "onclick": {
                  "enable": true,
                  "mode": "push"
                },
                "resize": true
              },
              "modes": {
                "grab": {
                  "distance": 400,
                  "line_linked": {
                    "opacity": 1
                  }
                },
                "bubble": {
                  "distance": 400,
                  "size": 40,
                  "duration": 2,
                  "opacity": 8,
                  "speed": 3
                },
                "repulse": {
                  "distance": 200
                },
                "push": {
                  "particles_nb": 4
                },
                "remove": {
                  "particles_nb": 2
                }
              }
            },
            "retina_detect": true,
            "config_demo": {
              "hide_card": false,
              "background_color": "green",
              "background_image": "",
              "background_position": "50% 50%",
              "background_repeat": "no-repeat",
              "background_size": "cover"
            }
          }
        );

    });

    </script>
    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script> -->
  </body>
</html>