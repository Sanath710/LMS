<?php
    try 
    {
        $con=mysqli_connect("localhost","root","","db_lms") or die("Connection Failed");
    }
    catch (Exception $e)
    {
        echo ("Database Connectivity Failed.");
    }

?>