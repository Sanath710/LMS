<?php
    session_start();
    error_reporting(0);
    $flag = false;
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {   
        include_once("../admin/adminNavbar.php");
        $flag = true;
    }
    else if ((substr($_SESSION['Sess_USR_Role'],0,1)=="H") || (substr($_SESSION['Sess_USR_Role'],0,1)=="T"))
    {
        include_once("../HoD/teacherNavbar.php");
        $flag = true;
    }
    else if (substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {
        include_once("../Student/studentNavbar.php");
        $flag = true;
    }
    if($flag)
    {
?>
<html lang="en">
    <head>
        <script>
            if(window.history.replaceState) 
            {
                window.history.replaceState( null, null, "profile.php");
            }
        </script>
        <script src="../COMMON_FILES/sweetalert.min.js"></script>
        <style>
            input 
            {
                /* border:none; */
                padding:0%;
                outline:none;
                font-size:inherit;
                cursor:pointer;
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="main-body">
                <div class="page-wrapper subBodyProgram">
                    <div class="page-body">
                        <div class="card bodyStyling">
                            <div class="card-header" style="margin-top:0.5%;">
                                <h4 style="font-weight:bold;">Profile</h4><hr style="width:97.8%; margin-left:0%;"/>
                            </div>
                            <div class="card-block" style="padding-left:2%;display:flex;margin-top:1%;">
                                <br/>
                                <div class="col-md-3">
                                    <div class="card user-card" style="margin-top:5%;height:25.9rem;margin-bottom:0%;">
                                        <div class="card-block" >
                                            <div style="width:100%;"> <!-- class="user-image"  for blue border-->
                                                <img src="../<?php echo $res_Pic['USR_Pic']; ?>" style="height:10rem;" class="img-radius"alt="User-Profile-Image">
                                                <!-- <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-radius"alt="User-Profile-Image"> -->
                                            </div>
                                            <!-- <h6 class="f-w-600 m-t-25 m-b-10"><?php echo $result['USR_FirstName']." ".$result['USR_LastName']; ?></h6> -->
                                            <br/>
                                            <p> User ID : &nbsp;<?php echo $_SESSION['Sess_USR_ID']; ?></p>
                                            <hr/>
                                            <div class="bg-c-blue counter-block m-t-10 p-10">
                                                <div class="row">
                                                    <!-- <div class="col-4">
                                                        <i class="fa fa-comment"></i>
                                                        <p>1256</p>
                                                    </div>
                                                    <div class="col-4">
                                                        <i class="fa fa-user"></i>
                                                        <p>8562</p>
                                                    </div>
                                                    <div class="col-4">
                                                        <i class="fa fa-suitcase"></i>
                                                        <p>189</p>
                                                    </div> -->
                                                    <span style="margin-left:26.8%;cursor:pointer;">Upload Profile Picture</span>
                                                </div>
                                            </div>
                                            <div class="bg-c-blue counter-block m-t-15 p-10" style="width:40%;">
                                                <span style="margin-left:2%;cursor:pointer;">Edit Profile</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <div style="margin-top:1%;margin-left:1.5%;">
                                <fieldset class="border p-2" style="padding-left:2%!important;">
                                    <legend  style="font-size:18px;font-weight:bold;">&nbsp;User Details</legend>
                                    <div style="width:69.5rem; font-size:18px;margin-top:2%;">
                                        First Name : &nbsp; <input type="text" style="margin-left:0.4%;" value="" readonly/><br/><br/>
                                        Last Name : &nbsp;<input type="text" style="margin-left:1%;" value="" readonly/><br/><br/>
                                        Gender :  &nbsp;<br/><br/>
                                        Email ID :  &nbsp;<input type="text" style="margin-left:2.8%;width:30%;" value="" readonly/><br/><br/>
                                        Contact No. : &nbsp;<input type="text" value="" readonly/><br/><br/>
                                        Aadhar No. : &nbsp;<input type="text" style="margin-left:0.3%;value="" readonly/><br/><br/>
                                    </div>
                                </fieldset>
                            </div>
                        </div>
                        <div style="border:1px solid #e9ecef!important;margin-left:2.8%;margin-right:3.4%;height:17.3rem;margin-bottom:2%;">highlight_file
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>