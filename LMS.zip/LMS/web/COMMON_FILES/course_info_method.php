<?php
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
            $sql = "SELECT CRSE_Name FROM Mtb_Courses WHERE CRSE_ID = $cid";
            $data = mysqli_query($con,$sql);
            $result = mysqli_fetch_assoc($data);

            $stud_QRY = "SELECT USR_ID,USR_FirstName,USR_LastName,USR_ContactNo,USR_EmailID FROM Mtb_Users,Tb_CourseUsers
                        WHERE UID = CRSE_USR_UID AND CRSE_USR_CourseID = $cid AND substring(USR_ID,1,1) = 'S' AND CRSE_USR_Status = 1";
            $stud_Data = mysqli_query($con,$stud_QRY);
            $stud_CNT = mysqli_num_rows($stud_Data);

            $date = date("Y");

            $assign_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_Doc_CourseID = $cid 
                        AND CRSE_Doc_Year = $date AND CRSE_DOC_Type LIKE 'Assignment%' AND CRSE_Doc_USR_ID = '".$_SESSION['Sess_USR_ID']."'";
            $assign_Data = mysqli_query($con,$assign_QRY);
            $assign_CNT = mysqli_fetch_assoc($assign_Data);

            $material_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_Doc_CourseID = $cid 
                        AND CRSE_Doc_Year = $date AND CRSE_DOC_Type LIKE 'Material%'";
            $material_Data = mysqli_query($con,$material_QRY);
            $material_CNT = mysqli_fetch_assoc($material_Data);

            $homewrk_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_Doc_CourseID = $cid 
                        AND CRSE_Doc_Year = $date AND CRSE_DOC_Type LIKE 'Homework%'";
            $homewrk_Data = mysqli_query($con,$homewrk_QRY);
            $homewrk_CNT = mysqli_fetch_assoc($homewrk_Data);

            $journal_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_Doc_CourseID = $cid 
                        AND CRSE_Doc_Year = $date AND CRSE_DOC_Type LIKE 'Journal%' AND CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."'";
            $journal_Data = mysqli_query($con,$journal_QRY);
            $journal_CNT = mysqli_fetch_assoc($journal_Data);

            $other_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_Doc_CourseID = $cid 
                        AND CRSE_Doc_Year = $date AND CRSE_DOC_Type LIKE 'Other%'";
            $other_Data = mysqli_query($con,$other_QRY);
            $other_CNT = mysqli_fetch_assoc($other_Data);

            // $req_SQL = "SELECT CRSE_Doc_PRGMID,CRSE_Doc_Year,CRSE_Doc_Sem FROM Mtb_CourseDocs WHERE CRSE_Doc_CourseID = $cid 
            //             AND CRSE_Doc_Year = $date";
            // $req_Data = mysqli_query($con,$req_SQL);
            // $req_Result = mysqli_fetch_assoc($req_Data);
    }
?>