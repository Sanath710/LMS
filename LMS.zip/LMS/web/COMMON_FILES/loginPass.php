<?php
  session_start();
  error_reporting(0);
?>
<html>
    <head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <style>
      body, html 
      {
        height: 100%;
        background-repeat: no-repeat; 
        background-image: linear-gradient(rgb(111, 65, 236),rgb(99, 130, 177));
          background-color: #020202;
          /* background: rgb(156, 156, 255); */
        position: relative;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div id="login-box">
        <div class="controls">
          <form action="" method="POST">
            <div class="login_Form_Title">Welcome to <br/><b style="font-size:23px;">"Learning Management System"</b><br/><br/>Please Provide Password</div>
            <span class="UserName">Password<br/></span>
            <input type="password" name="user_Password" placeholder="Enter Password" autocomplete="off" class="form-control usernameInp" title="Enter Your Password" required/>
            <hr/>
            <br/>
            <input type="Submit" value="Login" name="btn_LoginPass" style="font-size:18px;" class="btn btn-primary btnLOGIN"/>
          </form>
          <?php
              if(isset($_POST['btn_LoginPass']))
              {
                  include("Connection.php");
                  $username = $_SESSION['Sess_USR_ID'];
                  $password = $_POST['user_Password'];
                  $query = "SELECT USR_ID,USR_Role FROM Mtb_Users WHERE UPPER(USR_ID) = '$username' AND USR_Password = '$password'";
                  $data = mysqli_query($con,$query);
                  $total = mysqli_num_rows($data);
                  $result = mysqli_fetch_assoc($data);
                  if($total==1)
                  {
                      $sessionID = session_id();
                      $session_Active_QRY = "UPDATE Mtb_Users SET USR_Session = '$sessionID' WHERE USR_ID = '$username'";
                      mysqli_query($con,$session_Active_QRY);
                      if($result['USR_Role']=="Student") 
                      {
                          header('Location: ../Student/dashboard.php');
                      }
                      else if($result['USR_Role']=="Teacher")
                      {
                        header('Location: ../Teacher/dashboard.php');
                      }
                      else if($result['USR_Role']=="HoD") 
                      {
                        header('Location: ../HoD/dashboard.php');
                      }
                      else if($result['USR_Role']=="Admin") 
                      {
                          header("Location: ../admin/dashboard.php");
                      }
                  }
                  else
                  {
                      echo '<p style="color:red">Incorrect Password</p>';
                  }
              }
          ?>
        </div>
      </div>
    </div>
    <div id="particles-js"></div>
    <script>
        if ( window.history.replaceState ) 
        {
          window.history.replaceState( null, null, "loginPass.php");
        }
        $.getScript("../js/particles.min.js", function(){
        particlesJS('particles-js',
          {
            "particles": {
              "number": {
                "value": 80,
                "density": {
                  "enable": true,
                  "value_area": 800
                }
              },
              "color": {
                "value": "#ffffff"
              },
              "shape": {
                "type": "circle",
                "stroke": {
                  "width": 1,
                  "color": "green"
                },
                "polygon": {
                  "nb_sides": 10
                },
                "image": {
                  "width": 10,
                  "height": 100
                }
              },
              "opacity": {
                "value": 0.8,
                "random": false,
                "anim": {
                  "enable": false,
                  "speed": 0.2,
                  "opacity_min": 0.1,
                  "sync": false
                }
              },
              "size": {
                "value": 5,
                "random": true,
                "anim": {
                  "enable": false,
                  "speed": 40,
                  "size_min": 0.1,
                  "sync": false
                }
              },
              "line_linked": {
                "enable": true,
                "distance": 120,
                "color": "#ffffff",
                "opacity": 0.4,
                "width": 2
              },
              "move": {
                "enable": true,
                "speed": 1,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "attract": {
                  "enable": false,
                  "rotateX": 600,
                  "rotateY": 1200
                }
              }
            },
            "interactivity": {
              "detect_on": "canvas",
              "events": {
                "onhover": {
                  "enable": true,
                  "mode": "repulse"
                },
                "onclick": {
                  "enable": true,
                  "mode": "push"
                },
                "resize": true
              },
              "modes": {
                "grab": {
                  "distance": 400,
                  "line_linked": {
                    "opacity": 1
                  }
                },
                "bubble": {
                  "distance": 400,
                  "size": 40,
                  "duration": 2,
                  "opacity": 8,
                  "speed": 3
                },
                "repulse": {
                  "distance": 200
                },
                "push": {
                  "particles_nb": 4
                },
                "remove": {
                  "particles_nb": 2
                }
              }
            },
            "retina_detect": true,
            "config_demo": {
              "hide_card": false,
              "background_color": "green",
              "background_image": "",
              "background_position": "50% 50%",
              "background_repeat": "no-repeat",
              "background_size": "cover"
            }
          }
        );

    });

    </script>
    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script> -->
  </body>
</html>