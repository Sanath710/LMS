<?php
    session_start();
    include("Connection.php");
    $userID = $_SESSION['Sess_USR_ID'];
    $removeSession = "UPDATE Mtb_Users SET USR_Session = '' WHERE USR_ID = '$userID'";
    mysqli_query($con,$removeSession);
    unset($_SESSION['Sess_USR_Name']);
    unset($_SESSION['Sess_USR_ID']);
    unset($_SESSION['Sess_USR_Role']);
    session_destroy();
    header('Location:login.php');
?>