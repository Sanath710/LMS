<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {  
        include("../COMMON_FILES/Connection.php");

        $pid = $_POST['selProgramID'];
        $sem = $_POST['selSem'];
        $year = $_POST['selYear'];
        $course = $_POST['selCourse'];
        $div = $_POST['selDiv'];
        $uid = $_POST['chk_Stud'];
        $uname = $_POST['usr_Name'];
        $userStatus = 1;
        $flag = true;
        $error_id = '';   //For transffering error codes to the main page from where data came.
        
        // Server side validation
        if(!empty($pid) && !empty($sem) && !empty($year) && !empty($course) && !empty($div))
        {
            $insert_QRY = "INSERT INTO Tb_CourseUsers(CRSE_USR_UID,CRSE_USR_PID,CRSE_USR_CourseID,CRSE_USR_Year,CRSE_USR_Sem,CRSE_USR_Division,CRSE_USR_Status) 
                           Values(?,?,?,?,?,?,?)";
            $stmt = mysqli_stmt_init($con);
            if(!mysqli_stmt_prepare($stmt,$insert_QRY))
            {
                echo "Error in Prepare Statement";
                header("refresh:0;url=../Teacher/enrollStudents.php?s=4");
            }
            else
            {
                // As we have received programme name (i.e : BCA, MCA) instead of their ID from database so for getting Programme ID, firing below query.
                $sql = "SELECT PID FROM Mtb_Programme WHERE PRGM_Code ='$pid'";
                $data = mysqli_query($con,$sql);
                $res = mysqli_fetch_assoc($data);
                $res = $res['PID'];

                // For enrolling multiple students at once using data received from form
                foreach($uid as $id)
                {
                    mysqli_stmt_bind_param($stmt,"iiiiisi",$id,$res,$course,$year,$sem,$div,$userStatus);
                    if(!mysqli_stmt_execute($stmt))
                    {
                        $flag = true;
                        // For displaying error message along with Student ID, if student is already enrolled into that course previously.
                        $sql = "SELECT USR_ID FROM Mtb_Users WHERE UID = $id";
                        $data = mysqli_query($con,$sql);
                        $result = mysqli_fetch_assoc($data);
                        $error_id = $result['USR_ID'];
                    }
                    else
                    {
                        $flag = false;
                    }
                }
                if($flag == false)
                {
                    header("refresh:0;url=../Teacher/enrollStudents.php?s=2");
                }
                else
                {
                    header("refresh:0;url=../Teacher/enrollStudents.php?s=1&id=$error_id");
                }
            }
        }
        else
        {
            header("refresh:0;url=../Teacher/enrollStudents.php?s=3");
        }
    } 
    else
    {
        echo "You Don't have previleges to access this page.<br/>This incident will be reported along with your IP.";
        header("refresh:2;url=../COMMON_FILES/logout.php");
    }
?>
