<?php
    include("../COMMON_FILES/Connection.php");
    // @$program = 1;
    // @$year = 2021;
    // @$sem = 3;
    // @$div = 'A';

    @$QRY = "SELECT Mtb_CourseSchedule.* FROM Tb_CourseUsers,Mtb_Users,mtb_courseschedule WHERE USR_ID = 'T202100001' AND UID = CRSE_USR_UID AND CRSE_USR_CourseID = CRSE_SCHED_CourseID 
    GROUP BY CRSE_SCHED_Day ORDER BY FIELD(CRSE_SCHED_Day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), DATE_FORMAT(CRSE_SCHED_StartTime,'%T')";
    @$data_QRY = mysqli_query($con,$QRY);
    $column = mysqli_num_rows($data_QRY);
    // if(!empty($program) && !empty($year) && !empty($sem) && !empty($div))
    // {
        echo '
            <table style="width:95.5%;margin-left:3.5%;height:36rem;" class="table table-striped table-bordered wrap">
                <thead>
                    <tr><th style="text-align:center;">Day<br/>Time</th>
        ';
        while($res = mysqli_fetch_array($data_QRY))
        {
            echo "<th style='width:16%;text-align:center;border-right:none;height:5rem;border-left:none;padding-top:2.5%!important;padding-bottom:2%!important;'>".$res['CRSE_SCHED_Day']."</th>";
        }
        echo "      </tr>
                </thead>
                <tbody>
                    <tr>
        ";
        $QRY = "SELECT Mtb_CourseSchedule.* FROM Tb_CourseUsers,Mtb_Users,mtb_courseschedule WHERE USR_ID = 'T202100001' AND UID = CRSE_USR_UID AND CRSE_USR_CourseID = CRSE_SCHED_CourseID GROUP BY DATE_FORMAT(CRSE_SCHED_StartTime,'%T')";
        $data_QRY_2 = mysqli_query($con,$QRY);
        $row = mysqli_num_rows($data_QRY_2);
        $startTime_QRY = "select CRSE_SCHED_StartTime from mtb_courseschedule ,Mtb_Users, tb_courseusers WHERE USR_ID = 'T202100001' AND UID = CRSE_USR_UID AND CRSE_USR_CourseID = CRSE_SCHED_CourseID GROUP BY CRSE_SCHED_StartTime";
        $data_StartTime = mysqli_query($con,$startTime_QRY);
        $st_Result = mysqli_fetch_all($data_StartTime);
        // echo "<pre>";
        // print_r($st_Result);
        // echo "</pre>"; 
        while($res = mysqli_fetch_array($data_QRY_2))
        {
            echo "
                <td style='width:10%;background-color:white;padding-top:2.1%!important;padding-bottom:1.8%!important;'>".date('h:i A', strtotime($res['CRSE_SCHED_StartTime']))."<br/>
                ".date('h:i A', strtotime($res['CRSE_SCHED_EndTime']))."</td>
            ";
            $QRY_CRSE = "SELECT Mtb_CourseSchedule.* FROM Tb_CourseUsers,Mtb_Users,mtb_courseschedule WHERE USR_ID = 'T202100001' AND UID = CRSE_USR_UID AND CRSE_USR_CourseID = CRSE_SCHED_CourseID ";
            $data_QRY_3 = mysqli_query($con,$QRY_CRSE);
            
            $cnt = $temp =0;
            for($i = 0; $i < $row*$column; $i++)
            {
                $st_Total = mysqli_num_rows($data_StartTime);
                $r = mysqli_fetch_assoc($data_QRY_3);
                // echo $st_Result[$st_Total-1][0]." ".$res['CRSE_SCHED_StartTime']."<br/>";
                // if($r['CRSE_SCHED_StartTime'] == $st_Result[$st_Total-4][0])
                // {
                    echo"
                        <td style='width:13%;border:none;background-color:whitesmoke;text-align:center;padding-top:2.6%!important;padding-bottom:2.5%!important;'>".$r['CRSE_SCHED_CourseID'].$r['CRSE_SCHED_Day'].$r['CRSE_SCHED_StartTime']."</td>
                    ";
                // }
                // else if($res['CRSE_SCHED_Day'] == "Tuesday")
                // {
                //     echo"
                //         <td style='width:13%;border:none;background-color:whitesmoke;text-align:center;padding-top:2.6%!important;padding-bottom:2.5%!important;'>".$r['CRSE_SCHED_Day']."</td>
                //     ";
                // }
                // else if($res['CRSE_SCHED_Day'] == "Wednesday")
                // {
                //     echo"
                //         <td style='width:13%;border:none;background-color:whitesmoke;text-align:center;padding-top:2.6%!important;padding-bottom:2.5%!important;'>".$r['CRSE_SCHED_Day']."</td>
                //     ";
                // }
                // else if($res['CRSE_SCHED_StartTime'] == $st_Result[$st_Total-4][0] && $res['CRSE_SCHED_Day'] == $r['CRSE_SCHED_Day'])
                // {
                //     echo"
                //         <td style='width:13%;border:none;background-color:whitesmoke;text-align:center;padding-top:2.6%!important;padding-bottom:2.5%!important;'>".$r['CRSE_SCHED_CourseID']."</td>
                //     ";
                // }
                // else
                // {
                //     echo"
                //         <td style='width:13%;border:none;background-color:whitesmoke;text-align:center;padding-top:2.6%!important;padding-bottom:2.5%!important;'></td>
                //     ";
                // }
                if($cnt == 4)
                {
                    echo"</tr>";
                    break;
                }
                $cnt++;
            }
        }
        echo "      </tr>
                </tbody>
            </table>
        ";
    // }
?>