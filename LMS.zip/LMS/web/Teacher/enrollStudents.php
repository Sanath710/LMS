<?php
    session_start();
    error_reporting(0);

    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {  
        include_once("../HoD/teacherNavBar.php");
        include("../COMMON_FILES/Connection.php");
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['s']==1)
        {
            $id = $_GET['id'];
            echo 
            '<script>
                swal("Sorry", "Student '.$id.' is already enrolled into that course previously.", "info");
            </script>
            ';
        }
        else if($_GET['s']==2)
        {
            echo 
            '<script> 
                swal("Success", "Student/s enrolled Successfully.", "success");
            </script>
            ';
        }
        else if($_GET['s']==3)
        {
            echo 
            '<script> 
              swal("Alert", "All Fields are Compulsory.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==4)
        {
            echo 
            '<script> 
              swal("Alert", "Error in Prepare Statement", "warning");
            </script>
            ';
        }
        // For getting Programme details.
        $PRGM_QRY = "SELECT PRGM_ID,LPAD(PRGM_Code,3,0) as code FROM Tb_CourseUsers,Mtb_Programme,Mtb_Users WHERE CRSE_USR_PID = PID AND USR_ID ='".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID GROUP BY PID";
        $PRGM_QRY_Data = mysqli_query($con,$PRGM_QRY);
        
        // For getting Year details.
        $Year_QRY = "SELECT substring(USR_ID,2,4) as enroll_Year FROM Mtb_Users GROUP BY enroll_Year";
        $Year_QRY_Data = mysqli_query($con,$Year_QRY);

        // For getting Course details.
        $Sem_QRY = "SELECT CRSE_USR_Sem FROM Tb_CourseUsers,Mtb_Users WHERE USR_ID ='".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID GROUP BY CRSE_USR_Sem";
        $Sem_QRY_Data = mysqli_query($con,$Sem_QRY);

        // For getting Division.
        // $CRSE_QRY = "SELECT CRSE_USR_CourseID, CRSE_USR_Division FROM Tb_CourseUsers,Mtb_Users WHERE USR_ID ='".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID GROUP BY CRSE_USR_CourseID";
        // $CRSE_QRY_Data = mysqli_query($con,$CRSE_QRY);
?>
<html>
    <head>
        <title>Course Teacher</title>
        <meta name="author" content="Sanath Dinesh">
        <script>
            // Handling form submission redirecting issue.
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "enrollStudents.php");
            }
        </script>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="pcoded-wrapper">
                <div class="main-body" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding: 1% 1% 1% 1%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4 style="font-weight:550;">Enroll Students</h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                </div>
                                <form method="POST" action="enrollStudents_DB.php" style="margin-bottom:2.5%;">
                                    <div style="display:flex;flex-wrap:wrap;">
                                        <label class="col-form-label frmTxt" style="font-weight:550;">Programme</label>
                                        <select name='selProgramID' id='program' onchange="get_Students_REC(),get_Course()" style="width:8%;height:2rem;margin-left:1%;">
                                        <option  value='x'>Select</option>
                                        <?php
                                            // Fetching Programme ID.
                                            while($result = mysqli_fetch_assoc($PRGM_QRY_Data))
                                            {
                                                echo "<option  value='".$result['code']."'>".$result['PRGM_ID']." (".$result['code'].")</option>";
                                            }
                                        ?>
                                        </select>
                                        <label class="col-form-label frmTxt" style="margin-left:3%;font-weight:550;">Enrollment Year</label>&nbsp;&nbsp;
                                        <select name="selYear" id='year' onchange="get_Students_REC()" style="width:8%;height:2rem;margin-top:0.3%;margin-left:0.5%;
                                            border-left:none;border-right:none;border-top:none;">
                                        <option  value='x'>Select</option>
                                        <?php
                                            // Fetching Year.
                                            while($result = mysqli_fetch_assoc($Year_QRY_Data))
                                            {
                                                echo "<option value='".$result['enroll_Year']."'>".$result['enroll_Year']."</option>";
                                            }
                                        ?>
                                        </select>
                                        <label class="col-form-label frmTxt" style="margin-left:2.7%;font-weight:550;">Semester</label>&nbsp;&nbsp;
                                        <select name="selSem" id='sem' style="width:8%;height:2rem;margin-top:0.3%;border-top:none;
                                            border-left:none;border-right:none;margin-left:0.5%;" onChange="get_Course()">
                                        <option  value='x'>Select</option>
                                        <?php
                                            // Fetching Semester.
                                            while($result1 = mysqli_fetch_assoc($Sem_QRY_Data))
                                            {
                                                echo "<option value='".$result1['CRSE_USR_Sem']."'>".$result1['CRSE_USR_Sem']."</option>";
                                            }
                                        ?>
                                        </select>
                                        <label class="col-form-label frmTxt" style="margin-left:2.5%;margin-top:0.2%;font-weight:550;">Course</label>&nbsp;
                                        <!-- <select name="selCourse" id='course' style="width:8%;height:2rem;margin-top:0.3%;margin-left:0.5%;
                                            border-left:none;border-right:none;border-top:none;">
                                        <option  value='x'>Select</option> -->
                                        <!-- Ajax Concept Utilised -->
                                        <div style="margin-top:0.4%;margin-left:0.4%;display:flex;width:25%;" id="course_Data"></div>
                                        <?php
                                            // Fetching Course ID.
                                            // while($result = mysqli_fetch_assoc($CRSE_QRY_Data))
                                            // {
                                            //     echo "<option value='".$result['CRSE_USR_CourseID']."'>".$result['CRSE_USR_CourseID']."</option>";
                                            // }
                                        ?>
                                        <!-- </select> -->
                                        <!-- <label class="col-form-label frmTxt" style="margin-left:3%;">Division</label>&nbsp;&nbsp;
                                        <select name="selDiv" id='div' style="width:8%;height:2rem;margin-top:0.3%;margin-left:0.5%;
                                            border-left:none;border-right:none;border-top:none;">
                                        <option  value='x'>Select</option> -->
                                        <?php
                                            // Re-using same query.
                                            // $CRSE_Div_Data = mysqli_query($con,$CRSE_QRY);
                                            // Fetching Division
                                            // while($result = mysqli_fetch_assoc($CRSE_Div_Data))
                                            // {
                                            //     echo "<option value='".$result['CRSE_USR_Division']."'>".$result['CRSE_USR_Division']."</option>";
                                            // }
                                        ?>
                                        </select>
                                    </div>
                                    <br/>
                                    
                                    <span id="students_Data"></span>
                                    <script>
                                        // For implementing select all student's record at once functionality using checkbox.
                                        function all_CHK()
                                        {
                                            let chks = document.getElementsByClassName('chk_Stud');
                                            let main_CHK = document.getElementById('CHK_all');
                                            if(main_CHK.checked == true)
                                            {
                                                for(i = 0; i < chks.length; i++)
                                                {
                                                    chks[i].checked=true;
                                                }
                                            }
                                            else
                                            {
                                                for(i = 0; i < chks.length; i++)
                                                {
                                                    chks[i].checked=false;
                                                }
                                            }
                                        }
                                        // For displaying student's records based on selection of Programme & Year.
                                        function get_Students_REC()
                                        {
                                            let program = document.getElementById("program").value;
                                            let year = document.getElementById("year").value;


                                            if(program == "x" || year == "x")
                                            {
                                                // Do Nothing :)
                                            }
                                            else
                                            {
                                                let xhr;

                                                (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                
                                                let data = "program="+program+"&year="+year;
                                            
                                                xhr.open("POST","AJAX_EnrollStudents.php",true);
                                                xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                                xhr.send(data);
                                                xhr.onreadystatechange = display_data; 

                                                function display_data()
                                                {
                                                    if(xhr.readyState == 4)
                                                    {
                                                        if(xhr.status == 200)
                                                        {
                                                            document.getElementById("students_Data").innerHTML = xhr.responseText;
                                                            document.getElementById('submit').style.display="";
                                                            document.getElementById('reset').style.display="";
                                                        }
                                                        else
                                                        {
                                                            alert("There was a problem with the request");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        // For Displaying only that courses which is based on the semester selected by a teacher
                                        function get_Course()
                                        {
                                            let sem = document.getElementById("sem").value;
                                            let program = document.getElementById("program").value;

                                            if(sem == "x" || program == "x")
                                            {
                                                // Do Nothing :)
                                            }
                                            else
                                            {
                                                let xhr;

                                                (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                
                                                let data1 = "sem="+sem+"&prgm="+program;
                                            
                                                xhr.open("POST","AJAX_getCourse.php",true);
                                                xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                                xhr.send(data1);
                                                xhr.onreadystatechange = display; 

                                                function display()
                                                {
                                                    if(xhr.readyState == 4)
                                                    {
                                                        if(xhr.status == 200)
                                                        {
                                                            document.getElementById("course_Data").innerHTML = xhr.responseText;
                                                            document.getElementById('submit').style.display="";
                                                            document.getElementById('reset').style.display="";
                                                        }
                                                        else
                                                        {
                                                            alert("There was a problem with the request");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    </script>
                                    <noscript>Your browser doesnot support JavaScript!</noscript>
                                    
                                    <input type="submit" class="PGSubmit" id="submit" style="margin-top:0.5%;width:max-content;font-size:15px;height:2.5rem;padding-top:0.38%;display:none;
                                        padding-left:0.85%;padding-right:0.85%;" onclick="return validate()" name="btnSubmit" value="Submit" />
                                    <input type="reset" class="PGSubmit" id="reset" style="margin-top:0.5%;width:max-content;margin-left:-4%;font-size:16px;height:2.5rem;display:none;
                                            padding-top:0.38%;padding-left:1.15%;padding-right:1.15%;" value="Reset" />
                                </form>
                                <script>
                                    // For validation purpose (Checking if all drop down menus are selecting)
                                    function validate()
                                    {
                                        if(document.getElementById("program").value == "x")
                                        {
                                            swal("Alert", "Please Select a programme", "warning");
                                            return false;
                                        }
                                        if(document.getElementById("sem").value == "x")
                                        {
                                            swal("Alert", "Please Select Semester", "warning");
                                            return false;
                                        }
                                        if(document.getElementById("year").value == "x")
                                        {
                                            swal("Alert", "Please Select Year", "warning");
                                            return false;
                                        }
                                        if(document.getElementById("course").value == "x")
                                        {
                                            swal("Alert", "Please Select Course", "warning");
                                            return false;
                                        }
                                        // if(document.getElementById("div").value == "x")
                                        // {
                                        //     swal("Alert", "Please Select Division", "warning");
                                        //     return false;
                                        // }

                                        // For validation purpose (Checking if atleast one checkbox is selected or not).
                                        let chks = document.getElementsByClassName('chk_Stud');
                                        let flag = false;

                                        for(i = 0; i < chks.length; i++)
                                        {
                                            if(chks[i].checked == true)
                                            {
                                                flag = true;
                                                break;
                                            }
                                            else
                                            {
                                                flag = false;
                                            }
                                        }
                                        if(flag == false)
                                        {
                                            swal("Alert", "Please Select a Student", "warning");
                                            return false;
                                        }
                                    }
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>