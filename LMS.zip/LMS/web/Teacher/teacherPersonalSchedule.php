<?php
    session_start();
    error_reporting(0);
    // if(substr($_SESSION['Sess_USR_Role'],0,1)=="H" || substr($_SESSION['Sess_USR_Role'],0,1)=="T")
    // {   
        include("../COMMON_FILES/Connection.php");

        $QRY = "SELECT Mtb_CourseSchedule.* FROM Tb_CourseUsers,Mtb_Users,mtb_courseschedule WHERE USR_ID = '".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID 
                AND CRSE_USR_CourseID = CRSE_SCHED_CourseID 
                GROUP BY CRSE_SCHED_Day ORDER BY FIELD(CRSE_SCHED_Day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
                DATE_FORMAT(CRSE_SCHED_StartTime,'%T')";
        $data_QRY = mysqli_query($con,$QRY);
        $column = mysqli_num_rows($data_QRY);
        
        if($column) {
            echo '
                <table style="width:95.5%;margin-left:3.5%;height:37rem;margin-top:2%;" class="table table-striped table-bordered wrap">
                    <thead>
                        <tr>
                            <th style="text-align:center;">Day<br/>Time</th>
                            <th style="width:16%;text-align:center;border-right:none;border-left:none;">Monday</th>
                            <th style="width:16%;text-align:center;border-right:none;border-left:none;">Tuesday</th>
                            <th style="width:16%;text-align:center;border-right:none;border-left:none;">Wednesday</th>
                            <th style="width:16%;text-align:center;border-right:none;border-left:none;">Thursday</th>
                            <th style="width:16%;text-align:center;border-right:none;border-left:none;">Friday</th>
                        </tr>
                    </thead>
            ';
        }
        # For Fetching No. of Rows
        $QRY = "SELECT Mtb_CourseSchedule.* FROM Tb_CourseUsers,Mtb_Users,mtb_courseschedule WHERE USR_ID = '".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID 
                AND CRSE_USR_CourseID = CRSE_SCHED_CourseID  GROUP BY DATE_FORMAT(CRSE_SCHED_StartTime,'%T')";
        $data_QRY_2 = mysqli_query($con,$QRY);
        $row = mysqli_num_rows($data_QRY_2);

        # For Storing StartTime in Array
        $startTime_QRY = "SELECT CRSE_SCHED_StartTime from Mtb_courseschedule ,Mtb_Users, tb_courseusers WHERE USR_ID = '".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID 
                          AND CRSE_USR_CourseID = CRSE_SCHED_CourseID GROUP BY CRSE_SCHED_StartTime";
        $data_StartTime = mysqli_query($con,$startTime_QRY);
        $st_Result = mysqli_fetch_all($data_StartTime);

        # For EndTime in Array
        $endTime_QRY = "SELECT CRSE_SCHED_EndTime from Mtb_courseschedule ,Mtb_Users, tb_courseusers WHERE USR_ID = '".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID 
                        AND CRSE_USR_CourseID = CRSE_SCHED_CourseID GROUP BY CRSE_SCHED_StartTime";
        $data_EndTime = mysqli_query($con,$endTime_QRY);
        $et_Result = mysqli_fetch_all($data_EndTime);
            
        # For Adding Elements in array
        for($cnt=0;$cnt<7;$cnt++)
        {
            # Main Data Source QRY
            $QRY_CRSE = "SELECT Mtb_CourseSchedule.* FROM Tb_CourseUsers,Mtb_Users,mtb_courseschedule WHERE USR_ID = '".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID 
                         AND CRSE_USR_CourseID = CRSE_SCHED_CourseID AND CRSE_USR_Status = 1 
                         ORDER BY FIELD(CRSE_SCHED_Day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
                         DATE_FORMAT(CRSE_SCHED_StartTime,'%T') ";
            $data_QRY_3 = mysqli_query($con,$QRY_CRSE);

            # Arrays for Days.
            $arr[1] = $arr[2] = $arr[3] = $arr[4] = $arr[5] = array();

            for($i = 0; $i < $row*$column; $i++)
            {
                $r = mysqli_fetch_assoc($data_QRY_3);
                if($r['CRSE_SCHED_Day']=="Monday")
                {
                    array_push($arr[1],$r['CRSE_SCHED_CourseID']." ".$r['CRSE_SCHED_StartTime']." ".$r['CRSE_SCHED_Division']." ".$r['CRSE_SCHED_Day']);
                }
                else if($r['CRSE_SCHED_Day']=="Tuesday")
                {
                    array_push($arr[2],$r['CRSE_SCHED_CourseID']." ".$r['CRSE_SCHED_StartTime']." ".$r['CRSE_SCHED_Division']." ".$r['CRSE_SCHED_Day']);
                }
                else if($r['CRSE_SCHED_Day']=="Wednesday")
                {
                    array_push($arr[3],$r['CRSE_SCHED_CourseID']." ".$r['CRSE_SCHED_StartTime']." ".$r['CRSE_SCHED_Division']." ".$r['CRSE_SCHED_Day']);
                }
                else if($r['CRSE_SCHED_Day']=="Thursday")
                {
                    array_push($arr[4],$r['CRSE_SCHED_CourseID']." ".$r['CRSE_SCHED_StartTime']." ".$r['CRSE_SCHED_Division']." ".$r['CRSE_SCHED_Day']);
                }
                else if($r['CRSE_SCHED_Day']=="Friday")
                {
                    array_push($arr[5],$r['CRSE_SCHED_CourseID']." ".$r['CRSE_SCHED_StartTime']." ".$r['CRSE_SCHED_Division']." ".$r['CRSE_SCHED_Day']);
                }
            }
        }
        echo "<tbody>";
        
    // Table cell data filling from array 
    // for($c=0; $c<1; $c++)
    // {
        $cnt = 0;
        // count($st_Result) in order to avoid unnecessay row creation upto 7
        while($cnt < count($st_Result))
        {
            echo "<tr>";
                # For Timing Display
                echo "<td style='width:10%;background-color:white;padding-top:2.6%!important;padding-bottom:2.5%!important;'>".date('h:i A', strtotime($st_Result[$cnt][0]))."
                <br/>".date('h:i A', strtotime($et_Result[$cnt][0]))."</td>";
            
                # For Monday
                $rem = tableData($cnt,1);
                generateCell($rem);
                
                # For Tuesday
                $rem = tableData($cnt,2);
                generateCell($rem);

                # For Wednesday
                $rem = tableData($cnt,3);
                generateCell($rem);

                # For Thursday
                $rem = tableData($cnt,4);
                generateCell($rem);

                # For Friday
                $rem = tableData($cnt,5);
                generateCell($rem);
                
                $cnt++;
            echo "</tr>";
        }
    // }
        echo "</tbody>";
            
        # Ṭo generate table cell data if in array
        function tableData($cnt,$k)
        {
            $rem = $counter = 0;
            global $arr;
            global $st_Result;
            while($counter < count($arr[$k]))
            {
                # Below two variables for Link Generation as JS function Para Passing
                $division = substr($arr[$k][$counter],18,1);
                $day = substr($arr[$k][$counter],20,);

                if(intval($st_Result[$cnt][0]) == intval(substr($arr[$k][$counter],8,9)))
                {
                    # Don't Change below two sibiling span tag location else ChildNode Property of DOM will be violated & JS function won't work.
                    echo " <td class='data-cell' onclick='connectVC(this)' style='width:13%;text-align:center;padding-top:2.1%!important;padding-bottom:1.8%!important;'><span style='display:none;'>$division</span><span style='display:none;'>$day</span><span style='display:none;'>".substr($arr[$k][$counter],0,9)."</span><span style='display:none;'>".$st_Result[$cnt][0]."</span>
                            ".substr($arr[$k][$counter],0,9)."
                            <br/>Sem : ".substr($arr[$k][$counter],5,1)."</td>";
                    $rem++;
                }
                $counter++;
            }
            return $rem;
        }

        # To generate table cells
        function generateCell($rem)
        {
            while($rem < 1)
            {
                echo " <td style='width:13%;text-align:center;padding-top:2.1%!important;padding-bottom:1.8%!important;'></td>";
                $rem++;
            }
        }

        // print_r($arr[1]);echo"<br/>";
        // print_r($arr[2]);echo"<br/>";
        // print_r($arr[3]);echo"<br/>";
        // print_r($arr[4]);echo"<br/>";
        // print_r($arr[5]);echo"<br/>";

        echo "      </tr>
                </tbody>
            </table>
        ";
    // }
    // else
    // {
    //     header('Location:../COMMON_FILES/logout.php');
    // }
?>