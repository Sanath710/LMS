<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T") 
    {   
        include("../COMMON_FILES/Connection.php");

        include_once("../HoD/teacherNavbar.php");
        $PRGM_query ="SELECT CRSE_DOC_PRGMID FROM  Mtb_CourseDocs_new WHERE CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."' GROUP BY CRSE_DOC_PRGMID";
        $PRGM_data = mysqli_query($con,$PRGM_query);

        $CRSE_query ="SELECT CRSE_DOC_CourseID FROM  Mtb_CourseDocs_new WHERE CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."' GROUP BY CRSE_DOC_CourseID";
        $CRSE_data = mysqli_query($con,$CRSE_query);

        $Year_query ="SELECT CRSE_DOC_Year FROM  Mtb_CourseDocs_new WHERE CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."' GROUP BY CRSE_DOC_Year";
        $Year_data = mysqli_query($con,$Year_query);

        $query_Assessment ="SELECT CRSE_DOC_DocName,CRSE_DOC_Year FROM Mtb_CourseDocs_new WHERE CRSE_DOC_Type != 'Material' AND CRSE_DOC_Type != 'Homework' AND CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."'GROUP BY CRSE_DOC_DocName";
        $data_Assessment = mysqli_query($con,$query_Assessment);
?>
<html>

    <head>
        <title id="title">Reports</title>
        <link rel="stylesheet" type="text/css" href="../css/datatables.bootstrap4.min.css">
        <link rel="stylesheet" type="text/css" href="../css/buttons.datatables.min-2.css">
        <link rel="stylesheet" type="text/css" href="../css/style.css">
        <style>
            table tr,table,td 
            {
                border:none!important;
            }
            div.dataTables_wrapper div.dataTables_filter 
            {
                /* display: none; */
                margin-bottom:1.5%!important;
            }
            div.dataTables_wrapper div.dataTables_info 
            {
                display: none;
            }
            div.dataTables_wrapper div.dataTables_paginate 
            {
                display: none;
            }
        </style>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "submissionReport.php");
            }
        </script>
    </head>

    <body>
        <div class="pcoded-content">
        <!-- Main Body Starts -->
            <div class="main-body" style="margin-top:0.5%;">
                <div class="page-wrapper subBodyProgram">
                    <div class="card bodyStyling">
                        <div class="card-block"  style="margin-left:1.5%;margin-right:1.5%;">
                            <div style="font-size:17px;">
                                <h4>Assessment Submission Report</h4>
                                <hr style="margin-bottom:2%;margin-top:1%;"/>
                                <form method="POST">
                                    Programme : &nbsp;
                                    <select name='sel_ProgramID' style="width:9%;">
                                        <?php
                                            while($result = mysqli_fetch_assoc($PRGM_data))
                                            {
                                                echo "<option value='".$result['CRSE_DOC_PRGMID']."'>".$result['CRSE_DOC_PRGMID']."</option>";
                                            }
                                        ?>
                                    </select> 
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    Course : &nbsp;
                                    <select name='sel_CourseID' style="width:11%;">
                                        <?php
                                            while($result = mysqli_fetch_assoc($CRSE_data))
                                            {
                                                echo "<option value='".$result['CRSE_DOC_CourseID']."'>0".$result['CRSE_DOC_CourseID']."</option>";
                                            }
                                        ?>
                                    </select>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    Assessment : &nbsp;
                                    <select name='sel_CRSE_DOC_Name'style="width:10%;" >
                                        <?php
                                            while($res_Assessment = mysqli_fetch_assoc($data_Assessment))
                                            {
                                                echo "<option value='".$res_Assessment['CRSE_DOC_DocName']."'>".$res_Assessment['CRSE_DOC_DocName']."</option>";
                                            }
                                        ?>
                                    </select>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    Year : &nbsp;
                                    <select name='sel_Year'style="width:10%;" >
                                        <?php
                                            while($res_Year = mysqli_fetch_assoc($Year_data))
                                            {
                                                echo "<option value='".$res_Year['CRSE_DOC_Year']."'>".$res_Year['CRSE_DOC_Year']."</option>";
                                            }
                                        ?>
                                    </select>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="submit" class="btnView" name="btnView" value="View" />
                                </form>
                                <?php
                                    if(isset($_POST['btnView']))
                                    {    
                                        echo 
                                        "<script>
                                            document.getElementById('title').remove();
                                        </script>";
                                        $ProgramID = $_POST['sel_ProgramID'];
                                        $CourseID = $_POST['sel_CourseID'];
                                        $Assessment = $_POST['sel_CRSE_DOC_Name'];
                                        $Year = $_POST['sel_Year'];
                                        echo "<head><title>Assessment Submission Report : \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
                                        Course - ".$CourseID."\t\t\t".$Assessment." (".$ProgramID." ".$Year.")</title></head>";
                                        if(!empty($CourseID)  && !empty($Assessment) && !empty($Year))
                                        {
                                            include("Connection.php");
                                            $qry_Fetch = "SELECT CRSE_DOC_USR_ID,USR_FirstName,USR_LastName,CRSE_DOC_Submission,CRSE_DOC_Points FROM Mtb_CourseDOCS_new,Mtb_Users,Tb_CourseUsers 
                                                WHERE CRSE_DOC_USR_ID = USR_ID AND not USR_ID ='".$_SESSION['Sess_USR_ID']."' AND CRSE_DOC_USR_ID NOT LIKE 'T%' AND CRSE_DOC_USR_ID NOT LIKE 'H%'  AND CRSE_DOC_PRGMID = '$ProgramID' AND CRSE_DOC_CourseID = $CourseID 
                                                AND CRSE_DOC_Type = '$Assessment' AND CRSE_DOC_Year = $Year AND TB_CourseUsers.CRSE_USR_UID = Mtb_Users.UID Group by Mtb_Users.UID";
                                            $report_Data = mysqli_query($con,$qry_Fetch);

                                            $DueDateTime_QRY = "SELECT CRSE_DOC_TCHR_DueDate,CRSE_DOC_TCHR_DueTime FROM Tb_CourseDocTCHR WHERE CRSE_DOC_TCHR_DocID = 
                                                            (SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs WHERE CRSE_DOC_Type = '$Assessment' AND CRSE_DOC_PRGMID = '$ProgramID' AND CRSE_DOC_Year = $Year AND CRSE_DOC_CourseID = $CourseID
                                                            AND CRSE_DOC_USR_ID LIKE 'T%' OR CRSE_DOC_USR_ID LIKE 'H%')";
                                            $DueDateTime_Data = mysqli_query($con,$DueDateTime_QRY);

                                            $remainingStudent_QRY = "SELECT USR_ID, USR_FirstName, USR_LastName FROM Mtb_CourseDOCS_new,Mtb_Users,Tb_CourseUsers WHERE CRSE_USR_UID = Mtb_Users.UID 
                                                AND USR_ID NOT LIKE 'T%' AND USR_ID NOT LIKE 'H%' AND USR_ID NOT LIKE 'A%'
                                                AND CRSE_DOC_PRGMID = '$ProgramID' AND CRSE_DOC_CourseID = $CourseID AND CRSE_DOC_Type = '$Assessment' AND CRSE_DOC_Year = $Year AND TB_CourseUsers.CRSE_USR_UID = Mtb_Users.UID  
                                                AND USR_ID not in (SELECT CRSE_DOC_USR_ID FROM Mtb_CourseDocs WHERE CRSE_DOC_PRGMID = '$ProgramID' AND CRSE_DOC_CourseID = $CourseID AND CRSE_DOC_Type = '$Assessment' 
                                                AND CRSE_DOC_Year = $Year) Group by Mtb_Users.UID";
                                            $report_RemainingStudent = mysqli_query($con,$remainingStudent_QRY);

                                            $total_Submission = mysqli_num_rows($report_Data);
                                            
                                            if($total_Submission>0)
                                            {
                                                $Sem = substr($CourseID,5,1);
                                                $userCount = "SELECT CRSE_USR_UID FROM Tb_CourseUsers,Mtb_Users WHERE CRSE_USR_Year = $Year AND CRSE_USR_UID = Mtb_Users.UID AND USR_ID LIKE 'S%' AND USR_ID NOT LIKE 'T%' 
                                                AND USR_ID NOT LIKE 'A%' AND USR_ID NOT LIKE 'H%' AND CRSE_USR_Sem = $Sem GROUP BY CRSE_USR_UID";
                                                $total_UsersCnt = mysqli_query($con,$userCount);
                                                $totalUsers = mysqli_num_rows($total_UsersCnt);
                                                $nonSubmission =  $totalUsers-$total_Submission;
                                                echo "<br/><span style='font-size:18px;'>Total Submissions :&nbsp; ".$total_Submission."</span></span><span style='margin-left:62.5%;'></span><br/>";
                                                echo "<span style='font-size:18px;color:red;'>Non &nbsp;Submissions&nbsp;: &nbsp;".$nonSubmission."</span><span style='font-size:18px;margin-left:76%;'>Total Students : ".$totalUsers."</span><br/>";
                                                echo "<span style='font-size:20px;margin-left:31%;'><u>Course : &nbsp;".$CourseID." &nbsp;".$Assessment." Submission Report of ".$ProgramID." : ".$Year."</u></span><br/>";

                                                // echo "<span style='font-size:18px;'>Late &nbsp;Submissions&nbsp;:&nbsp; ".$_SESSION['lateSubmission']."</span><br/>";
                                                // // Handling Late Submission Count for every refresh of page / new request.
                                                // unset($_SESSION['lateSubmission']);
                                            }
                                            else
                                            {
                                                echo "<span style='color:red;'>No Data Found</span>";
                                            }
                                        }
                                    }
                                    
                                ?>
                            </div>
                            <br/>
                            <div class="dt-responsive table-responsive">
                                <table id="basic-btn" class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th style="width:12%;">User ID</th>
                                            <th style="width:30%;">User Name</th>
                                            <th style="width:10%;">Submission Status</th>
                                            <th style="width:10%;">Submission Date-Time</th>
                                            <th style="width:10%;">Graded</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $due_result = mysqli_fetch_assoc($DueDateTime_Data);
                                        $dueDate = $due_result['CRSE_DOC_TCHR_DueDate'];
                                        $dueTime = strtotime($due_result['CRSE_DOC_TCHR_DueTime']);

                                        if($dueDate)
                                        echo "<span style='font-size:18px;'>Assessment Due : ".$dueDate." ".date('h:i A',strtotime($due_result['CRSE_DOC_TCHR_DueTime']))."</span><br/><br/>";
                                        
                                        while($report_Result = mysqli_fetch_assoc($report_Data))
                                        {
                                    ?>
                                        <tr>
                                            <td><?php echo $report_Result['CRSE_DOC_USR_ID']; ?></td>
                                            <td><?php echo $report_Result['USR_FirstName']." ".$report_Result['USR_LastName']; ?></td>
                                            <td>
                                                <?php
                                                    $submissionDate = substr($report_Result['CRSE_DOC_Submission'],0,10);
                                                    $submissionTime =  strtotime(substr($report_Result['CRSE_DOC_Submission'],10,9));
                                                    if($submissionDate <= $dueDate && $submissionTime <= $dueTime)
                                                    {
                                                        echo "In-time";
                                                    }
                                                    else
                                                    {
                                                        echo "Late";
                                                        // $_SESSION['lateSubmission']+=1;
                                                    }
                                                ?>
                                            </td>
                                            <td><?php echo date('d/m/y &\nb\sp;&\nb\sp; h:i A',strtotime($report_Result['CRSE_DOC_Submission'])); ?></td>
                                            <td><?php echo $report_Result['CRSE_DOC_Points']; ?></td>
                                        </tr>
                                    <?php
                                        }
                                    ?>
                                     <?php
                                        while($report_Result1 = mysqli_fetch_assoc($report_RemainingStudent))
                                        {
                                    ?>
                                        <tr><!-- style="background-color:rgb(255, 79, 79);color:white;" -->
                                            <td><?php echo $report_Result1['USR_ID']; ?></td>
                                            <td><?php echo $report_Result1['USR_FirstName']." ".$report_Result1['USR_LastName']; ?></td>
                                            <td><?php echo "Pending"; ?></td>
                                            <td><?php echo "---" ?></td>
                                            <td><?php echo "---" ?></td>
                                        </tr>
                                    <?php
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="../js/jquery.datatables.min.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/jszip.min.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/pdfmake.min.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/vfs_fonts.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/datatables.buttons.min-2.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/buttons.print.min.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/buttons.html5.min.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/datatables.bootstrap4.min.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/extension-btns-custom.js" type="46fdda76826106b979343b7a-text/javascript"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="46fdda76826106b979343b7a-|49" defer=""></script>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>