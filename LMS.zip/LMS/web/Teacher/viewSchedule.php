<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="T")
  {   
    include("../HoD/teacherNavbar.php");
    include("../COMMON_FILES/Connection.php");
?>
<html>
  <head>
    <title>LMS | Personalize Course Schedule</title>
    <style>
      #submit:hover,
      #reset:hover 
      {
        background-color: rgb(2, 223, 2) !important;
        border: 1px solid rgb(85, 0, 221) !important;
      }
      table th, 
      table td 
      {
        padding: 1% !important;
        text-align: center;
        vertical-align: inherit !important;
      }
      select:hover {
        cursor:pointer;
      }
      .card .card-block {
        padding: 0%;
        padding-right: 1%;
      }
      .tableView {
        padding-left: 0.5%;
      }
      .table thead th {
        /* border-bottom: 1px solid #d6dde1;
        border-top: none;
        border-left: none;
        border-right: none; */
      }
      table {
        /* border:none!important; */
        margin-top: 2%;
        margin-left: 1.8%;
      }
      .data-cell:hover {
        cursor:pointer;
        background-color:	#4179e1;
        color:white;
      }
    </style>
  </head>
  <body>
  <div class="pcoded-content">
    <!-- Main Body Starts -->
    <div class="main-body">
      <div class="page-wrapper">
        <!-- <div class="page-body"> -->
        <div class="card"style="padding:0%;margin-bottom:0%;margin-top:0.5%;">
          <div class="card-block" style="background-color:white;">
            <div class="card-header" style="margin-top:1%;margin-left:1%;margin-right:1.4%;">
              <h4 style="font-weight:bold;">Personalize Course Schedule</h4>
              <hr/>
            </div>
            <div class="dt-responsive table-responsive tableView">
              <table style="width:40%;margin-left:3.15%;margin-top:1.8%;" >
                <thead>
                  <tr>
                    <th style="width:1.5%;padding-bottom:1.8%;text-align:left;">Programme</th>
                    <th style="width:3%;padding-bottom:2%;text-align:left;">&nbsp;&nbsp;&nbsp;&nbsp;Semester</th>
                    <th style="width:3%;padding-bottom:2%;text-align:left;">&nbsp;Division</th>
                    <th style="width:4%;padding-bottom:2%;text-align:left;">Year</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <form action="newSchedule_DB.php" method="POST">
                      <td class="height_td">
                        <select name='selPRO_ID' id="PRO" onchange="getSCHED()"
                          style="width:107%;height:2rem;">
                          <option value=''>Select</option>
                          <?php
                                # For getting Programme ID.
                                $PRO_QRY = "SELECT PID,PRGM_ID FROM Mtb_Programme,Tb_CourseUsers,Mtb_Users WHERE Mtb_Users.UID = CRSE_USR_UID AND PID = CRSE_USR_PID 
                                            AND USR_ID = '".$_SESSION['Sess_USR_ID']."' GROUP BY PID";
                                $PRO_Data = mysqli_query($con,$PRO_QRY);
                                while($r = mysqli_fetch_assoc($PRO_Data))
                                {
                                    echo "<option value='".$r['PID']."'>".$r['PRGM_ID']."</option>";
                                }
                            ?>
                        </select>
                      </td>
                      <td>
                        <select name='selSEM' id="SEM" onchange="getSCHED()"
                          style="width:90%;height:2rem;margin-left:10%;">
                          <option value=''>Select</option>
                          <?php
                                # For getting Semester.
                                $Sem_QRY = "SELECT CRSE_USR_Sem AS Sem FROM Tb_CourseUsers,Mtb_Users WHERE Mtb_Users.UID = CRSE_USR_UID AND USR_ID = '".$_SESSION['Sess_USR_ID']."' 
                                            GROUP BY CRSE_USR_Sem";
                                $Sem_Data = mysqli_query($con,$Sem_QRY);
                                while($r = mysqli_fetch_assoc($Sem_Data))
                                {
                                    echo "<option value='".$r['Sem']."'>".$r['Sem']."</option>";
                                }
                            ?>
                        </select>
                      </td>
                      <td>
                        <select name="selDivision" id="DIV" onchange="getSCHED()"
                          style="width:95%;height:2rem;">
                          <option value=''>Select</option>
                          <?php
                                # For getting Division.
                                $Div_QRY = "SELECT CRSE_USR_Division FROM Tb_CourseUsers,Mtb_Users WHERE Mtb_Users.UID = CRSE_USR_UID AND USR_ID = '".$_SESSION['Sess_USR_ID']."' 
                                            GROUP BY CRSE_USR_Division";
                                $Div_Data = mysqli_query($con,$Div_QRY);
                                while($r = mysqli_fetch_assoc($Div_Data))
                                {
                                    echo "<option value='".$r['CRSE_USR_Division']."'>".$r['CRSE_USR_Division']."</option>";
                                }
                            ?>
                        </select>
                      </td>
                      <td>
                        <select name="selYEAR" id="YEAR" onchange="getSCHED()"
                          style="width:95%;height:2rem;">
                          <option value=''>Select</option>
                          <?php
                                # For getting Year.
                                $Year_QRY = "SELECT CRSE_USR_Year FROM Tb_CourseUsers,Mtb_Users WHERE Mtb_Users.UID = CRSE_USR_UID AND USR_ID = '".$_SESSION['Sess_USR_ID']."' 
                                             GROUP BY CRSE_USR_Year";
                                $Year_Data = mysqli_query($con,$Year_QRY);
                                while($r = mysqli_fetch_assoc($Year_Data))
                                {
                                    echo "<option value='".$r['CRSE_USR_Year']."'>".$r['CRSE_USR_Year']."</option>";
                                }
                              ?>
                        </select>
                      </td>
                      <script>
                        // Sending request based on values obtained to get schedule information as a reponse.
                        function getSCHED() 
                        {
                          let program = document.getElementById("PRO").value;
                          let year = document.getElementById("YEAR").value;
                          let sem = document.getElementById("SEM").value;
                          let div = document.getElementById("DIV").value;

                          if (program == "Null" || year == "Null" || sem == "Null" || div == "Null") 
                          {
                            // Do Nothing :)
                          }
                          else 
                          {
                            let xhr;

                            (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");

                            let data = "program=" + program + "&year=" + year + "&sem=" + sem + "&div=" + div;

                            xhr.open("POST", "../admin/AJAX_ViewSchedule_DB.php", true);
                            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                            xhr.send(data);
                            xhr.onreadystatechange = display_data;

                            function display_data() 
                            {
                              if (xhr.readyState == 4) 
                              {
                                if (xhr.status == 200) 
                                {
                                  document.getElementById("resSchedule").innerHTML = xhr.responseText;
                                  document.getElementById("hidePersonalSchedule").style.display="none";
                                }
                                else 
                                {
                                  alert("There was a problem with the request");
                                }
                              }
                            }
                          }
                        }
                      </script>
                      <noscript>Your browser doesnot support JavaScript!</noscript>
                    </form>
                </tbody>
              </table>
              <!-- Personlize Schedule of teacher -->
              <div id="hidePersonalSchedule">
                  <?php
                    include_once("teacherPersonalSchedule.php");
                    // Course details display
                    // echo '
                    //     <h6 style="margin-top:1.9%;margin-bottom:-0.9%;margin-left:3.5%;">
                    //         <span style="color:red;font-size:18px;">Note : You can directly join the lecture by clicking on respective Course ID.</sapn>
                    //     </h6>
                    // ';
                    // echo '<div style="border:1px solid #dee2e6;width:max-content;padding:1.3%;margin-left:3.5%;margin-top:1.4%;">';
                    //       $sql = "SELECT Mtb_Courses.* FROM Tb_CourseUsers,Mtb_Users,mtb_courseschedule,mtb_courses WHERE USR_ID = '".$_SESSION['Sess_USR_ID']."' AND UID = CRSE_USR_UID 
                    //               AND CRSE_USR_CourseID = CRSE_SCHED_CourseID AND CRSE_USR_CourseID = CRSE_ID GROUP BY CRSE_ID ";
                    //       $data = mysqli_query($con,$sql);
                    //       while($r = mysqli_fetch_assoc($data))
                    //       {
                    //         echo "<h6>".$r['CRSE_ID']."&nbsp;&nbsp;&nbsp;".$r['CRSE_Name']."</h6>";
                    //       }
                    // echo'</div>';
                  ?>
                  
              </div>
              <div id="resSchedule" style="margin-bottom:3%;"></div>
              <script>
                var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                var stringLength = 30;
                var randomString = Array.apply(null, Array(stringLength)).map(pickRandom).join('');
                function pickRandom() {
                    return possible[Math.floor(Math.random() * possible.length)];
                }
                function connectVC(cs) {
                  if(cs.childNodes[0].innerHTML != '') {
                      window.location.href='../Video_Conferencing/TeachersVC.php?div='+cs.childNodes[0].innerHTML+'&day='+cs.childNodes[1].innerHTML+'&course='+cs.childNodes[2].innerHTML+'&start='+cs.childNodes[3].innerHTML+'&CS='+randomString;
                  } else {
                      swal("Alert", "There is some error in your personal schedule.\nLink not generated.", "info");
                  }
                }
              </script>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>