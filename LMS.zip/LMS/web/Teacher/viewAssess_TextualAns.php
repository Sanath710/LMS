<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");

        $cid = base64_decode($_GET['id']);
        $type = base64_decode($_GET['type']); 
        $did = base64_decode($_GET['did']);
        $uid = base64_decode($_GET['uid']);

        # For Course Name for title of page
        $sql = "SELECT CRSE_Name FROM Mtb_Courses WHERE CRSE_ID = $cid";
        $data = mysqli_query($con,$sql);
        $result = mysqli_fetch_assoc($data);

        # For online text Submission
        $text_QRY = "SELECT CRSE_DOC_DESC_Description FROM Tb_CourseDOCDESC WHERE CRSE_DOC_DESC_DocID = $did";
        $text_Data = mysqli_query($con,$text_QRY);
        $text_Result = mysqli_fetch_assoc($text_Data);
?>
<html>
    <head>
        <title>LMS | Course View <?php echo $type; ?></title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "viewAssess_TextualAns.php?id=<?php echo base64_encode($cid);?>&type=<?php echo base64_encode($type);?>&did=<?php echo base64_encode($did);?>&uid=<?php echo base64_encode($uid);?>");
            }
        </script>
        <style>
            table, tr, td, th {
                border: 1px solid black;
                text-align:center;
            }
            .assess_Details
            {
                padding:1%;
                margin-left: 0%;
                border-radius:2px;
                box-shadow: 0 0 5px rgba(81, 203, 238, 1);
            }
        </style>
         <!-- For File Icons -->
         <link href="../css/css-file-icons.css?v=<?php echo time(); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-15">
                                        <h4><?php echo $cid." : ".$result['CRSE_Name'];?></h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                </div>
                                <h4 style="font-weight:bold;margin-bottom:1.5%;margin-top:0.5%;"><?php echo $type; ?>&nbsp; <i class="fa fa-file-text-o"></i></h4>
                                <!-- Assessment Texual Answers -->
                                <h4 style="font-weight:bold;margin-bottom:1.5%;margin-top:0.5%;">Textual Answer Submission by : <?php echo $uid; ?></h4>
                                <div  class="assess_Details m-b-20 p-l-5">
                                    <?php
                                        echo  $text_Result['CRSE_DOC_DESC_Description'];
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>