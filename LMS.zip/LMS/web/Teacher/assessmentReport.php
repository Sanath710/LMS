<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");
        $year = date("Y");
        $sql = "SELECT CRSE_USR_CourseID FROM Tb_CourseUsers,Mtb_Users WHERE CRSE_USR_UID = UID 
                AND USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_USR_Year = $year";
?>
<html>
    <head>
        <title>LMS | Course Students</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "assessmentReport.php");
            }
        </script>
        <style>
            .criteria:hover
            {
                background-color:#7db8fc;;
                border:1px solid #4099ff;
                color: white;
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding: 1.2% 1% 1% 1%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4 style="font-weight:bold;">Assessment Report</h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                    <form method="POST" style="width:100%;">
                                        <div style="margin-left:1%;margin-top:-1%;display:flex;width:100%;">
                                            <h5 style="font-weight:550;"> Select Course : </h5>
                                            <select name="selCRSE" id='selCRSE'  onchange="getDiv()" style="cursor:pointer;margin-left:0.6%;margin-top:-0.3%;width:8.5%;border: 1px solid rgba(81, 203, 238, 1);">
                                                <option value="x">Select </option>
                                            <?php
                                                $CRSE_data = mysqli_query($con,$sql);
                                                while($r = mysqli_fetch_assoc($CRSE_data))
                                                {
                                                    echo "
                                                        <option value='".$r['CRSE_USR_CourseID']."'>".$r['CRSE_USR_CourseID']."</option>
                                                    ";
                                                }
                                            ?>
                                            </select>
                                            <div id="resDIV" style="width:16.5%;"></div>
                                            <div onclick="remove_BGCOLOR()" class="btn-primary" style="margin-left:54%;padding:0.3%;border-radius:2px;padding-left:1%;padding-right:1%;">Remove Highlights</div>
                                        </div>
                                    </form>
                                    <div id="resReport" style="width:100%;overflow-x:scroll;margin-left:1%;margin-top:0.5%;"></div>
                                    <script>
                                        let cells = document.getElementsByClassName("overall_StudMarks");
                                        let NG = document.getElementsByClassName("NG");

                                        function fun_Lowest()
                                        {
                                            let minMarks =  document.getElementById("minMarks");
                                            for(let i = 0; i < cells.length; i++)
                                            {
                                                if(cells[i].innerHTML == minMarks.innerHTML)
                                                {
                                                    cells[i].style.backgroundColor = "rgba(255, 255, 4, 0.938)";
                                                }
                                            }
                                        }
                                        function fun_Highest()
                                        {
                                            let maxMarks =  document.getElementById("maxMarks");
                                            for(let i = 0; i < cells.length; i++)
                                            {
                                                if(cells[i].innerHTML == maxMarks.innerHTML)
                                                {
                                                    cells[i].style.backgroundColor = "#21F97A";
                                                }
                                            }
                                        }
                                        function fun_NG()
                                        {
                                            for(let i = 0; i < NG.length; i++)
                                            {
                                                NG[i].style.backgroundColor = "#DE9EFF";
                                                NG[i].style.color = "white";
                                            }
                                        }
                                        function remove_BGCOLOR() 
                                        {
                                            let minMarks =  document.getElementById("minMarks");
                                            for(let i = 0; i < cells.length; i++)
                                            {
                                                cells[i].style.backgroundColor = "initial";
                                            }
                                            for(let i = 0; i < cells.length; i++)
                                            {
                                                cells[i].style.backgroundColor = "initial";
                                            }
                                            for(let i = 0; i < NG.length; i++)
                                            {
                                                NG[i].style.backgroundColor = "initial";
                                                NG[i].style.color = "black";
                                            }
                                        }
                                    </script>
                                    <script>
                                        function getDiv()
                                        {
                                            let CRSE = document.getElementById("selCRSE").value;

                                            if(CRSE == "x")
                                            {
                                                // Do Nothing :)
                                                document.getElementById("resDIV").style.display="none";
                                            }
                                            else
                                            {
                                                let xhr;

                                                (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                
                                                let data = "CRSE="+CRSE;
                                                xhr.open("POST","AJAX_assessmentReport.php",true);
                                                xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                                xhr.send(data);
                                                xhr.onreadystatechange = display_data; 

                                                function display_data()
                                                {
                                                    if(xhr.readyState == 4)
                                                    {
                                                        if(xhr.status == 200)
                                                        {
                                                            document.getElementById("resDIV").style.display="";
                                                            document.getElementById("resDIV").innerHTML = xhr.responseText;
                                                        }
                                                        else
                                                        {
                                                            alert("There was a problem with the request");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        function getReport()
                                        {
                                            let CRSE = document.getElementById("selCRSE").value;
                                            let Div = document.getElementById("sel_Div").value;

                                            if(CRSE == "x" || Div == "x")
                                            {
                                                // Do Nothing :)
                                                // document.getElementById("resReport").style.display="none";
                                            }
                                            else
                                            {
                                                let xhr;
                                                (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                
                                                let data = "CRSE="+CRSE+"&Div="+Div;
                                                xhr.open("POST","AJAX_assessmentReport.php",true);
                                                xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                                xhr.send(data);
                                                xhr.onreadystatechange = display; 
                                                
                                                function display()
                                                {
                                                    if(xhr.readyState == 4)
                                                    {
                                                        if(xhr.status == 200)
                                                        {
                                                            // document.getElementById("resReport").style.display="";
                                                            document.getElementById("resReport").innerHTML = xhr.responseText;
                                                        }
                                                        else
                                                        {
                                                            alert("There was a problem with the request");
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    </script>
                                    <noscript>Your browser doesnot support JavaScript!</noscript>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>