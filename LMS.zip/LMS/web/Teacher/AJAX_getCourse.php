<?php
    session_start();
    error_reporting(0);

    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {  
        include("../COMMON_FILES/Connection.php");

        $sem = $_POST['sem'];
        $prgm = $_POST['prgm'];

        // Server side validation
        if($sem != "x")
        {
            $getPRGM_Qry = "SELECT PID FROM Mtb_Programme WHERE PRGM_Code=$prgm";
            $getPRGM_Data = mysqli_query($con,$getPRGM_Qry);
            $PID = mysqli_fetch_assoc($getPRGM_Data);
            $PID = $PID['PID'];

            $CRSE_QRY = "SELECT CRSE_USR_CourseID,CRSE_USR_Division FROM Tb_CourseUsers,Mtb_Users WHERE USR_ID ='".$_SESSION['Sess_USR_ID']."' 
                         AND UID = CRSE_USR_UID AND CRSE_USR_Sem = $sem AND CRSE_USR_PID = $PID GROUP BY CRSE_USR_Division";
            $CRSE_QRY_Data = mysqli_query($con,$CRSE_QRY);
            echo '
                <select name="selCourse" id="course" style="width:100%;height:2rem;
                    border-left:none;border-right:none;border-top:none;">
                    <option  value="x">Select</option>';
                    while($result = mysqli_fetch_assoc($CRSE_QRY_Data))
                    {
                        echo "<option value='".$result['CRSE_USR_CourseID']."'>".$result['CRSE_USR_CourseID']."</option>";
                    }
            echo "</select>";
            echo '
                <label class="col-form-label frmTxt" style="margin-left:12%;font-weight:550;">Division</label>&nbsp;&nbsp;
                <select name="selDiv" id="div" style="width:100%;height:2rem;margin-top:0.3%;margin-left:0.5%;
                    border-left:none;border-right:none;border-top:none;">
                <!-- <option  value="x">Select</option> -->
            ';
                $CRSE_Div_Data = mysqli_query($con,$CRSE_QRY);
                while($result = mysqli_fetch_assoc($CRSE_Div_Data))
                {
                    echo "<option value='".$result['CRSE_USR_Division']."'>".$result['CRSE_USR_Division']."</option>";
                }
        }
    }
    else
    {
        header('Location: ../COMMON_FILES/logout.php');
    }
?>
