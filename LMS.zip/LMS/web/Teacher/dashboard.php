<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");

        $sql = "SELECT CRSE_ID, CRSE_Name FROM Mtb_Courses,Tb_CourseUsers,Mtb_Users WHERE CRSE_USR_CourseID = CRSE_ID 
                AND UID = CRSE_USR_UID AND USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_USR_Status = 1";
        $data = mysqli_query($con,$sql);

        $year = date("Y");
        $uid = $_SESSION['Sess_USR_ID'];
?>
<html>
    <head>
        <title>Dashboard</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "Dashboard.php");
            }
        </script>
        <style>
            ::-webkit-scrollbar {
                width:4px;  /* Remove scrollbar space */
                background: rgb(4 26 55 / 16%);  /* Make scrollbar invisible */
            }
        </style>
        <!-- Radial chart -->
        <link rel="stylesheet" href="../css/radial.css" type="text/css" media="all">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper" style="display:flex;min-height:55.6rem;">
                        <div class="card mainBody" style="width:75%;padding:2%;padding-bottom:0%;margin-bottom:0.5%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-25">
                                        <h4 style="font-weight:bold;">Dashboard<span style="font-weight:bold;margin-left:69%;">Welcome : </span> <?php echo $_SESSION['Sess_USR_ID'];?></h4>
                                        <hr style="margin-left:0%;margin-top:2%;margin-bottom:0%;" />
                                    </div>
                                    <!-- Card blocks -->
                                    <h4 style="font-weight:bold;margin-left:2%;">My Courses : &nbsp;<i class="fa fa-cube"></i></h4>
                                    <div style="margin-top:0%;display:flex;flex-wrap:wrap;margin-left:2%;margin-right:-2%;margin-top:1.5%;margin-bottom:-1.5%;">
                                        <?php
                                            $cnt = 0;
                                            # For getting all images from folder named "Course_Pic" automatically for courses
                                            $auto_Imgs = glob("../Course_Pic/*.*");
                                            while($r = mysqli_fetch_assoc($data))
                                            {
                                                # Getting individual images
                                                // $image = $auto_Imgs[array_rand($auto_Imgs)]; # For auto image
                                                $image = $auto_Imgs[$cnt];
                                                # Valid image formats
                                                $valid_Formats = array('gif','jpg','jpeg','png');
                                                # For getting choosed image format
                                                $image_ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));

                                                $cid = base64_encode($r['CRSE_ID']);
                                                echo'
                                                <a href="../Teacher/course_info.php?id='.$cid.'" style="width:30.3%;" class="ahref_CRSE">
                                                    <div class="course-cards" style="width:100%;">
                                                ';
                                                        # If image is valid then showing them
                                                        if (in_array($image_ext, $valid_Formats))
                                                        {
                                                            echo '<img style="height:62%;width:100%;" src="../Course_Pic/'.$image .'" alt="Course Image" />';
                                                        }
                                                echo '
                                                        <br/><br/>
                                                        <h4 class="CRSE_id" style="text-align:center;font-weight:550;">'.$r['CRSE_ID'].'</h4>
                                                        <h5 class="CRSE_Name">
                                                            <span class="CRSE_Label">Course : </span>'.$r['CRSE_Name'].'</h5>
                                                    </div>
                                                </a>';
                                                $cnt ++ ;
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Side Cards Starts -->
                        <div class="card mainBody m-t-4" style="box-shadow:none;width:24.5%;margin-left:0.8%;background:transparent;margin-bottom:0%;">
                        <!-- Side Top Card -->
                            <div style="background-color:white;width:109%;margin-top:-6.6%;border-radius:5px;height:auto;min-height:18rem;margin-bottom:0%;
                                    box-shadow: 0 1px 2.94px 0.06px rgb(4 26 55 / 16%); border: none;padding:2%;" >
                                <h5 style="font-weight:bold;text-align:left;margin-top:13.5%;margin-bottom:5%;margin-left:7%;"><i class="fa fa-star-half-empty"></i> &nbsp;Internal Evaluations</h5>
                                <hr style="margin-left:5%;margin-right:5%;margin-top:6.7%;margin-bottom:4%;" />
                                <div style="margin-left:4%;font-size:18px;padding:2%;margin-right:3%;margin-bottom:4%;">
                                    <?php
                                        $courses = mysqli_query($con,$sql);
                                        while($res = mysqli_fetch_assoc($courses))
                                        {
                                            $internal_QRY = "SELECT sum(CRSE_DOC_TCHR_Weightage) as total FROM mtb_coursedocs_new,tb_coursedoctchr 
                                                            WHERE CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_DOC_Year = '$year' AND CRSE_DOC_USR_ID = '$uid' AND CRSE_DOC_CourseID = ".$res['CRSE_ID']."";
                                            $internal_Data = mysqli_query($con,$internal_QRY);
                                            $internal = mysqli_fetch_assoc($internal_Data);
                                            echo "<span style='font-weight:550;'>".$res['CRSE_ID'].'</span>&nbsp;&nbsp;<progress style="margin-top:4%;width:55%;" value="'.$internal['total'].'" max="40"></progress><span class="m-l-10" style="font-weight:550">'.round((($internal['total']*100)/40),2).'%</span><br/>';
                                        }
                                    ?>
                                </div>
                            </div>
                        <!-- Side Card bottom Starts-->
                            <div style="background-color:white;width:109%;margin-top:3.6%;border-radius:5px;margin-bottom:2.3%;min-height:35rem;
                                box-shadow: 0 1px 2.94px 0.06px rgb(4 26 55 / 16%); border: none;" >
                                <h5 style="font-weight:bold;text-align:left;margin-top:5.5%;margin-bottom:5%;margin-left:7%;">
                                <i class="fa fa-laptop f-22 p-t-15"></i>&nbsp; Scheduled Meetings 
                                </h5>
                                <hr style="margin-left:5%;margin-right:5%;margin-top:2%;margin-bottom:2%;" />
                                <div class="card-body" style="margin-top:-5%;">
                                    <div class="row align-items-center m-b-0">
                                        <div class="col p-l-0 m-t-5">
                                                <div class="card-block" style="margin-top:-2.8%;">
                                                    <div class="slimScrollDiv" style="position: relative; overflow: visible; width: 107%; ">
                                                        <div class="scroll-widget" style="overflow-y: scroll; overflow-x:hidden; width: auto; min-height:27rem;">
                                                            <div class="latest-update-box">
                                                                <?php
                                                                // echo "*************************";
                                                                    $cnt = 0; #colored circle purpose
                                                                    $getSched_Qry = "SELECT PRGM_ID, CRSE_SCHED_CourseID,  CRSE_SCHED_Division, substring(CRSE_SCHED_CourseID, 5, 2) as semester, 
                                                                                            CRSE_SCHED_StartTime, CRSE_SCHED_EndTime, CRSE_SCHED_LectureLink
                                                                                     FROM mtb_courseschedule, mtb_programme WHERE mtb_programme.PID = CRSE_SCHED_PID 
                                                                                     AND time(now()) <= time(CRSE_SCHED_EndTime) AND DAYNAME(now()) = CRSE_SCHED_Day 
                                                                                     ORDER BY (CRSE_SCHED_StartTime)";
                                                                    $getSchedData = mysqli_query($con, $getSched_Qry);
                                                                    while($schedule = mysqli_fetch_array($getSchedData))
                                                                    {
                                                                        if($cnt%2 == 0)
                                                                        {
                                                                            echo '
                                                                            <div class="row p-b-30">
                                                                                <div class="col-auto text-right update-meta p-r-0">
                                                                                    <i class="b-danger update-icon ring"></i>
                                                                                </div>
                                                                                <div class="col p-l-10">
                                                                                    <a href="../Video_Conferencing/TeachersVC.php?div='.$schedule[2].'&day=Tuesday&course='.$schedule[1].'&start='.$schedule[4].'&CS='.$schedule[6].'">
                                                                                        <h6 style="font-size:17px;font-weight:bold;">'.$schedule[0].'&nbsp; - '.$schedule[1].'&nbsp; ('.date("g:i a", strtotime($schedule[4])).' - '.date("g:i a", strtotime($schedule[5])).')</h6>
                                                                                    </a>
                                                                                    <p class="text-muted m-b-0">Semester : '.$schedule[3].' &nbsp; Division : '.$schedule[2].'</p>
                                                                                </div>
                                                                            </div>
                                                                            ';
                                                                        }
                                                                        else
                                                                        {
                                                                            echo '
                                                                            <div class="row p-b-30">
                                                                                <div class="col-auto text-right update-meta p-r-0">
                                                                                    <i class="b-primary update-icon ring"></i>
                                                                                </div>
                                                                                <div class="col p-l-10">
                                                                                    <a href="../Video_Conferencing/TeachersVC.php?div='.$schedule[2].'&day=Tuesday&course='.$schedule[1].'&start='.$schedule[4].'&CS='.$schedule[6].'">
                                                                                        <h6 style="font-size:17px;font-weight:bold;">'.$schedule[0].'&nbsp; - '.$schedule[1].'&nbsp; ('.date("g:i a", strtotime($schedule[4])).' - '.date("g:i a", strtotime($schedule[5])).')</h6>
                                                                                    </a>
                                                                                    <p class="text-muted m-b-0">Semester : '.$schedule[3].' &nbsp; Division : '.$schedule[2].'</p>
                                                                                </div>
                                                                            </div>
                                                                            ';
                                                                        }
                                                                        $cnt++;
                                                                    }
                                                                    echo '
                                                                    <div class="row">
                                                                        <div class="col-auto text-right update-meta p-r-0">
                                                                            <i class="b-success update-icon ring"></i>
                                                                        </div>
                                                                        <div class="col p-l-10" style="font-size:15.5px;margin-bottom:0%;font-weight:bold;">
                                                                            That\'s all for the day.
                                                                        </div>
                                                                    </div>
                                                                    ';
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </h6>
                                        </div>
                                    </div>
                                <!-- </div> -->
                            <!-- </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>