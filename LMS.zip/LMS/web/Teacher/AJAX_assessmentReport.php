<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T")
    {
        include("../COMMON_FILES/Connection.php");
        $year = date("Y");
        $div = $_POST['Div'];
        $CRSE = $_POST['CRSE'];
        $column_CNT = $maxMarks = $minMarks = $studCnt =  0;
        $assessments = array();

        if($_POST['Div'])
        {
            $col_SQL = "SELECT CRSE_Doc_Type,CRSE_Doc_Points FROM `mtb_coursedocs_new`,Tb_CourseUsers WHERE CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_DOC_Year = $year AND CRSE_DOC_CourseID = $CRSE
                        AND CRSE_Doc_Type not LIKE 'Homework%' AND CRSE_Doc_Type not LIKE 'Material%' AND CRSE_USR_CourseID = CRSE_DOC_CourseID AND CRSE_USR_Division = '$div' GROUP BY CRSE_DOC_Type";
            $col_Data = mysqli_query($con,$col_SQL);

            $crse_Name_QRY = "SELECT CRSE_Name from Mtb_Courses WHERE CRSE_ID = $CRSE";
            $CRSE_DATA = mysqli_query($con,$crse_Name_QRY);
            $CRSE_RES = mysqli_fetch_assoc($CRSE_DATA);

            // $Overall_QRY = "SELECT sum(CRSE_DOC_Points) as total FROM `mtb_coursedocs_new`,Tb_CourseUsers  WHERE CRSE_DOC_USR_ID NOT LIKE 'T%' AND CRSE_DOC_USR_ID NOT LIKE 'H%' 
            //                 AND CRSE_DOC_USR_ID NOT LIKE 'A%' AND CRSE_Doc_Type not in ('Homework','Material') AND CRSE_USR_CourseID = CRSE_DOC_CourseID AND CRSE_USR_Division = '$div'
            //                 AND CRSE_DOC_Year = $year AND CRSE_DOC_CourseID = $CRSE GROUP BY CRSE_USR_UID LIMIT 1";
            // $Overall_Data = mysqli_query($con,$Overall_QRY);
            // $Overall_Marks = mysqli_fetch_assoc($Overall_Data);

            echo "<span style='font-size:16.5px;font-weight:550;'>Course ID  <span style='margin-left:2%;'> &nbsp;:&nbsp; $CRSE.</span><br/>
                  Course Name &nbsp;:&nbsp; ".$CRSE_RES['CRSE_Name']."</span><br/><br/>";
            echo '
                <table id="base-style" style="text-align:center;width:99%;" class="table table-striped table-bordered wrap tableViewProgram">
                <thead>
                    <tr>
                        <th style=\'text-align:center;\'>Student ID</th>
            ';
                while($columns = mysqli_fetch_assoc($col_Data))
                {
                    echo '
                        <th>'.$columns['CRSE_Doc_Type'].'</th>
                    ';
                    array_push($assessments,$columns['CRSE_Doc_Type']);
                    $column_CNT++;
                }
            echo'
                        <th style="text-align:center;">Overall</th>
                    </tr>
                    <tr>
                        <th></th>
            ';
                $sum = 0;
                $col_Data1 = mysqli_query($con,$col_SQL);
                while($columns = mysqli_fetch_assoc($col_Data1))
                {
                    echo '
                        <th>'.$columns['CRSE_Doc_Points'].'</th>
                    ';
                    $sum += intval($columns['CRSE_Doc_Points']);
                }
            // $minMarks = $sum;
            echo'
                        <th style="text-align:center;padding-left:0%;">'.$sum.'</th>
                    </tr>
                </thead>
                <tbody>
            ';

            // Students Data Portion Starts
            $QRY = "SELECT CRSE_DOC_USR_ID,USR_FirstName,USR_LastName FROM Mtb_CourseDocs_new,Tb_CourseUsers,mtb_users WHERE CRSE_DOC_USR_ID LIKE 'S%' AND CRSE_DOC_Year = $year
                    AND CRSE_DOC_CourseID = $CRSE AND CRSE_DOC_USR_ID = USR_ID AND UID = CRSE_USR_UID AND CRSE_USR_Division = '$div' AND CRSE_DOC_CourseID = CRSE_USR_CourseID
                    AND CRSE_Doc_Type not LIKE 'Homework%' AND CRSE_Doc_Type not LIKE 'Material%'
                    GROUP BY CRSE_DOC_USR_ID 
                    ORDER BY CRSE_DOC_USR_ID, CRSE_DOC_Type";
            $Data = mysqli_query($con,$QRY);
            $studCnt = mysqli_num_rows($Data);
            $Data1 = mysqli_query($con,$QRY);
            
            while($r = mysqli_fetch_assoc($Data))
            {
                $result = mysqli_fetch_assoc($Data1);
                $sql = "SELECT CRSE_DOC_USR_ID,USR_FirstName,USR_LastName,CRSE_DOC_Points,CRSE_DOC_Type FROM Mtb_CourseDocs_new,Mtb_Users 
                        WHERE CRSE_DOC_USR_ID = '".$result['CRSE_DOC_USR_ID']."' AND USR_ID = CRSE_DOC_USR_ID
                        AND CRSE_Doc_Type not LIKE 'Homework%' AND CRSE_Doc_Type not LIKE 'Material%'
                        AND CRSE_DOC_Year = $year AND CRSE_DOC_CourseID = $CRSE ORDER BY CRSE_DOC_USR_ID, CRSE_DOC_Type";
                $data = mysqli_query($con,$sql);

                echo "
                <tr>
                    <td style='text-align:left;padding-left:2%;'>".$result['CRSE_DOC_USR_ID']." &nbsp;(".$result['USR_FirstName']." ".$result['USR_LastName'].")</td>";
                $cnt = 0;
                $total = 0.00;
                $loop_CNT = 0;
                $flag = false;
                while($loop_CNT < count($assessments))
                {
                    $res = mysqli_fetch_assoc($data);

                    if($assessments[$loop_CNT] == $res['CRSE_DOC_Type'])
                    {
                        if($res['CRSE_DOC_Points'] != NULL) {
                            echo "<td>".$res['CRSE_DOC_Points']."</td>";
                            $flag = true;
                        }
                        else {
                            echo "<td class='NG'> -- NG --  </td>";
                            $flag = false;
                        }
                        $total += floatval($res['CRSE_DOC_Points']);
                        // if($total <= $minMarks)
                        // {
                        //     $minMarks = $total;
                        // }
                        // else if($total > $maxMarks)
                        // {
                        //     $maxMarks = $total;
                        // }
                        $cnt++;
                    }
                    else
                    {
                        if(!$flag)
                        {
                            echo "<td>-- NS --</td>";
                            $cnt++;
                        }
                        $c = 0;
                        while($c < count($assessments))
                        {
                            if($assessments[$c] == $res['CRSE_DOC_Type'])
                            {
                                if($res['CRSE_DOC_Points'] != NULL) {
                                    echo "<td>".$res['CRSE_DOC_Points']."</td>";
                                }
                                else
                                    echo "<td class='NG'> -- NG -- </td>";


                                $total += floatval($res['CRSE_DOC_Points']);
                                $cnt++;
                                $flag = true;
                                // if($total <= $minMarks)
                                // {
                                //     $minMarks = $total;
                                // }
                                // else if($total > $maxMarks)
                                // {
                                //     $maxMarks = $total;
                                // }
                            }
                            $c++;
                        }
                        
                    }
                    $loop_CNT++;
                }
                while($cnt < $column_CNT)
                {
                    echo "<td>-- NS --</td>";
                    $cnt++;
                }
                echo "<td style='text-align:center;padding-left:0%;' class='overall_StudMarks'>$total</td></tr>";
            }
            // For getting total minimum marks (overall)
            $min_QRY = "SELECT sum(CRSE_DOC_Points) as total FROM mtb_coursedocs_new,Tb_CourseUsers,mtb_users
                        WHERE CRSE_DOC_CourseID = $CRSE AND CRSE_DOC_Year = $year AND CRSE_DOC_USR_ID NOT LIKE 'T%' AND CRSE_DOC_USR_ID NOT LIKE 'H%'
                        AND CRSE_DOC_USR_ID = USR_ID AND UID = CRSE_USR_UID AND CRSE_USR_Division = '$div' AND CRSE_DOC_CourseID = CRSE_USR_CourseID
                        GROUP BY CRSE_DOC_USR_ID ORDER BY total LIMIT 1";
            $min_Data = mysqli_query($con,$min_QRY);
            $minMarks = mysqli_fetch_assoc($min_Data);
            $minMarks = $minMarks['total'];
            
            // For getting total maximum marks (Overall);
            $max_QRY = "SELECT sum(CRSE_DOC_Points) as total FROM mtb_coursedocs_new,Tb_CourseUsers,mtb_users
                        WHERE CRSE_DOC_CourseID = $CRSE AND CRSE_DOC_Year = '$year' AND CRSE_DOC_USR_ID NOT LIKE 'T%' AND CRSE_DOC_USR_ID NOT LIKE 'H%'
                        AND CRSE_DOC_USR_ID = USR_ID AND UID = CRSE_USR_UID AND CRSE_USR_Division = '$div' AND CRSE_DOC_CourseID = CRSE_USR_CourseID
                        GROUP BY CRSE_DOC_USR_ID ORDER BY total DESC LIMIT 1";
            $max_Data = mysqli_query($con,$max_QRY);
            $maxMarks = mysqli_fetch_assoc($max_Data);
            $maxMarks = $maxMarks['total'];

            #For Average Marks below portion

            #First of all Getting total marks
            $marks_QRY = "SELECT sum(CRSE_DOC_Points) as total FROM mtb_coursedocs_new,mtb_users,tb_courseusers
                        WHERE CRSE_DOC_CourseID = $CRSE AND CRSE_DOC_Year = '$year' AND CRSE_DOC_USR_ID NOT LIKE 'T%' AND CRSE_DOC_USR_ID NOT LIKE 'H%'
                        AND CRSE_DOC_USR_ID = USR_ID AND CRSE_USR_UID = UID AND CRSE_DOC_CourseID = CRSE_USR_CourseID AND CRSE_USR_Division = '$div'";
            $marks_Data = mysqli_query($con,$marks_QRY);
            $marks_Result = mysqli_fetch_assoc($marks_Data);
            $marks_Result = $marks_Result['total'];

            #Getting total no. of active students
            // $studs_QRY = "SELECT count(USR_ID) FROM tb_courseusers,mtb_users WHERE CRSE_USR_UID = UID AND USR_ID LIKE 'S%' AND CRSE_USR_Sem = substring($CRSE,5,2) 
            //              AND CRSE_USR_Year = '$year' AND CRSE_USR_Status = 1 AND CRSE_USR_Division = '$div' GROUP BY USR_ID";
            // $studs_Data = mysqli_query($con,$studs_QRY);
            // $studs_Result = mysqli_num_rows($studs_Data);

            #calculating average marks
            $avgMarks = round($marks_Result/$studCnt,2);

           
            // Course Progress Portion starts
            echo '
            </table>
            <br/>
            <table style="text-align:center;width:40%;" class="table table-striped table-bordered wrap ">
                <tr style="background-color:white;">
                    <th class="criteria" style="width:40%;cursor:pointer;" onclick="fun_Lowest()">
                        Lowest Marks
                    </th>
                    <td style="width:18%;" id="minMarks">'.round($minMarks,3).'</td>
                    <th class="criteria" style="width:36%;cursor:pointer;" onclick="fun_Highest()">
                        Highest Marks
                    </th>
                    <td style="width:16%;" id="maxMarks">'.round($maxMarks,3).'</td>
                </tr>
                <tr style="background-color:white;"><th>Average Marks</th><td>'.$avgMarks.'</td><th>Average Marks %</th><td>'.round(($avgMarks*100)/$sum,2).' %</td></tr>
               
            </table>
            <table style="text-align:center;margin-left:43%;margin-top:-9.2%;width:40%;" class="table table-striped table-bordered wrap ">
                <tr style="background-color:white;">
                    <th colspan="2">Abbrevations</th>
                </tr>
                <tr style="background-color:white;">
                    <td class="criteria" style="cursor:pointer;" onclick="fun_NG()"> -- NG -- &nbsp;: &nbsp;&nbsp;Not Graded</td>
                    <td style="width:50%;"> -- NS -- &nbsp;: &nbsp;&nbsp;Not Submitted </td>
                </tr>
            </table>
            <br/>
            <table style="text-align:center;width:25%;" class="table table-striped table-bordered wrap">
            ';
            // <tr style="background-color:white;"><th>Average Course Progress</th><td>'.round(($Overall_Marks['total']*100)/($studCnt*$sum),2).' %</td></tr>

            // Zero Assessments Portion Starts
            $sql = "SELECT USR_ID,USR_FirstName,USR_LastName FROM Mtb_Users,TB_CourseUsers WHERE CRSE_USR_UID = UID AND CRSE_USR_CourseID = $CRSE AND CRSE_USR_Status = 1 AND USR_ID LIKE 'S%' AND USR_ID not in (SELECT CRSE_DOC_USR_ID FROM Mtb_CourseDocs_new WHERE CRSE_DOC_USR_ID LIKE 'S%' AND CRSE_DOC_Year = $year
                    AND CRSE_DOC_CourseID = $CRSE AND CRSE_USR_Division = '$div' GROUP BY CRSE_DOC_USR_ID)";
            $data = mysqli_query($con,$sql);
            if(mysqli_fetch_assoc($data))
            echo "<tr><td style='background-color:White;font-weight:bold;text-align:center;' colspan='".(count($assessments)*2)."'> Zero assessments received till date from below students</td></tr>";
            // $cnt = 0;
            echo "<tr>";
            while($r = mysqli_fetch_assoc($data))
            {
                echo "<td style='text-align:center;'>".$r['USR_ID']."</td><td>".$r['USR_FirstName']." ".$r['USR_LastName']."</td></tr>";
            }
            echo'
                </tbody>
            </table>
            ';
        }
        else
        {
            $sql = "SELECT CRSE_USR_Division FROM Tb_CourseUsers,Mtb_Users WHERE CRSE_USR_UID = UID AND USR_ID = '".$_SESSION['Sess_USR_ID']."' 
                    AND CRSE_USR_CourseID = $CRSE AND CRSE_USR_Year = $year";
            $data = mysqli_query($con,$sql);
            
            echo '<span style="font-size:18px;margin-left:6%;font-weight:550;">Division : </span>
                <select name="sel_Div" id="sel_Div" onChange="getReport()" style="cursor:pointer;margin-left:4.1%;width:40%;margin-top:-1%;height: 2.1rem; border: 1px solid rgba(81, 203, 238, 1);">
                    <option value="x">Select</option>';
            while($r = mysqli_fetch_assoc($data))
            {
                echo "
                    <option value='".$r['CRSE_USR_Division']."'>".$r['CRSE_USR_Division']."</option>
                ";
            }
            echo '</select>';
        }
    }
?>