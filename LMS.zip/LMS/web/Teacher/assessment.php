<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="T")
    {    
        include_once("../HoD/teacherNavbar.php");
        include("../COMMON_FILES/Connection.php");

        $uid = $_SESSION['Sess_USR_ID'];
        $cid = base64_decode($_GET['id']);
        $type = base64_decode($_GET['type']); 
        $year = date("Y");

        # For Course Name for title of page
        $sql = "SELECT CRSE_Name FROM Mtb_Courses WHERE CRSE_ID = $cid";
        $data = mysqli_query($con,$sql);
        $result = mysqli_fetch_assoc($data);

        # For assessment details
        $assessment_QRY = " SELECT CRSE_DOC_DocName,CRSE_DOC_Type,CRSE_DOC_Points,CRSE_DOC_TCHR_DueDate,CRSE_DOC_TCHR_DueTime,CRSE_DOC_TCHR_Weightage,
                                   CRSE_DOC_TCHR_AvailableFromDate, CRSE_DOC_DocID
                            FROM Mtb_CourseDocs_New,Tb_CourseDocTCHR
                            WHERE CRSE_DOC_TCHR_DocID = CRSE_DOC_DocID AND CRSE_DOC_USR_ID = '$uid' AND CRSE_DOC_CourseID = $cid
                            AND CRSE_DOC_Year = $year AND CRSE_DOC_Sem = substring($cid,5,2) AND CRSE_DOC_Type LIKE '$type%'";
        $assessment_Data = mysqli_query($con,$assessment_QRY);

        # For total students count
        $stud_QRY = "SELECT CRSE_USR_UID FROM Tb_CourseUsers,Mtb_Users WHERE CRSE_USR_CourseID = $cid AND CRSE_USR_Year = $year AND CRSE_USR_Sem = substring($cid,5,2)
                     AND CRSE_USR_Division = (SELECT CRSE_USR_Division FROM Tb_CourseUsers,Mtb_Users WHERE CRSE_USR_CourseID = $cid AND CRSE_USR_Year = $year 
                                                AND CRSE_USR_Sem = substring($cid,5,2) AND CRSE_USR_UID = UID AND USR_ID = '$uid')
                     AND CRSE_USR_UID = UID AND USR_ID LIKE 'S%' AND CRSE_USR_Status = 1";
        $stud_Data = mysqli_query($con,$stud_QRY);
        $stud_Count = mysqli_num_rows($stud_Data);
?>
<html>
    <head>
        <title>LMS | Course <?php echo $type; ?></title>
        <!-- For File Icons -->
        <link href="../css/css-file-icons.css?v=<?php echo time(); ?>" rel="stylesheet">
        <script src="../COMMON_FILES/sweetalert.min.js"></script>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "assessment.php?id=<?php echo base64_encode($cid);?>&type=<?php echo base64_encode($type);?>");
            }
        </script>
        <style>
            .main-card 
            {
                border : 1px solid white;
            }
            .main-card:hover 
            {
                border: 1px solid rgba(81, 203, 238, 1);
            }
            .counter-block:hover
            {
                background-color:rgb(44, 243, 44);
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-15">
                                        <h4 style="font-weight:bold;"><?php echo $cid." : ".$result['CRSE_Name'];?></h4>
                                        <hr style="margin-left:0%;" />
                                    </div>
                                </div>
                                <h4 style="font-weight:bold;margin-bottom:1.5%;"><?php echo $type; ?>&nbsp; <i class="fa fa-file-text-o"></i></h4>
                                <div class="m-b-10" style="height:40.8rem;display:flex;flex-wrap:wrap;overflow-y:scroll;margin-left:-0.9%">
                                    <!-- For Responsive Behaviour -->
                                    <?php
                                        $flag = false;
                                        
                                        while($res = mysqli_fetch_assoc($assessment_Data)) {

                                            # For file icon
                                            $id = $res['CRSE_DOC_DocID'];
                                            $file_Qry = "SELECT CRSE_DOC_Attach_Path FROM Tb_CourseDOCAttached WHERE CRSE_Doc_Attach_DocID = $id";
                                            $file_Data = mysqli_query($con,$file_Qry);
                                            $file_Res = mysqli_fetch_assoc($file_Data);

                                            $flag = true;
                                            $type = $res['CRSE_DOC_Type'];

                                            # For getting total no. of submissions for individual assessments.
                                            $submission_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_New WHERE CRSE_DOC_CourseID = $cid AND CRSE_DOC_Year = $year 
                                                               AND CRSE_DOC_Sem = substring($cid,5,2) AND CRSE_DOC_Type LIKE '$type%' AND CRSE_DOC_USR_ID LIKE 'S%'";
                                            $submission_Data = mysqli_query($con,$submission_QRY);
                                            $submission_Count = mysqli_num_rows($submission_Data);


                                            echo '
                                            <div class="col-md-2.5 m-l-15 m-t-10 m-b-50" style="display:flex;flex-wrap:wrap;height:16rem;margin-bottom:auto%;">
                                                <div class="card user-card m-r-25">
                                                    <div class="card-block main-card">
                                            ';
                                                    if(@$file_Res['CRSE_DOC_Attach_Path'])
                                                    {
                                                        echo '
                                                            <a href="../'.$file_Res['CRSE_DOC_Attach_Path'].'">
                                                                <span style="width:35px;height:41px;margin-bottom:-2%;padding-left:0%;" class="fi fi-'.end(explode(".",@$file_Res['CRSE_DOC_Attach_Path'])).'">&nbsp;
                                                                    <div class="fi-content">'.end(explode(".",@$file_Res['CRSE_DOC_Attach_Path'])).'</div>
                                                                </span>
                                                            </a>
                                                        ';
                                                    }
                                                    else
                                                        echo "<p style='color:black;margin-top:-0.7%;'>Descriptive Question Asked<br/> No File Uploded</p>";
                                                        // echo '<i class="fa fa-file-text-o f-24"></i>';
                                            echo '
                                                        <h6 class="f-w-600 m-t-25 m-b-10"></h6>
                                                        <p style="font-weight:bold; font-size:17px; overflow-wrap: break-word;">
                                                            '.$res['CRSE_DOC_DocName'].'
                                                        </p>
                                                        <hr/>
                                                        <p class="m-t-20 m-b-20" style="text-align:left;">
                                                            <span style="font-weight:550;">Uploaded On&nbsp; :&nbsp; &nbsp; </span>'.$res['CRSE_DOC_TCHR_AvailableFromDate'].'<br/>
                                            ';
                                            if((substr($type,0,8)!="Material") && (substr($type,0,8)!="Homework"))
                                            {
                                                echo'
                                                            <span style="font-weight:550;">Due Date &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </span>&nbsp; &nbsp;'.$res['CRSE_DOC_TCHR_DueDate'].'&nbsp;&nbsp;'.date("g:i A", strtotime($res['CRSE_DOC_TCHR_DueTime'])).'<br/>
                                                            <span style="font-weight:550;">Submissions &nbsp; : </span>&nbsp;&nbsp; '.$submission_Count.'&nbsp;/&nbsp;'.$stud_Count.'
                                                        </p>
                                                    <!-- <ul class="list-unstyled activity-leval">
                                                            <li class="active"></li>
                                                            <li class="active"></li>
                                                            <li class="active"></li>
                                                        </ul> -->
                                               
                                                        <a href="viewAssessments.php?id='.base64_encode($cid).'&type='.base64_encode($res['CRSE_DOC_Type']).'">
                                                            <div class="bg-c-blue counter-block m-t-10 p-10" style="cursor:pointer;font-size:16px;">
                                                                <span style="color:white;">View</span>
                                                            </div>
                                                        </a>
                                                ';
                                            }
                                            else
                                            {
                                                # For View & Delete Material
                                                echo '  
                                                <div style="display:flex;width:100%;">
                                                    <a href="../'.$file_Res['CRSE_DOC_Attach_Path'].'" style="width:98%;">
                                                        <div class="bg-c-blue counter-block p-10" style="cursor:pointer;font-size:16px;">
                                                            <span style="color:white;">View</span>
                                                        </div>
                                                     </a>
                                                    <form method="POST" style="width:100%;margin-bottom:-1%;">
                                                        <input type="hidden" name="DOCID" value="'.$res['CRSE_DOC_DocID'].'"/>
                                                        <input type="submit" name="btnRemove" class="bg-c-red counter-block p-10" value="Remove" style="border:none;font-size:16px;cursor:pointer;"/>
                                                    </form>
                                                </div>
                                                ';
                                                # For Removing Assessment
                                                if($_POST['btnRemove']!= "")
                                                {
                                                    $docID = $_POST['DOCID'];
                                                    $dlt_QRY = "DELETE FROM Mtb_CourseDocs_new WHERE CRSE_DOC_DocID = $docID";
                                                    if(!mysqli_query($con,$dlt_QRY))
                                                    {
                                                        echo 
                                                        '<script> 
                                                            swal("Alert", "Some error occured.\n Please try again.", "warning");
                                                        </script>
                                                        ';
                                                    }
                                                    else
                                                    {
                                                        echo 
                                                        '<script> 
                                                            swal("Success", "'.$type.' removed successfully.", "success");
                                                            setTimeout(function () {
                                                                window.location.reload(1);
                                                            }, 5000);
                                                        </script>
                                                        ';
                                                    }
                                                }
                                            }
                                            echo '
                                                    </div>
                                                    <!-- <div class="row m-b-20 justify-content-center user-social-link">
                                                        <div class="col-auto"><a href="#!"><i class="fa fa-facebook text-facebook"></i></a></div>
                                                        <div class="col-auto"><a href="#!"><i class="fa fa-twitter text-twitter"></i></a></div>
                                                        <div class="col-auto"><a href="#!"><i class="fa fa-dribbble text-dribbble"></i></a></div>
                                                    </div> -->
                                                </div>
                                            </div>
                                            ';
                                        }
                                        if(!$flag)
                                        {
                                            echo '<h5 class="m-l-15" style="color:red;">No Data Found.</h5>';
                                        }
                                    ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>