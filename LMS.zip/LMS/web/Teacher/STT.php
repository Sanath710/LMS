<?php include("../COMMON_FILES/Connection.php");
    $pid = $_POST['selProgramID'];
    $sem = $_POST['selSem'];
    $year = $_POST['selYear'];
    $course = $_POST['selCourse'];
    $div = $_POST['selDiv'];
    $uid = $_POST['chk_Stud'];
    $userStatus = 1;
    $flag = true;
    $error_id = '';
    if(!empty($pid) && !empty($sem) && !empty($year) && !empty($course) && !empty($div)) {
        $insert_QRY = "INSERT INTO Tb_CourseUsers(CRSE_USR_UID,CRSE_USR_PID,CRSE_USR_CourseID,CRSE_USR_Year,CRSE_USR_Sem,CRSE_USR_Division,CRSE_USR_Status) Values(?,?,?,?,?,?,?)";
        $stmt = mysqli_stmt_init($con);
        if(!mysqli_stmt_prepare($stmt,$insert_QRY)) {
            header("refresh:0;url=../Teacher/enrollStudents.php?s=4");
        }
        else {
            $sql = "SELECT PID FROM Mtb_Programme WHERE PRGM_Code ='$pid'";
            $data = mysqli_query($con,$sql);
            $res = mysqli_fetch_assoc($data);
            $res = $res['PID'];
            foreach($uid as $id) {
                mysqli_stmt_bind_param($stmt,"iiiiisi",$id,$res,$course,$year,$sem,$div,$userStatus);
                if(!mysqli_stmt_execute($stmt)) {
                    $flag = true;
                    $sql = "SELECT USR_ID FROM Mtb_Users WHERE UID = $id";
                    $data = mysqli_query($con,$sql);
                    $result = mysqli_fetch_assoc($data);
                    $error_id = $result['USR_ID'];
                }
                else {
                    $flag = false;
                }
            }
            if($flag == false) {
                header("refresh:0;url=../Teacher/enrollStudents.php?s=2");
            }
            else {
                header("refresh:0;url=../Teacher/enrollStudents.php?s=1&id=$error_id");
            }
        }
    }
    else {
        header("refresh:0;url=../Teacher/enrollStudents.php?s=3");
    } ?>