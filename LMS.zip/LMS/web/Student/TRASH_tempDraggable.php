<?php
    include_once("StudentNavbar.php");
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <style>
            .sty
            {
                border:1px solid black;
                padding:1%;
                height:5rem;
                margin-right:0%;
                width:17%;
                margin-top:0%;
            }
            .drag {
                float: left;
                width: 100px;
                height: 35px;
                margin: 10px;
                padding: 10px;
                border: 1px solid black;
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-15">
                                        <h4 style="font-weight:bold;">Draggable</h4>
                                        <hr style="margin-left:0%;margin-top:2%;" />
                                    </div>
                                    <?php
                                        for($i = 0; $i < 35; $i++)
                                        {
                                            echo '
                                            <div class="sty drag" ondrop="drop(event)" ondragover="allowDrop(event)">
                                                <p draggable="true" ondragstart="drag(event)" id="'.$i.'">'.$i.'</p>
                                            </div>';
                                        }
                                    ?>
                                   <!-- <div class="drag" ondrop="drop(event)" ondragover="allowDrop(event)">
                                        <p draggable="true" ondragstart="drag(event)" id="drag1">hi</p>
                                    </div> -->
                                    <div class="drag" id="7" ondrop="drop(event)" ondragover="allowDrop(event)">7</div>
                                    <script>
                                        function allowDrop(ev) {
                                            ev.preventDefault();
                                        }

                                        function drag(ev) {
                                            ev.dataTransfer.setData("text", ev.target.id);
                                        }

                                        function drop(ev) {
                                            ev.preventDefault();
                                            var data = ev.dataTransfer.getData("text");
                                            ev.target.appendChild(document.getElementById(data));
                                            if(data == (document.getElementById("7").innerHTML))
                                            {
                                                alert(data);
                                            }
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
