<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {    
        include("../COMMON_FILES/Connection.php");
        // print_r($_POST);
        // print_r($_FILES);

        // Form Data 
        $docID = $_POST['docID'];
        $crseID = $_POST['crseID'];
        $docType = $_POST['docType'];
        $docName = $_POST['docName'];
        $prgmID = $_POST['prgmID'];
        $assessText = $_POST['assessText'];

        // For redirecting purpose
        $c_ID = base64_encode($crseID);
        $d_ID = base64_encode($docID);
        $label = base64_encode($_POST['label']);

        // Form Data Received (Only File Related)
        $fileName = $_FILES['assessFile']['name'];
        $fileType = $_FILES['assessFile']['type'];
        $fileSize = $_FILES['assessFile']['size'];
        $fileLocation = $_FILES['assessFile']['tmp_name'];
        $fileError = $_FILES['assessFile']['error'];

        // Other required data
        $year = date("Y");
        $sem = substr($crseID,5,1);
        $uid = $_SESSION['Sess_USR_ID'];

        #seperating file name with it's extension.
        $fileExt = explode('.',$fileName);
    
        #checking uploaded file's extension
        $checkExt = strtolower(end($fileExt));

        $supportedExt = array('pdf','docx');

        #file name with a random number so that similar dont get replaced
        $randomName = rand(1000,10000)."-".$fileName;
  
        if(($assessText == '') && ($fileName == ''))
        {
           echo "error";
            #S = 2 if there no data received.
            header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=2"); 
        }
        else if ($assessText == '')
        {
            #File + Description
            if($fileError==0)
            {
                if(in_array($checkExt,$supportedExt))
                {
                    #File Size > 2 KB
                    if($fileSize > 20000)
                    {
                        #File Size  < 5 MB
                        if($fileSize < 5242880)
                        {
                            #TO move the uploaded file to specific location
                            if(move_uploaded_file($fileLocation, "../Uploaded_Documents/".$randomName))
                            {
                                #Master table insert QRY
                                $sql = "INSERT INTO Mtb_CourseDocs_new(CRSE_DOC_PRGMID, CRSE_DOC_Year, CRSE_DOC_Sem, CRSE_DOC_USR_ID, CRSE_DOC_CourseID, 
                                                    CRSE_DOC_DocName, CRSE_DOC_Type, CRSE_DOC_Submission)
                                        VALUES('$prgmID', $year, $sem, '$uid', $crseID, '$randomName', '$docType', now())";
                                if(!mysqli_query($con,$sql))
                                {
                                    #S = 3 if database error occurs.
                                    header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=3"); 
                                }
                                else
                                {
                                    #Feteching lastly auto generated Doc ID from database.
                                    $get_DOC_ID_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_new WHERE CRSE_DOC_PRGMID = '$prgmID' AND CRSE_DOC_Year = $year 
                                        AND CRSE_DOC_Sem = $sem AND CRSE_DOC_USR_ID = '$uid' AND CRSE_DOC_CourseID = $crseID AND CRSE_DOC_DocName = '$randomName'
                                        AND CRSE_DOC_Type = '$docType'";
                                    $get_DOC_ID_data = mysqli_query($con,$get_DOC_ID_QRY);
                                    $get_DOC_ID_result = mysqli_fetch_assoc($get_DOC_ID_data);
                                    $get_DOC_ID_result = $get_DOC_ID_result['CRSE_DOC_DocID'];

                                    #Inserting Data into File Database
                                    $sql = "INSERT INTO Tb_CourseDocAttached(CRSE_DOC_Attach_DocID, CRSE_DOC_Attach_Path)
                                            VALUES($get_DOC_ID_result,'Uploaded_Documents/$randomName')";
                                    if(!mysqli_query($con,$sql))
                                    {
                                        echo "error";
                                        #S = 4 if database error occurs for transaction table.
                                        header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=4"); 
                                    }
                                    else
                                    {
                                        #S = 5 for successfull submission
                                        header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=5"); 
                                    }
                                }
                            }
                            else
                            {
                                #S = 6 if error occurs while moving file to destination folder
                                header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=6"); 
                            }
                        }
                        else
                        {
                            #S = 7 file size must be lesser than 5 mb
                            header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=7"); 
                        }
                    }
                    else
                    {
                        #S = 8 file size must be greater than 2 KB
                        header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=8"); 
                    }
                }
                else
                {
                    #S = 9 file extension must be docx or pdf only
                    header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=9"); 
                }
            }
            else
            {
                #S = 10 file extension must be docx or pdf only
                header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=10"); 
            }
        }
        else if(($assessText != '') && ($fileError != 0))
        {
            #Master table insert QRY
            $sql = "INSERT INTO Mtb_CourseDocs_new(CRSE_DOC_PRGMID, CRSE_DOC_Year, CRSE_DOC_Sem, CRSE_DOC_USR_ID, CRSE_DOC_CourseID, 
                    CRSE_DOC_DocName, CRSE_DOC_Type, CRSE_DOC_Submission) VALUES ('$prgmID', $year, $sem, '$uid', $crseID, '$docType', '$docType', now())";
            if(!mysqli_query($con,$sql))
            {
                #S = 3 if database error occurs.
                header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=3"); 
            }
            else
            {
                #Feteching lastly auto generated Doc ID from database.
                $get_DOC_ID_QRY = "SELECT CRSE_DOC_DocID FROM Mtb_CourseDocs_new WHERE CRSE_DOC_PRGMID = '$prgmID' AND CRSE_DOC_Year = $year 
                    AND CRSE_DOC_Sem = $sem AND CRSE_DOC_USR_ID = '$uid' AND CRSE_DOC_CourseID = $crseID AND CRSE_DOC_DocName = '$docType'
                    AND CRSE_DOC_Type = '$docType'";
                $get_DOC_ID_data = mysqli_query($con,$get_DOC_ID_QRY);
                $get_DOC_ID_result = mysqli_fetch_assoc($get_DOC_ID_data);
                $get_DOC_ID_result = $get_DOC_ID_result['CRSE_DOC_DocID'];

                #Inserting Data into File Database
                $sql = "INSERT INTO Tb_CourseDocDesc(CRSE_DOC_DESC_DocID, CRSE_DOC_DESC_Description)
                VALUES($get_DOC_ID_result,'$assessText')";

                if(!mysqli_query($con,$sql))
                {
                    echo "error";
                    #S = 4 if database error occurs for transaction table.
                    header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=4"); 
                }
                else
                {
                    #S = 5 for successfull submission
                    header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=5"); 
                }
            }
        }
        else
        {
            #S = 11 for only either file or text submission accepted message
            header("Location:../Student/assessmentDetails.php?cid=$c_ID&id=$d_ID&label=$label&s=11"); 
        }
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>