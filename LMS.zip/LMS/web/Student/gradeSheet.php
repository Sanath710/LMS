<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {    
        include_once("../Student/studentNavbar.php");
        include("../COMMON_FILES/Connection.php");
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <title>LMS | GradeSheet</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "gradeSheet.php");
            }
        </script>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-15">
                                        <h4 style="font-weight:bold;">GradeSheet</h4>
                                        <hr style="margin-left:0%;margin-top:2%;" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>