<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {    
        include_once("../Student/StudentNavbar.php");
        include("../COMMON_FILES/Connection.php");
        $cid = base64_decode($_GET['id']);
        include_once("../COMMON_FILES/course_info_method.php");
        
        // For Page title where cid is coming as Query String (parameter) 
        $sql = "SELECT CRSE_Name FROM Mtb_Courses WHERE CRSE_ID = $cid";
        $data = mysqli_query($con,$sql);
        $result = mysqli_fetch_assoc($data);

        // For Total Assignments Count By Teacher 
        $assignment_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_Doc_Type LIKE 'Assignment%' AND (substring(CRSE_DOC_USR_ID,1,1) = 'T' OR substring(CRSE_DOC_USR_ID,1,1) = 'H')";
        $assign_data = mysqli_query($con,$assignment_QRY);
        $assign_CNT = mysqli_fetch_assoc($assign_data); 

        // Submmitted Assignment.
        $year = date("Y");
        $uid = $_SESSION['Sess_USR_ID'];
        $s_Assign_QRY = "SELECT CRSE_Doc_Type, count(CRSE_DOC_USR_ID) as total FROM mtb_coursedocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_DOC_Year = '$year' AND CRSE_DOC_USR_ID ='$uid' AND  CRSE_Doc_Type LIKE 'Assignment%' GROUP BY CRSE_Doc_Type";
        $s_Assign_Data = mysqli_query($con,$s_Assign_QRY);
        $s_Assign_CNT = mysqli_num_rows($s_Assign_Data);

        // For Homework
        $hw_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_Doc_Type LIKE 'Homework%' AND (substring(CRSE_DOC_USR_ID,1,1) = 'T' OR  substring(CRSE_DOC_USR_ID,1,1) = 'H')";
        $hw_data = mysqli_query($con,$hw_QRY);
        $hw_CNT = mysqli_fetch_assoc($hw_data); 
        $userHW_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_Doc_Type LIKE 'Homework%'";
        $userHW_data = mysqli_query($userHW_QRY);
        $userHW_CNT = mysqli_fetch_assoc($userHW_data);

        // For Journal
        $Journal_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_Doc_Type LIKE 'Journal%' AND (substring(CRSE_DOC_USR_ID,1,1) = 'T'  OR  substring(CRSE_DOC_USR_ID,1,1) = 'H')";
        $Journal_data = mysqli_query($con,$Journal_QRY);
        $Journal_CNT = mysqli_fetch_assoc($Journal_data); 
        $userJournal_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_Doc_Type LIKE 'Journal%'";
        $userJournal_data = mysqli_query($userJournal_QRY);
        $userJournal_CNT = mysqli_fetch_assoc($userJournal_data);

        // // Redundant
        // $hw_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_Doc_Type LIKE 'Homework%' AND substring(CRSE_DOC_USR_ID,1,1) = 'T' OR  substring(CRSE_DOC_USR_ID,1,1) = 'H'";
        // $hw_data = mysqli_query($con,$hw_QRY);
        // $hw_CNT = mysqli_fetch_assoc($hw_data); 
        // $userHW_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_DOC_USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_Doc_Type LIKE 'Homework%'";
        // $userHW_data = mysqli_query($userHW_QRY);
        // $userHW_CNT = mysqli_fetch_assoc($userHW_data);

        // For Materials 
        $Material_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_Doc_Type LIKE 'Material%' AND (substring(CRSE_DOC_USR_ID,1,1) = 'T' OR  substring(CRSE_DOC_USR_ID,1,1) = 'H')";
        $Material_data = mysqli_query($con,$Material_QRY);
        $Material_CNT = mysqli_fetch_assoc($Material_data); 

        // For Other file types uploaded
        $Other_QRY = "SELECT count(CRSE_DOC_DocID) as total FROM Mtb_CourseDocs_new WHERE CRSE_DOC_CourseID = $cid AND CRSE_Doc_Type LIKE 'Other%' AND (substring(CRSE_DOC_USR_ID,1,1) = 'T'  OR  substring(CRSE_DOC_USR_ID,1,1) = 'H')";
        $Other_data = mysqli_query($con,$Other_QRY);
        $Other_CNT = mysqli_fetch_assoc($Other_data); 

        // For Sweet Alert JS file
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['s']==1)
        {
            echo 
            '<script> 
              swal("Success", "Assessment Uploaded Successfully.", "success");
            </script>
            ';
        }
        else if($_GET['s']==2)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While uploading File into Database.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==3)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While inserting values in description relation.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==4)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While inserting values of assessments availability & visibility in database.\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==5)
        {
            echo 
            '<script> 
              swal("Info", "Assessment Upload Failed.\nSome Error Occured While inserting values in database.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==6)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While moving file to destination folder.!\nUpload failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==7)
        {
            echo 
            '<script> 
              swal("Info", "File Size must be lesser than 5 MB.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==8)
        {
            echo 
            '<script> 
              swal("Info", "File Size must be greater than 20 KB.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==9)
        {
            echo 
            '<script> 
              swal("Info", "Invalid file format.\nAccepted formats are PDF & DOCX.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==10)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured While Uploading File", "warning");
            </script>
            ';
        }
        else if($_GET['s']==11)
        {
            echo 
            '<script> 
              swal("Info", "Some Error Occured. Assessment Upload Failed.", "warning");
            </script>
            ';
        }
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <title>Dashboard</title>
        <style>
            table tr,table,td {border:none!important;}
            col-auto
            {
                font-size:18.5px;
            }
            .comp-card
            {
                cursor: pointer;
                color:black;
            }
            .comp-card:hover
            {
                box-shadow: 0px 1px 1px 1px  rgba(81, 203, 238, 1); 
            }
        </style>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "course_info.php?id=<?php echo base64_encode($cid);?>");
            }
        </script>
        <link rel="stylesheet" type="text/css" href="../css/boxicons.min.css">
        <link rel="stylesheet" href="../css/radial.css" type="text/css" media="all">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-20">
                                        <h4 style="font-weight:510;"><?php echo $cid." : ".$result['CRSE_Name'];?></h4>
                                        <hr style="margin-left:0%;margin-top:2%;" />
                                    </div>
                                    <h4 style="font-weight:510;margin-left:1%;margin-bottom:2%;">Course Dashboard</h4>
                                    <!-- Menu Hyperlink starts -->
                                    <div style="width:100%!important;margin-left:1%;margin-top:-0.7%;min-height:43rem;height:auto;">
                                        <div class="tab-content tabs-right-content card-block" style="width:100%;">
                                            <div class="tab-pane active show" id="menu1" role="tabpanel">
                                                <!-- Dashboard Starts -->
                                                <div style="display:flex;flex-wrap:wrap;margin-left:-3%;">
                                                    <div class="col-xl-4 col-md-12">
                                                        <a href="course.php?id=<?php echo base64_encode($cid); ?>&label=<?php echo base64_encode("Assignment");?>">
                                                            <div class="card comp-card">
                                                                <div class="card-body">
                                                                    <div class="row align-items-center">
                                                                        <div class="col">
                                                                            <h6 class="m-b-25" style="font-weight:510;">Assignment Completion</h6>
                                                                            <!-- <h3 class="f-w-700 text-c-blue" style="margin-top:-3%;margin-bottom:2%;"><?php //if($s_Assign_CNT==0) echo "0"; else echo $s_Assign_CNT; ?></h3> -->
                                                                            <!-- Radial Progress show -->
                                                                            <div data-label="<?php if($assign_CNT['total']==0) echo "0"; else echo round(($s_Assign_CNT*100)/$assign_CNT['total'],1); ?>%" class="radial-bar 
                                                                                radial-bar-<?php if($assign_CNT['total']==0) echo "0"; else echo round((($s_Assign_CNT*100)/$assign_CNT['total'])/5)*5; ?> radial-bar-md radial-bar-warning" style="margin-bottom:0%;margin-top:-2%;">
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-auto" style="margin-bottom:2%;margin-top:2%;">
                                                                            <!-- <h6  style="margin-bottom:6%;">Total Assignments<br/>
                                                                                <span style=""><?php //if($s_Assign_CNT==0) echo "0"; else echo $s_Assign_CNT; ?> /&nbsp;<?php //if($assign_CNT['total']==0) echo "0"; else echo $assign_CNT['total']; ?></span>
                                                                            </h6> -->
                                                                            <br/><br/>
                                                                            <i class="fa fa-file-pdf-o bg-c-blue" style="margin-bottom:15%;"></i>
                                                                            <br/>
                                                                            <span style="font-weight:bold;margin-left:18%;"><?php if($s_Assign_CNT==0) echo "0"; else echo $s_Assign_CNT; ?> /&nbsp;<?php if($assign_CNT['total']==0) echo "0"; else echo $assign_CNT['total']; ?></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                    <a href="course.php?id=<?php echo base64_encode($cid); ?>&label=<?php echo base64_encode("Homework");?>">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25" style="font-weight:510;">Homework Completion</h6>
                                                                        <!-- Radial Progress show -->
                                                                        <div data-label="<?php if($hw_CNT['total']==0) echo "0"; else echo round(($userHW_CNT*100)/$hw_CNT['total'],1); ?>%" class="radial-bar 
                                                                                radial-bar-<?php if($hw_CNT['total']==0) echo "0"; else echo round((($userHW_CNT*100)/$hw_CNT['total'])/5)*5; ?> radial-bar-md radial-bar-warning" style="margin-bottom:0%;margin-top:-2%;">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-auto" style="margin-bottom:2%;margin-top:2%;">
                                                                        <br/><br/>
                                                                        <i class="fa fa-file-pdf-o bg-c-blue" style="margin-bottom:15%;"></i>
                                                                        <br/>
                                                                        <span style="font-weight:bold;margin-left:18%;"><?php if($userHW_CNT==0) echo "0"; else echo $userHW_CNT; ?> /&nbsp;<?php if($hw_CNT['total']==0) echo "0"; else echo $hw_CNT['total']; ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                    <a href="course.php?id=<?php echo base64_encode($cid); ?>&label=<?php echo base64_encode("Journal");?>">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <!-- <div class="col">
                                                                        <h6 class="m-b-25">Total Journals</h6>
                                                                        <h3 class="f-w-700 text-c-blue" style="margin-top:-3%;margin-bottom:2%;"><?php //if($userJournal_CNT['total']==0) echo "0"; else echo $userJournal_CNT['total']; ?></h3>
                                                                        <p class="m-b-0">submitted by you out of <span style="font-weight:bold;">&nbsp;<?php //if($Journal_CNT['total']==0) echo "0"; else echo $Journal_CNT['total'];?></span></p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-code bg-c-blue"></i>
                                                                    </div> -->
                                                                    <div class="col">
                                                                        <h6 class="m-b-25" style="font-weight:510;">Journal Completion</h6>
                                                                        <!-- Radial Progress show -->
                                                                        <div data-label="<?php if($Journal_CNT['total']==0) echo "0"; else echo round(($userJournal_CNT*100)/$Journal_CNT['total'],1); ?>%" class="radial-bar 
                                                                                radial-bar-<?php if($Journal_CNT['total']==0) echo "0"; else echo round((($userJournal_CNT*100)/$Journal_CNT['total'])/5)*5; ?> radial-bar-md radial-bar-warning" style="margin-bottom:0%;margin-top:-2%;">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-auto" style="margin-bottom:2%;margin-top:2%;">
                                                                        <br/><br/>
                                                                        <i class="fa fa-file-pdf-o bg-c-blue" style="margin-bottom:15%;"></i>
                                                                        <br/>
                                                                        <span style="font-weight:bold;margin-left:18%;"><?php if($userJournal_CNT==0) echo "0"; else echo $userJournal_CNT; ?> /&nbsp;<?php if($Journal_CNT['total']==0) echo "0"; else echo $Journal_CNT['total']; ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                    <a href="materials.php?id=<?php echo base64_encode($cid); ?>&label=<?php echo base64_encode("Material");?>">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25" style="font-weight:510;">Total Materials</h6>
                                                                        <h3 class="f-w-700 text-c-blue" style="margin-top:-3%;margin-bottom:2%;"><?php if($Material_CNT['total']==0) echo "0"; else echo $Material_CNT['total']; ?></h3>
                                                                        <p class="m-b-0">Material available</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-archive-o bg-c-yellow"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    </div>
                                                    <div class="col-xl-4 col-md-12">
                                                    <a href="course.php?id=<?php echo base64_encode($cid); ?>&label=<?php echo base64_encode("Other");?>">
                                                        <div class="card comp-card">
                                                            <div class="card-body">
                                                                <div class="row align-items-center">
                                                                    <div class="col">
                                                                        <h6 class="m-b-25" style="font-weight:510;">Other Files</h6>
                                                                        <h3 class="f-w-700 text-c-blue" style="margin-top:-3%;margin-bottom:2%;"><?php if($Other_CNT['total']==0) echo "0"; else echo $Other_CNT['total']; ?></h3>
                                                                        <p class="m-b-0">uploaded by course teacher</p>
                                                                    </div>
                                                                    <div class="col-auto">
                                                                        <i class="fa fa-file-word-o bg-c-red"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </a>
                                                </div>
                                                <!-- Course Dashboard Ends -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>