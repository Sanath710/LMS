<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {    
        include_once("../Student/StudentNavbar.php");
        include("../COMMON_FILES/Connection.php");

        // Basic Details of Course
        $cid = base64_decode($_GET['id']);
        $label = base64_decode($_GET['label']);
        $sql = "SELECT CRSE_Name FROM Mtb_Courses WHERE CRSE_ID = $cid";
        $data = mysqli_query($con,$sql);
        $result = mysqli_fetch_assoc($data);

        $year = date("Y");
        // Label Details (i.e : parameter from previous page based query (QueryString))
        $Root_QRY = "SELECT CRSE_DOC_DocID, CRSE_DOC_DocName, CRSE_DOC_Type, CRSE_DOC_Points, CRSE_DOC_DESC_Description, CRSE_DOC_TCHR_DueDate, CRSE_DOC_TCHR_DueTime
                     FROM Mtb_CourseDocs_new, Tb_CourseDocDesc, Tb_CourseDocTCHR
                     WHERE CRSE_DOC_DocID = CRSE_DOC_DESC_DocID AND CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_DOC_CourseID = $cid 
                     AND CRSE_Doc_Type LIKE '$label%' AND CRSE_DOC_Year = '$year' AND (substring(CRSE_DOC_USR_ID,1,1) = 'T' OR substring(CRSE_DOC_USR_ID,1,1) = 'H') GROUP BY CRSE_DOC_Type";
        $Root_data = mysqli_query($con,$Root_QRY);
        $rows = mysqli_num_rows($Root_data);
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <title><?php echo "Course : ".$cid; ?></title>
        <style>
            td 
            {
                /* cursor:pointer; */
            }
        </style>

        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "course.php?id=<?php echo base64_encode($cid);?>&label=<?php echo base64_encode($label);?>");
            }
        </script>
        <link rel="stylesheet" type="text/css" href="../css/boxicons.min.css">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-15">
                                        <h4 style="font-weight:510;"><?php echo $cid." : ".$result['CRSE_Name'];?></h4>
                                        <hr style="margin-left:0%;margin-top:2%;" />
                                    </div>
                                </div>
                                <div style="min-height:43.5rem;height:auto;">
                                    <h4 style="font-weight:bold;margin-bottom:1.8%;"><?php echo $label; ?></h4>
                                    <table class="table table-hover table-striped">
                                        <thead style="">
                                            <tr>
                                                <th style="width:7%;border-left:1px solid rgba(0,0,0,.125);">Sr<br/>No.</th>
                                                <th><?php echo $label; ?><br/>Name</th>
                                                <th><?php echo $label; ?><br/>Description</th>
                                                <th style="padding-left:1.9%;"><?php echo $label; ?><br/>Due On</th>
                                                <?php 
                                                    if(substr($label,0,8) != "Homework" && substr($label,0,8) != "Material")
                                                        echo '<th>'.$label.' Carries<br/>(Marks/Points)</th>';
                                                ?>
                                                <th>Submission<br/>Status</th>
                                                <th style="padding-left:1.6%;width:7%;border-right:1px solid rgba(0,0,0,.125);">View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $cnt = 1;
                                                $uid = $_SESSION['Sess_USR_ID'];
                                                
                                                while($QRY_result = mysqli_fetch_assoc($Root_data))
                                                {
                                                    // For Student Submission Status Logic.
                                                    $docType = $QRY_result['CRSE_DOC_Type'];
                                                    $stud_Submission_QRY = "SELECT CRSE_Doc_Type FROM mtb_coursedocs_new WHERE CRSE_DOC_USR_ID = '$uid' AND CRSE_Doc_Type in 
                                                                            (SELECT CRSE_Doc_Type FROM mtb_coursedocs_new WHERE CRSE_Doc_Type = '$docType' AND CRSE_DOC_USR_ID LIKE 'T%' OR  CRSE_DOC_USR_ID LIKE 'H%' AND CRSE_DOC_CourseID = $cid AND CRSE_DOC_Year = '$year')
                                                                            ORDER BY CRSE_Doc_Type";
                                                    $stud_Submission_Data = mysqli_query($con,$stud_Submission_QRY);
                                                    $stud_Submission_Result = mysqli_fetch_assoc($stud_Submission_Data);

                                                    echo 
                                                    '
                                                    <tr id="'.$QRY_result['CRSE_DOC_DocID'].'">
                                                        <th style="padding-top:1.8%;">'.$cnt++.'</th>
                                                        <td style="padding-top:1.8%;">'.$QRY_result['CRSE_DOC_DocName'].'</td>
                                                        <td style="padding-top:1.8%;white-space:pre-line;">';
                                                        
                                                    if(strlen($QRY_result['CRSE_DOC_DESC_Description'])>50)
                                                    {
                                                        echo substr($QRY_result['CRSE_DOC_DESC_Description'],0,30)."...";
                                                    }
                                                    else
                                                    {
                                                        echo $QRY_result['CRSE_DOC_DESC_Description'];
                                                    }
                                                    echo
                                                    '   </td>
                                                        <td style="padding-top:1.8%;">'. date("d-m-Y",strtotime($QRY_result['CRSE_DOC_TCHR_DueDate']))."&nbsp;&nbsp;".date("g:i A", strtotime($QRY_result['CRSE_DOC_TCHR_DueTime'])).'</td>
                                                    ';

                                                    // For hiding homework & material marks field display
                                                    if(substr($label,0,8) != "Homework" && substr($label,0,8) != "Material")
                                                        echo '<td style="padding-top:1.8%;padding-left:3.3%;">'.$QRY_result['CRSE_DOC_Points'].'</td>';

                                                    echo '
                                                        <td style="padding-top:1.8%;">
                                                    ';
                                                    // For Submission Status Display
                                                    if($stud_Submission_Result)
                                                    {
                                                        echo '<label class="label label-success" style="font-size:17px;">Submitted</label>';
                                                    }
                                                    else
                                                    {
                                                        echo '<label class="label label-danger"  style="font-size:17px;">Pending</label>';
                                                    }
                                                    echo '
                                                        </td>
                                                        <td>
                                                            <a href="assessmentDetails.php?cid='.base64_encode($cid).'&id='.base64_encode($QRY_result['CRSE_DOC_DocID']).'&label='.base64_encode($label).'">
                                                                <span class="btn btn-primary btn-round waves-effect waves-light"><i class="fa fa-external-link" style="margin-left:15%;margin-top:9%;"></i></span>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    ';
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>