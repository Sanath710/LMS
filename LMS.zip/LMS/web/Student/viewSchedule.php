<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {   
        include_once("../Student/StudentNavbar.php");
        include_once("../COMMON_FILES/Connection.php");
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <title> LMS | View Schedule </title>
        <style>
            td:hover {
                cursor:pointer;
                background-color: #4179e1;
                color:white;
            }
        </style>
        <script src="../COMMON_FILES/sweetalert.min.js"></script>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="main-body">
                <div class="page-wrapper"style="padding-bottom:0%;">
                    <div class="card">
                        <div class="card-block" style="background-color:white;height:54.65rem;">
                            <div class="card-header" style="margin-right:0.5%;margin-left:-0.8%;">
                                <h4 style="font-weight:bold;">Course Schedule</h4>
                                <hr/>
                            </div>
                            <br/>
                            <div class="dt-responsive table-responsive tableView">
                            <?php
                                // Obtaining user programme & course info from database where user status is currently active to prevent old data to be fetched & display
                                $usrDetails_QRY = "SELECT CRSE_USR_PID,CRSE_USR_Year,CRSE_USR_Sem,CRSE_USR_Division FROM Tb_CourseUsers,Mtb_Users WHERE UID = CRSE_USR_UID 
                                                    AND USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_USR_Status = 1";
                                $usr_Details_Data = mysqli_query($con,$usrDetails_QRY);
                                $result = mysqli_fetch_assoc($usr_Details_Data);

                                $program = $result['CRSE_USR_PID'];
                                $year = $result['CRSE_USR_Year'];
                                $sem = $result['CRSE_USR_Sem'];
                                $div = $result['CRSE_USR_Division'];

                                // Checking user programme & course data obtained with course schedule + if exists then grouping by days of week
                                $QRY = "SELECT * FROM Mtb_CourseSchedule WHERE CRSE_SCHED_PID = $program AND CRSE_SCHED_Year = '$year' AND substring(CRSE_SCHED_CourseID,6,1) =  $sem
                                        AND CRSE_SCHED_Division = '$div' GROUP BY CRSE_SCHED_Day 
                                        ORDER BY FIELD(CRSE_SCHED_Day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), DATE_FORMAT(CRSE_SCHED_StartTime,'%T')";
                                $data_QRY = mysqli_query($con,$QRY);
                                
                                //To Control Visibility if No course schedule data is found
                                if($data_QRY)
                                {
                                    echo '
                                        <table style="width:100%;height:30rem;text-align:center;border:1px solid #dee2e6;margin-bottom:1.5%;" class="table table-striped table-bordered wrap">
                                            <thead>
                                                <tr><th style="text-align:center;border-right:none;font-size:16px;width:13.5%;">Day<br/>Time</th>
                                    ';
                                    while($res = mysqli_fetch_array($data_QRY))
                                    {
                                        echo "<th style='width:16%;padding-bottom:2%;border-right:none;height:5rem;border-left:none;'>".$res['CRSE_SCHED_Day']."</th>";
                                    }
                                    echo "      </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                    ";
                                    // Grouping by lecture Start time
                                    $QRY = "SELECT * FROM Mtb_CourseSchedule WHERE CRSE_SCHED_PID = $program AND CRSE_SCHED_Year = '$year' AND substring(CRSE_SCHED_CourseID,6,1) = $sem
                                            AND CRSE_SCHED_Division = '$div' GROUP BY DATE_FORMAT(CRSE_SCHED_StartTime,'%T') ORDER BY DATE_FORMAT(CRSE_SCHED_StartTime,'%T')";
                                    $data_QRY_2 = mysqli_query($con,$QRY);
                                    $row = 0;
                                    while($res = mysqli_fetch_array($data_QRY_2))
                                    {
                                        echo "
                                            <td style='width:10%;background-color:white;padding-top:2.4%;color:black;cursor:initial;'>
                                                ".date('h:i A', strtotime($res['CRSE_SCHED_StartTime']))."
                                                <br/>
                                                ".date('h:i A', strtotime($res['CRSE_SCHED_EndTime']))."
                                            </td>
                                        ";
                                        // Fetching all records by start time (From Above Query value obtained)
                                        $QRY_CRSE = "SELECT CRSE_SCHED_CourseID,CRSE_SCHED_LectureLink FROM Mtb_CourseSchedule WHERE CRSE_SCHED_StartTime = '".$res['CRSE_SCHED_StartTime']."' 
                                                     AND CRSE_SCHED_PID = $program AND CRSE_SCHED_Year = '$year' AND substring(CRSE_SCHED_CourseID,6,1) = $sem 
                                                     AND CRSE_SCHED_Division = '$div' GROUP BY  FIELD(CRSE_SCHED_Day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')";
                                        $data_QRY_3 = mysqli_query($con,$QRY_CRSE);
                                        // For controlling column count
                                        $cnt = 0;
                                        while($r = mysqli_fetch_assoc($data_QRY_3))
                                        {
                                            # For JS Parameters
                                            $ConStr = $r['CRSE_SCHED_LectureLink'];
                                            # Donot change below 1st span tag containing connection String becuz child element property is being applied
                                            echo"
                                                <td style='width:13%;padding-top:2.9%;border:none;' onclick='myfun(this)'><span style='display:none;'>$ConStr</span>
                                                    <span>".$r['CRSE_SCHED_CourseID']."</span>
                                                </td>
                                            ";
                                            # breaking row after it reached day of the week = "Friday" (i.e : based on column count).
                                            if($cnt == 4)
                                            {
                                                $row++;
                                                echo"</tr>";
                                                break;
                                            }
                                            $cnt++;
                                        }
                                    }
                                    echo "      </tr>
                                            </tbody>
                                        </table>
                                    ";
                                    # Course details display
                                    echo '
                                        <h6 style="margin-top:1%;margin-bottom:1%;">
                                            <span style="font-size:18px;font-weight:bold;">&nbsp;Course Details : </span>
                                            <span style="color:red;margin-left:49%;font-size:18px;">Note : You can directly join the lecture by clicking on respective Course ID.</sapn>
                                        </h6>
                                        <div style="border:1px solid #dee2e6;width:max-content;padding:1.3%;margin-top:1.4%;">
                                    ';
                                            $sql = "SELECT CRSE_ID,CRSE_Name FROM Mtb_Courses,Mtb_CourseSchedule WHERE CRSE_SCHED_CourseID = CRSE_ID AND CRSE_SCHED_Year = '$year' 
                                                    AND substring(CRSE_SCHED_CourseID,6,1) = $sem GROUP BY CRSE_ID";
                                            $data = mysqli_query($con,$sql);
                                            while($r = mysqli_fetch_assoc($data))
                                            {
                                                echo "<h6 style='font-weight:501;'>".$r['CRSE_ID']."&nbsp;&nbsp;- &nbsp;".$r['CRSE_Name']."</h6>";
                                            }
                                    echo'</div>';
                                }
                                else
                                {
                                    echo "<h5 style='font-weight:bold;'> No Data Found.</h5>";
                                }
                            ?>
                            <script>
                                function myfun(s) {
                                    if(s.childNodes[0].innerHTML != '') {
                                        window.location.href='../Video_Conferencing/StudentsVC.php?id='+s.childNodes[0].innerHTML;
                                    } else {
                                        swal("Note", "Your lecture has not been started yet.", "info");
                                    }
                                }
                            </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>
