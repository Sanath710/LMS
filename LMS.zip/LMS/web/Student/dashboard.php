<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {    
        include_once("../Student/studentNavbar.php");
        include("../COMMON_FILES/Connection.php");

        $uid = $_SESSION['Sess_USR_ID'];

        #Course Details
        $sql = "SELECT CRSE_ID,CRSE_Name,CRSE_USR_Sem FROM Mtb_Courses,Tb_CourseUsers,Mtb_Users WHERE CRSE_USR_CourseID = CRSE_ID 
                AND UID = CRSE_USR_UID AND USR_ID = '".$_SESSION['Sess_USR_ID']."' AND CRSE_USR_Status = 1";
        $data = mysqli_query($con,$sql);
        $data1 = mysqli_query($con,$sql);
        
        $year = date("Y"); #because if I fetch record based on student id then there can be issue if student is a repeater so fetching current year

        #fetching semester from previous semester
        $data1 = mysqli_query($con,$sql);
        $r1 = mysqli_fetch_assoc($data1); 
        $sem = $r1['CRSE_USR_Sem'];

        #Top Performer Details
        $top_Performers_QRY = "SELECT CRSE_DOC_USR_ID,USR_FirstName,USR_Pic,sum(CRSE_DOC_Points) as total 
                FROM mtb_coursedocs_new,mtb_users where CRSE_DOC_Sem = $sem AND CRSE_DOC_Year = '$year' AND USR_ID = CRSE_DOC_USR_ID
                AND CRSE_DOC_USR_ID NOT Like 'T%' AND CRSE_DOC_USR_ID NOT LIKE 'H%' AND CRSE_DOC_USR_ID NOT LIKE 'A%'
                GROUP BY CRSE_DOC_USR_ID ORDER BY total DESC LIMIT 3";
        $top_Performers_Data= mysqli_query($con,$top_Performers_QRY);
        $top_Performers_Result = mysqli_fetch_all($top_Performers_Data);
        // print_r($top_Performers_Result);

        #For Pending works display
        $pen_QRY = "SELECT CRSE_Doc_Type,CRSE_DOC_TCHR_DueDate,CRSE_DOC_CourseID,CRSE_DOC_DocID FROM mtb_coursedocs_new,tb_coursedoctchr WHERE CRSE_Doc_Type not in
                (SELECT CRSE_Doc_Type FROM mtb_coursedocs_new WHERE CRSE_DOC_USR_ID = '$uid' AND CRSE_DOC_Year = '$year')  AND CRSE_DOC_Type NOT LIKE 'Material%'
                AND CRSE_DOC_USR_ID NOT LIKE 'S%'  AND CRSE_DOC_Sem = $sem AND CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID ORDER BY CRSE_DOC_TCHR_DueDate ASC";
        $pen_Data = mysqli_query($con,$pen_QRY);
        // print_r($pen_Data);
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <title>LMS | Dashboard</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "Dashboard.php");
            }
        </script>
        <style>
            ::-webkit-scrollbar {
                width:4px;  /* Remove scrollbar space */
                background: rgb(4 26 55 / 16%);  /* Make scrollbar invisible */
            }
            .topPerformersList:hover {
                text-decoration:underline;
            }
        </style>
        <!-- Radial chart -->
        <link rel="stylesheet" href="../css/radial.css" type="text/css" media="all">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;margin-bottom:0.5%;" >
                    <div class="page-wrapper" style="display:flex;">
                        <div class="card mainBody" style="width:75%;padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row" style="margin-bottom:-2.15%;display:flow-root;">
                                    <div class="col-sm-12 col-xl-12 m-b-50">
                                        <h4 style="font-weight:bold;">Dashboard<span style="font-weight:bold;margin-left:69%;">Welcome : </span> <?php echo $_SESSION['Sess_USR_ID'];?></h4>
                                        <hr style="margin-left:0%;margin-top:2%;margin-bottom:0%;" />
                                    </div>
                                    <!-- Card blocks -->
                                    <!-- <h4 style="font-weight:bold;margin-left:2.7%;margin-top:-0.3%;">My Courses : &nbsp;<i class="fa fa-cube"></i></h4> -->
                                    <div style="margin-top:0%;display:flex;flex-wrap:wrap;margin-left:2%;margin-right:-2%;margin-top:1.2%;margin-bottom:-1.5%;">
                                        <?php
                                            $cnt = 0;
                                            # For getting all images from folder named "Course_Pic" automatically for courses
                                            $auto_Imgs = glob("../Course_Pic/*.*");
                                            while($r = mysqli_fetch_assoc($data))
                                            {
                                                # Getting individual images
                                                // $image = $auto_Imgs[array_rand($auto_Imgs)]; # For auto image
                                                $image = $auto_Imgs[$cnt];
                                                # Valid image formats
                                                $valid_Formats = array('gif','jpg','jpeg','png');
                                                # For getting choosed image format
                                                $image_ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));

                                                $cid = base64_encode($r['CRSE_ID']);
                                                // if($cnt == 3) echo '<div style="background-color:whitesmoke;">&nbsp;</div>';$cnt++;
                                                echo'
                                                <a href="../Student/course_info.php?id='.$cid.'" class="ahref_CRSE" style="width:30.3%;margin-top:0.5%;">
                                                    <div class="course-cards" style="width:100%;">
                                                ';
                                                        # If image is valid then showing them
                                                        if (in_array($image_ext, $valid_Formats))
                                                        {
                                                            echo '<img style="height:60%;width:100%;" src="../Course_Pic/'.$image .'" alt="Course Image" />';
                                                        }
                                                echo '
                                                        <br/><br/>
                                                        <h4 class="CRSE_id" style="text-align:center;font-weight:550;">'.$r['CRSE_ID'].'</h4>
                                                        <h5 class="CRSE_Name">
                                                            <span class="CRSE_Label">Course : </span>'.$r['CRSE_Name'].'</h5>
                                                    </div>
                                                </a>';
                                                $cnt ++ ;
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Side Cards Starts -->
                        <div class="card mainBody" style="box-shadow:none;width:24.5%;margin-left:0.8%;background:transparent;margin-bottom:0%;">
                        <!-- Side Top Card -->
                            <div style="background-color:white;width:109%;margin-top:-6.6%;border-radius:5px;height:26rem;margin-bottom:0%;
                                    box-shadow: 0 1px 2.94px 0.06px rgb(4 26 55 / 16%); border: none;padding:2%;" >
                                <h4 style="font-weight:bold;text-align:center;margin-top:13.5%;margin-bottom:5%;">
                                    <i class="fa fa-line-chart"></i>&nbsp;
                                    <span data-toggle="modal" data-target="#default-Modal" style="font-size:inherit;cursor:pointer;" class="topPerformersList">
                                        Top Batch Performers</h4>
                                    </span>
                                <hr style="margin-left:5%;margin-right:5%;margin-top:2%;margin-bottom:4%;" />
                                <!-- Top 3 Performers  -->
                                <div class="row" style="padding:2%;padding-left:11%;margin-left:2%;margin-right:2%;margin-top:7%;">
                                    <!-- 2nd position (Performer) -->
                                    <div style="margin-top:5%;margin-right:5.5%;" class="radial-bar radial-bar-50 radial-bar-md radial-bar-danger">
                                        <!-- <img src="../Profile_Pics/rakeshPatel.jpg" alt="User-Image"> -->
                                        <h4 style="margin-top:112%;margin-left:30%;margin-bottom:5%;padding-top:5%;">
                                            2<sup>nd</sup> <br/>
                                            <b style="font-weight:bold;font-size:16px;"><?php echo $top_Performers_Result[1][1]."<br/>(".substr($top_Performers_Result[1][0],8,10);?>)</b>
                                        </h4>
                                        <?php 
                                            if(@$top_Performers_Result[1][2]) echo '<img src="../'.$top_Performers_Result[1][2].'"/>';
                                        ?>
                                    </div>
                                    <!-- 1st position (Performer) -->
                                    <div  style="margin-top:0%;" class="radial-bar radial-bar-50 radial-bar-lg radial-bar-warning">
                                        <h4 style="margin-top:112%;margin-left:35%;margin-bottom:3%;padding-top:5%;">
                                            &nbsp;1<sup>st</sup> <br/>
                                            <b style="font-weight:bold;font-size:16px;"><?php echo $top_Performers_Result[0][1]."<br/>(".substr($top_Performers_Result[0][0],8,10);?>)</b>
                                        </h4>
                                        <!-- <img src="../Profile_Pics/bhaviPanchal.jpg" alt="User-Image"> -->
                                        <?php 
                                            if($top_Performers_Result[0][2]) echo '<img src="../'.$top_Performers_Result[0][2].'"/>';
                                        ?>
                                    </div>
                                    <!-- 3rd position (Performer) -->
                                    <div style="margin-top:5%;margin-left:4%;" class="radial-bar radial-bar-50 radial-bar-md radial-bar">
                                        <h4 style="margin-top:112%;margin-left:30%;margin-bottom:3%;padding-top:5%;">
                                            3<sup>rd</sup> <br/>
                                            <b style="font-weight:bold;font-size:16px;"><?php echo $top_Performers_Result[2][1]."<br/>(".substr($top_Performers_Result[2][0],8,10);?>)</b>
                                        </h4>
                                        <?php 
                                            if($top_Performers_Result[2][2]) echo '<img src="../'.$top_Performers_Result[2][2].'"/>';
                                        ?>
                                    </div>
                                    <div style="margin-top:15%;margin-left:-7%;font-size:17px;">
                                        <!-- <h4 style="font-weight:bold;"> Names : </h4> -->
                                        <br/>
                                        <?php
                                            // echo $top_Performers_Result[0][0]." : ".$top_Performers_Result[0][1]." ".$top_Performers_Result[0][2]."<br/>";
                                            // echo $top_Performers_Result[1][0]." : ".$top_Performers_Result[1][1]." ".$top_Performers_Result[1][2]."<br/>";
                                            // echo $top_Performers_Result[2][0]." : ".$top_Performers_Result[2][1]." ".$top_Performers_Result[2][2];
                                        ?>
                                    </div>
                                </div>
                            </div>
                        <!-- Modal Top Performers List -->
                        <div class="modal fade" id="default-Modal" tabindex="-1" role="dialog" style="margin-left:-13%;">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content" style="width:180%;padding:1.5%;">
                                    <div class="modal-header">
                                        <h4 class="modal-title" style="font-weight:bold;">Score Board</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <table class="table">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th scope="col" style="text-align:center;">Sr No.</th>
                                                <th scope="col" style="width:19%;">Profile Picture</th>
                                                <th scope="col" style="width:21%;">Enrollment No.</th>
                                                <th scope="col">Student Name</th>
                                                <th scope="col">Score</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php
                                                $getTotalList = "SELECT CRSE_DOC_USR_ID,USR_FirstName,USR_LastName,USR_Pic,sum(CRSE_DOC_Points) as total 
                                                    FROM mtb_coursedocs_new,mtb_users where CRSE_DOC_Sem = $sem AND CRSE_DOC_Year = '$year' AND USR_ID = CRSE_DOC_USR_ID
                                                    AND CRSE_DOC_USR_ID NOT Like 'T%' AND CRSE_DOC_USR_ID NOT LIKE 'H%' AND CRSE_DOC_USR_ID NOT LIKE 'A%'
                                                    GROUP BY CRSE_DOC_USR_ID ORDER BY total desc";
                                                $data = mysqli_query($con,$getTotalList);
                                                $cnt = 0;
                                                $myStyle = "color:red;";
                                                while($res = mysqli_fetch_assoc($data)) 
                                                {
                                                    if($res['CRSE_DOC_USR_ID'] == $_SESSION['Sess_USR_ID']) {
                                                        echo "<tr style='color:red;'>";
                                                    } else {
                                                        echo "<tr style='height:5.8rem;'>";
                                                    }
                                                    echo 
                                                    '
                                                        <td style="text-align:center;">'.++$cnt.'</td>
                                                        <td style="text-align:left;margin:0%;padding-top:0%;">
                                                        ';

                                                        if(@$res['USR_Pic'] != "") {
                                                            echo '
                                                            <div class="radial-bar radial-bar radial-bar-warning" style="height:4rem;margin:0%;">
                                                                <img src="../'.$res['USR_Pic'].'" style="border-radius:50%;height:100%;width:90%;" alt=""/>
                                                            </div>';
                                                            } else {
                                                                echo "<br/><span style='margin-left:12%;'>No-Image</span>";
                                                            }
                                                    echo '
                                                        </td>
                                                        <td>'.$res['CRSE_DOC_USR_ID'].'</td>
                                                        <td>'.$res['USR_FirstName'].' '.$res['USR_LastName'].'</td>
                                                        <td>'.$res['total'].'</td>
                                                    </tr>
                                                    ';
                                                }
                                           ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!--  -->
                        <!-- Side Bottom Card -->
                            <div style="background-color:white;width:109%;margin-top:3.6%;border-radius:5px;margin-bottom:0%;height:27.2rem;
                                    box-shadow: 0 1px 2.94px 0.06px rgb(4 26 55 / 16%); border: none;" >
                                    <h4 style="font-weight:bold;text-align:center;margin-top:10.5%;margin-bottom:5%;">
                                        <i class="feather icon-file-text feed-icon"></i>&nbsp; Pending Works 
                                        <?php 
                                            #For blink label animation & label color
                                            $count = mysqli_num_rows($pen_Data);
                                            $color = "red";
                                            $style = null;
                                            if($count == 0) 
                                            {
                                                $color = "green";
                                            }
                                            else
                                            {
                                                $style = "-webkit-animation: not-blink 1.5s cubic-bezier(.65,.815,.735,.395) infinite;";
                                            }
                                            echo '<span class="badge bg-c-'.$color.'" style="color:white;'.$style.'">'.$count;
                                        ?>
                                        </span>
                                    </h4>
                                    <hr style="margin-left:5%;margin-right:5%;margin-top:2%;margin-bottom:2%;" />
                                    <div class="latest-update-card">
                                        <div class="card-header">
                                            <!-- <h4 style="font-weight:bold;text-align:center;margin-top:10.5%;margin-bottom:5%;">Pending Works</h4> -->
                                            <div class="card-block">
                                            <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: 105%; height: 290px;">
                                                <div class="scroll-widget" style="overflow-y: scroll; overflow-x:hidden; width: auto; height: 280px;">
                                                    <div class="latest-update-box">
                                                        <?php
                                                            $cnt = 0; #colored circle purpose
                                                            while($pen_Result = mysqli_fetch_array($pen_Data))
                                                            {
                                                                $cid = base64_encode($pen_Result[2]);
                                                                $label =  base64_encode($pen_Result[0]);
                                                                $id =  base64_encode($pen_Result[3]);
                                                                if($cnt%2 == 0)
                                                                {
                                                                    echo '
                                                                    <div class="row p-b-30">
                                                                        <div class="col-auto text-right update-meta p-r-0">
                                                                            <i class="b-danger update-icon ring"></i>
                                                                        </div>
                                                                        <div class="col p-l-10">
                                                                            <a href="../Student/assessmentDetails.php?cid='.$cid.'&id='.$id.'&label='.$label.'">
                                                                                <h6 style="font-size:17px;font-weight:bold;">'.$pen_Result[0].'&nbsp; - ('.$pen_Result[2].')</h6>
                                                                            </a>
                                                                            <p class="text-muted m-b-0">Due on : '.$pen_Result[1].'</p>
                                                                        </div>
                                                                    </div>
                                                                    ';
                                                                }
                                                                else
                                                                {
                                                                    echo '
                                                                    <div class="row p-b-30">
                                                                        <div class="col-auto text-right update-meta p-r-0">
                                                                            <i class="b-primary update-icon ring"></i>
                                                                        </div>
                                                                        <div class="col p-l-10">
                                                                            <a href="../Student/assessmentDetails.php?cid='.$cid.'&id='.$id.'&label='.$label.'">
                                                                                <h6 style="font-size:17px;font-weight:bold;">'.$pen_Result[0].'&nbsp; - ('.$pen_Result[2].')</h6>
                                                                            </a>
                                                                            <p class="text-muted m-b-0">Due on : '.$pen_Result[1].'</p>
                                                                        </div>
                                                                    </div>
                                                                    ';
                                                                }
                                                                $cnt++;
                                                            }
                                                            echo '
                                                            <div class="row">
                                                                <div class="col-auto text-right update-meta p-r-0" style="margin-top:2%;">
                                                                    <i class="b-success update-icon ring"></i>
                                                                </div>
                                                                <div class="col p-l-10" style="font-size:15.5px;margin-bottom:0%;font-weight:bold;">
                                                                    No More Pending Works.
                                                                </div>
                                                            </div>
                                                            ';
                                                        ?>
                                                    </div>
                                                    <?php
                                                        #if no pending works
                                                        // if($cnt == 0)
                                                        // {
                                                        //     echo '<h4 style="font-weight:bold;">No Pending Works</h4>';
                                                        // }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>