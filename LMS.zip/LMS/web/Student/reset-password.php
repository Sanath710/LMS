<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {    
        include_once("../Student/studentNavbar.php");
        include("../COMMON_FILES/Connection.php");

        $uid = $_SESSION['Sess_USR_ID'];
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        <title>LMS | Password-Reset</title>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState(null, null, "reset-password.php");
            }
        </script>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;" >
                    <div class="page-wrapper" style="display:flex;">
                        <div class="card mainBody" style="width:100%;padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block" >
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4 style="font-weight:bold;">Reset Password</h4>
                                        <hr style="margin-left:0%;margin-top:2%;margin-bottom:0%;" />
                                    </div>
                                </div>
                                <div class="auth-box card p-t-20 p-l-10 p-r-20" style="width:40%;">
                                    <div class="card-block" style="font-size:16px;">
                                        <div class="form-group form-primary" style="display:flex;font-weight:505;">
                                            <span style="margin-top:2%;">UserName</span>  <input type="text" name="username" style="margin-left:12.5%;padding-left:3%;background-color:white;height:3rem;font-size:16px" readonly autocomplete="off" class="form-control" value="<?php echo $uid;?>" required="">
                                        </div>
                                        <div class="form-group form-primary" style="display:flex;font-weight:505;">
                                            Exisiting Password  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="password" style="margin-left:3%;" autocomplete="off" class="form-control" placeholder="Enter Your Exisiting Password" required="">
                                        </div>
                                        <div class="form-group form-primary" style="display:flex;font-weight:505;">
                                            New Password  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="newpassword" style="margin-left:9%;height:3rem;" autocomplete="off" class="form-control" placeholder="Enter New Password" required="">
                                        </div>
                                        <div class="form-group form-primary" style="display:flex;font-weight:505;margin-top:-4%;">
                                            Confirm Password  &nbsp;<input type="password" style="margin-left:7.5%;" autocomplete="off" class="form-control" placeholder="Confirm New Password" required="">
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <button type="button" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-10" style="margin-left:-0.5%;margin-top:0.7%;">Change</button>
                                            </div>
                                        </div>
                                        <!-- <div class="row">
                                            <div class="col-md-10">
                                                <p class="text-inverse text-left m-b-0">Thank you.</p>
                                                <p class="text-inverse text-left"><a href="index.html"><b>Back to website</b></a></p>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                            <?php
                                   
                                    // $all_files = glob("../Course_Pic/*.*");
                                    // for ($i=0; $i<count($all_files); $i++)
                                    //     {
                                    //     $image_name = $all_files[$i];
                                    //     $supported_format = array('gif','jpg','jpeg','png');
                                    //     $ext = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
                                    //     if (in_array($ext, $supported_format))
                                    //         {
                                    //             echo '<img src="../Course_Pic/'.$image_name .'" alt="'.$image_name.'" />'."<br /><br />";
                                    //         } else {
                                    //             continue;
                                    //         }
                                    //     }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>