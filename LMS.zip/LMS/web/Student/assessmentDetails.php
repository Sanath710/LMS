<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="S")
    {    
        include_once("../Student/StudentNavbar.php");
        include("../COMMON_FILES/Connection.php");

        # Basic Details of Course
        $cid = base64_decode($_GET['cid']);
        $Doc_ID = base64_decode($_GET['id']);
        $label = base64_decode($_GET['label']);
        $sql = "SELECT CRSE_Name FROM Mtb_Courses WHERE CRSE_ID = $cid";
        $data = mysqli_query($con,$sql);
        $result = mysqli_fetch_assoc($data);

        # Label Details (i.e : parameter from previous page based query)
        # Recheck below query there is redundancy....................................Time and Date.............................................................
        $Root_QRY = "SELECT CRSE_DOC_DocID, CRSE_DOC_DocName, CRSE_DOC_Points, CRSE_DOC_DESC_Description, CRSE_DOC_TCHR_DueDate, CRSE_DOC_TCHR_DueTime,
                            CRSE_DOC_TCHR_AvailableFromDate, CRSE_DOC_TCHR_AvailableFromTime, CRSE_DOC_Type, CRSE_DOC_PRGMID,CRSE_DOC_TCHR_DueTime, CRSE_DOC_TCHR_DueDate, CRSE_DOC_Attach_Path
                     FROM Mtb_CourseDocs_new, Tb_CourseDocDesc, Tb_CourseDocTCHR, Tb_CourseDocAttached
                     WHERE CRSE_DOC_DocID = CRSE_DOC_DESC_DocID AND CRSE_DOC_DocID = CRSE_DOC_TCHR_DocID AND CRSE_DOC_DocID = CRSE_DOC_Attach_DocID AND CRSE_DOC_CourseID = $cid 
                     AND (substring(CRSE_DOC_USR_ID,1,1) = 'T' OR substring(CRSE_DOC_USR_ID,1,1) = 'H') AND CRSE_Doc_DocID = $Doc_ID";
        $Root_data = mysqli_query($con,$Root_QRY);
        $Root_Result = mysqli_fetch_all($Root_data);
        // print_r($Root_Result);

        # Submission Details if any (CHECKING FOR FILE UPLOAD).
        $uid = $_SESSION['Sess_USR_ID'];
        $docType = $Root_Result[0][8];
        $year = date("Y");
        $submission_Status_QRY = "SELECT CRSE_DOC_Submission,CRSE_DOC_Attach_Path,CRSE_DOC_Points FROM Mtb_CourseDocs_new, Tb_CourseDocAttached 
                                  WHERE CRSE_DOC_DocID = CRSE_DOC_Attach_DocID AND CRSE_DOC_USR_ID = '$uid' AND CRSE_DOC_CourseID = $cid 
                                  AND CRSE_DOC_Type = '$docType' AND CRSE_DOC_Year = $year";
        $submission_Status_Data = mysqli_query($con,$submission_Status_QRY);
        $submission_Status_result = mysqli_fetch_all($submission_Status_Data);
        $submitted_DOC = end(explode("/",$submission_Status_result[0][1]));

        $submission_Date = substr($submission_Status_result[0][0],0,11);
        $submission_time = substr($submission_Status_result[0][0],11,);
        $obtainedMarks = $submission_Status_result[0][2];
        // print_r($submission_Status_result);

        // Submission Details if any (CHECKING FOR TEXT UPLOAD).
        $submission_Status_TEXT_QRY = "SELECT CRSE_DOC_Submission,CRSE_DOC_DESC_Description,CRSE_DOC_Points FROM Mtb_CourseDocs_new, Tb_CourseDocDesc 
                                       WHERE CRSE_DOC_DocID = CRSE_DOC_DESC_DocID AND CRSE_DOC_USR_ID = '$uid' AND CRSE_DOC_CourseID = $cid 
                                       AND CRSE_DOC_Type = '$docType' AND CRSE_DOC_Year = $year";
        $submission_Status_TEXT_Data = mysqli_query($con,$submission_Status_TEXT_QRY);
        $submission_Status_TEXT_result = mysqli_fetch_all($submission_Status_TEXT_Data);
        $textSubmission = $submission_Status_TEXT_result[0][1];
        // print_r($submission_Status_TEXT_result);

        if(@$submission_Date) {
            # Do Nothing.
        } else {
            $submission_Date = substr($submission_Status_TEXT_result[0][0],0,11);
            $submission_time = substr($submission_Status_TEXT_result[0][0],11,);
            $obtainedMarks = $submission_Status_TEXT_result[0][2];
        }

        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['s']==2)
        {
            echo 
            '<script> 
                swal("Alert", "Please Choose a file or Type text.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==3)
        {
            echo 
            '<script> 
                swal("Alert", "Some error occured. Database Error Occured for Master Table.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==4)
        {
            echo 
            '<script> 
                swal("Alert", "Some error occured. Database Error for Transaction Table.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==5)
        {
            echo 
            '<script> 
                swal("Success", "'.$label.' Submitted Successfully.", "success");
            </script>
            ';
        }
        else if($_GET['s']==6)
        {
            echo 
            '<script> 
                swal("Alert", "Some error occured while moving file to destination location.\n\n Please try again.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==7)
        {
            echo 
            '<script> 
                swal("Alert", "File size must be lesser than 5 MB.\n\n  Upload Failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==8)
        {
            echo 
            '<script> 
                swal("Alert", "File size must be greater than 2 KB.\n\n  Upload Failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==9)
        {
            echo 
            '<script> 
                swal("Alert", "Invalid file.File must be PDF or DOCX extensioned.\n\n  Upload Failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==10)
        {
            echo 
            '<script> 
                swal("Alert", "Invalid file. File might be corrupted.\n\n Upload Failed.", "warning");
            </script>
            ';
        }
        else if($_GET['s']==11)
        {
            echo 
            '<script> 
                swal("Alert", "You cannot submit both file and descriptive text together at same time. Please choose any one only either file or text.\n\n Upload Failed.", "warning");
            </script>
            ';
        }
?>
<html>
    <head>
        <!-- Developer -->
        <meta name="author" content="Sanath Dinesh" />
        
        <title><?php echo "Course : ".$cid." ".$label; ?></title>
        <!-- For File Icons -->
        <link href="../css/css-file-icons.css?v=<?php echo time(); ?>" rel="stylesheet">
        <!-- Text Editor Script Files -->
        <script type="text/javascript" src="../tinymce-master/js/jquery.min.js"></script>
		<script type="text/javascript" src="../tinymce-master/plugin/tinymce/tinymce.min.js"></script>
		<script type="text/javascript" src="../tinymce-master/plugin/tinymce/init-tinymce.js"></script>
        <script>
            if (window.history.replaceState) 
            {
                window.history.replaceState( null, null, "assessmentDetails.php?cid=<?php echo base64_encode($cid);?>&id=<?php echo base64_encode($Doc_ID);?>&label=<?php echo base64_encode($label); ?>");
            }
        </script>
        <style>
            .mce-flow-layout-item.mce-last {
                display:none;
            }
            #assessText_ifr {
                height:450px!important;
            }
            .textInp {
                color: black;
                text-align: center;
                font-size: 17.1px;
                margin-left: -0.2%;
                /* box-shadow: 0 0 0.8px 0 grey; */
                margin-bottom: 0%;
                background-color: #f3f2f3;
                cursor: pointer;
                border: 1.5px solid rgb(90, 90, 90);
                border-radius: 2px;
                outline:none;
                padding: 0.25% 0.6% 0.25% 0.6%;
            }
        </style>
        <link rel="stylesheet" type="text/css" href="../css/boxicons.min.css">
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" style="margin-top:0.5%;margin-bottom:1%;" >
                    <div class="page-wrapper">
                        <div class="card mainBody" style="padding:2%;padding-bottom:0%;margin-bottom:0%;">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-15">
                                        <h4 style="font-weight:510;"><?php echo $cid." : ".$result['CRSE_Name'];?></h4>
                                        <hr style="margin-left:0%;margin-top:2%;" />
                                    </div>
                                    <div style="margin-left:1%;width:98.1%;min-height:43.3rem;">
                                        <h4 style="font-weight:bold;margin-bottom:1.8%;"><?php echo $label; ?> Details</h4>
                                        <form method="POST" enctype="Multipart/form-data" action="assessmentDetails_DB.php">
                                        <!-- Form Required Data  -->
                                            <input type="hidden" name="docID" value="<?php echo $Root_Result[0][0];?>"/>
                                            <input type="hidden" name="crseID" value="<?php echo $cid;?>"/>
                                            <input type="hidden" name="label" value="<?php echo $label;?>"/>
                                            <input type="hidden" name="docType" value="<?php echo $Root_Result[0][8];?>"/>
                                            <input type="hidden" name="docName" value="<?php echo $Root_Result[0][1];?>"/>
                                            <input type="hidden" name="prgmID" value="<?php echo $Root_Result[0][9];?>"/>
                                        <!--  -->
                                            <table class="table table-hover table-bordered" style="width:90%;margin-bottom:0%;" id="table">
                                                <thead>
                                                    <tr>
                                                        <th style="width:27%;">Name</th>
                                                        <td><?php echo $Root_Result[0][1];?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Assigned On</th>
                                                        <td><?php echo date("d-m-Y",strtotime($Root_Result[0][6]))." ".date("g:i A", strtotime($Root_Result[0][7]));?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Instructions / File<br/><br/></th>
                                                        <td style="white-space:pre-line;padding-top:0%;" > 
                                                            <?php 
                                                                echo $Root_Result[0][3];
                                                                if(@$Root_Result[0][12])
                                                                {
                                                                    echo '<br/>
                                                                    <a target="_new" href="../'.$Root_Result[0][12].'" style="font-size:17px;color:blue;display:flex;margin-top:0.3%;">'.explode(".",end(explode("-",$Root_Result[0][12])))[0].'&nbsp;
                                                                        <span style="margin-top:-0.7%;" class="fi fi-'.end(explode(".",$Root_Result[0][12])).'">&nbsp;<span class="fi-content">'.end(explode(".",$Root_Result[0][12])).'</span></span>
                                                                    </a>';
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th style="padding-bottom:1.5%;">Your Submission<br/><br/></th>
                                                        <td style="white-space:pre-line;padding-top:0%;">
                                                            <a target="_top" href="../Uploaded_Documents/<?php echo @$submitted_DOC; ?>" style="font-size:17px;color:blue;">
                                                                <?php 
                                                                    echo explode(".",end(explode("-",@$submitted_DOC)))[0];
                                                                    if(@$submitted_DOC) 
                                                                    echo ' <span class="fi fi-'.end(explode(".",@$submitted_DOC)).'">&nbsp;<div class="fi-content">'.end(explode(".",@$submitted_DOC)).'</div></span>';
                                                                ?>
                                                            </a>
                                                            <?php
                                                                if(@$textSubmission) echo $textSubmission;
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th>Submission Status</th>
                                                        <td>
                                                            <?php
                                                                #flag for upload file option (showing/hiding) along with submit & reset button (showing/hiding)
                                                                $flag = false;

                                                                if(@$submitted_DOC || @$textSubmission)
                                                                {
                                                                    // For Date
                                                                    $dueDate = $Root_Result[0][11];
                                                                    $date1=date_create("$submission_Date");
                                                                    $date2=date_create("$dueDate");
                                                                    $diff = date_diff($date1,$date2);

                                                                    $due_On = $dueDate." ".$Root_Result[0][10];
                                                                    $due_time = $Root_Result[0][10];
                                                                    
                                                                    // For Time
                                                                    $cal_DueDateTime = new DateTime($due_On);
                                                                    $cal_SubDateTime = $cal_DueDateTime->diff(new DateTime($submission_Date." ".$submission_time));
                                                                    $time = date('H:i:s',strtotime($submission_time));

                                                                    // echo $cal_SubDateTime->days.' days total<br>';
                                                                    // echo $cal_SubDateTime->y.' years<br>';
                                                                    // echo $cal_SubDateTime->m.' months<br>';
                                                                    // echo $cal_SubDateTime->d.' days<br>';
                                                                    // echo $cal_SubDateTime->h.' hours<br>';
                                                                    // echo $cal_SubDateTime->i.' minutes<br>';
                                                                    // echo $cal_SubDateTime->s.' seconds<br>';

                                                                    // echo "<pre>";
                                                                    // print_r($diff);
                                                                    // echo "</pre>";
                                                                   
                                                                    if($diff->format("%R%a") >= 0)
                                                                    {
                                                                        if($time < date($due_time)){
                                                                            echo '<label class="label label-success" style="font-size:17px;">'.$diff->format("%a days ").$cal_SubDateTime->format("%h hours & %i minutes & %s second ").'Earlier </label>';
                                                                            echo "On ".date("d-m-Y",strtotime($submission_Date))."&nbsp;@ ".date("g:i A", strtotime($submission_time));
                                                                        } else {
                                                                            echo '<label class="label label-warning" style="font-size:17px;">'.$diff->format("%a days ").$cal_SubDateTime->format("%h hours & %i minutes & %s second ").'Late </label>';
                                                                            echo "On ".date("d-m-Y",strtotime($submission_Date))."&nbsp;@ ".date("g:i A", strtotime($submission_time));
                                                                        }
                                                                        $flag = true;
                                                                    }
                                                                    else
                                                                    {
                                                                        echo '<label class="label label-warning" style="font-size:17px;">'.$diff->format("%a days ").$cal_SubDateTime->format("%h hours & %i minutes & %s second ").'Late</label>';
                                                                        echo "On ".date("d-m-Y",strtotime($submission_Date))."&nbsp;@ ".date("g:i A", strtotime($submission_time));
                                                                        $flag = true;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    echo '<label class="label label-danger"  style="font-size:17px;">Pending</label>';
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th>Due On</th>
                                                        <td><?php echo date("d-m-Y",strtotime($Root_Result[0][4]))." ".date("g:i A", strtotime($Root_Result[0][5]));?></td>
                                                    </tr>
                                                    <tr>
                                                        <th><?php echo $label; ?> Carries </th>
                                                        <td><?php echo $Root_Result[0][2]." marks.";?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Obtained Marks </th>
                                                        <td><?php echo $obtainedMarks." marks."; ?></td>
                                                    </tr>
                                                    <tr id="new_submit" style="display:none;">
                                                        <th>Submit Via</th>
                                                        <td style="display:flex;">
                                                            <div class="textInp" id="textUpload" onclick="show()" style="width:8rem;">Textual Based</div>&nbsp; OR &nbsp; 
                                                            <input type="file" id="assessFile" style="font-size:17px;cursor:pointer;" name="assessFile" />
                                                        </td>
                                                    </tr>
                                                </thead>
                                            </table>
                                            <script>
                                                function show()
                                                {
                                                    document.getElementById("textEditor").style.display="";
                                                    document.getElementById("table").style.display="none";
                                                    document.getElementById("showTableBtn").style.display="";
                                                    document.getElementById("Que").style.display="";
                                                }
                                                function showTable()
                                                {
                                                    document.getElementById("showTableBtn").style.display="none";
                                                    document.getElementById("table").style.display="";
                                                    document.getElementById("Que").style.display="none";
                                                }
                                                // function backBtn()
                                                // {
                                                //     history.go(-1);
                                                // }
                                            </script>
                                            <div class="textInp btn btn-primary btn waves-effect waves-light" id="showTableBtn" style="display:none;width:15%;" onclick="showTable()">Show Assignment Details</div>
                                            <div id="Que" style="display:none;margin-top:1%;font-size:18px;white-space:pre-line;"><?php echo $Root_Result[0][3];?></div>
                                            <!-- Text Editor API -->
                                            <div  id="textEditor" style="display:none;margin-top:1.5%;">
                                                <textarea class="tinymce" name="assessText" id="assessText" style="height:29rem;"></textarea>
                                            </div>
                                            <!--  -->
                                                <input type="submit" id="btnSubmit" name="btnSubmit" style="margin-top:1.5%;font-size:16px;margin-bottom:-0.85%;display:none;border-radius:7%;" 
                                                        class="btn btn-primary btn waves-effect waves-light" value="Submit"> &nbsp;
                                                <input type="reset" id="btnReset" style="margin-top:1.1%;padding-left:1.6%;font-size:16px;padding-right:1.6%;margin-bottom:-1.26%;border-radius:7%;display:none;" 
                                                        class="btn btn-primary btn waves-effect waves-light" value="Reset">
                                                <!-- <input type="button" style="margin-top:1%;padding-left:1.6%;padding-right:1.6%;margin-left:0.5%;" 
                                                        class="btn btn-primary btn-round waves-effect waves-light" onclick="backBtn()" value="Back"> -->
                                            <br/>
                                            <?php
                                                if($flag == false)
                                                {
                                                    echo 
                                                    '<script>
                                                        document.getElementById("new_submit").style.display="";
                                                        document.getElementById("btnSubmit").style.display="";
                                                        document.getElementById("btnReset").style.display="";
                                                    </script>
                                                    ';
                                                }
                                            ?>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>