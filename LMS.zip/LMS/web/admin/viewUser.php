<?php 
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {  
        include_once("adminNavbar.php");
        include_once("../COMMON_FILES/Connection.php");
        $query ="SELECT USR_ID,USR_FirstName,USR_LastName,USR_Pic,USR_Role FROM Mtb_Users";
        $data = mysqli_query($con,$query);
?>
<html>
    <head>
        <title>Users</title>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <?php
                    while ($result = mysqli_fetch_array($data)) 
                    {
                ?> 
                <!-- For Responsive Behaviour -->
                <div class="col-md-4">
                    <div class="card user-card" style="margin-top:5%;">
                        <div class="card-block">
                            <div class="user-image">
                                <img src="../<?php echo $result['USR_Pic']; ?>" class="img-radius"alt="User-Profile-Image">
                                <!-- <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-radius"alt="User-Profile-Image"> -->
                            </div>
                            <h6 class="f-w-600 m-t-25 m-b-10"><?php echo $result['USR_FirstName']." ".$result['USR_LastName']; ?></h6>
                            <p class="text-muted">
                                User ID : <?php echo $result['USR_ID']; ?></p>
                            <hr/>
                            <p class="text-muted m-t-15">
                                <?php 
                                    if(substr($result['USR_ID'],0,1)=="S")
                                    {
                                        echo "Programme : BCA";
                                    }
                                    else
                                    {
                                        echo "Role : ".$result['USR_Role'];
                                    }
                                ?>
                               
                            </p>
                            <!-- <ul class="list-unstyled activity-leval">
                                <li class="active"></li>
                                <li class="active"></li>
                                <li class="active"></li>
                                <li></li>
                                <li></li>
                            </ul> -->
                            <div class="bg-c-blue counter-block m-t-10 p-10">
                                <div class="row">
                                    <!-- <div class="col-4">
                                        <i class="fa fa-comment"></i>
                                        <p>1256</p>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-user"></i>
                                        <p>8562</p>
                                    </div>
                                    <div class="col-4">
                                        <i class="fa fa-suitcase"></i>
                                        <p>189</p>
                                    </div> -->
                                    <span style="margin-left:45%;cursor:pointer;">View</span>
                                </div>
                            </div>
                            <!-- <div class="row justify-content-center user-social-link">
                                <div class="col-auto"><a href="#!"><i class="fa fa-facebook text-facebook"></i></a></div>
                                <div class="col-auto"><a href="#!"><i class="fa fa-twitter text-twitter"></i></a></div>
                                <div class="col-auto"><a href="#!"><i class="fa fa-dribbble text-dribbble"></i></a></div>
                            </div> -->
                        </div>
                    </div>
                </div>
                <?php 
                    } 
                ?>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>