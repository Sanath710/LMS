<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {    
        include ("adminNavbar.php");
        if($_GET['s']==1)
        {
            $ERROR = "border:1px solid red;";
            $ERROR_MSG = "<span style='color:red; font-size:14px;'>Please Enter Some Other Program ID.<br/>Previously Entered Program ID was Already Taken.!</span>";
        }
        elseif($_GET['s']==2)
        {
            echo 
                '<script src="../COMMON_FILES/sweetalert.min.js"></script>
                <script> 
                    swal("Success", "Programme Added successfully", "success");
                </script>
            ';
        }
        else if($_GET['s']==3)
        {
            
            echo 
                '<script src="../COMMON_FILES/sweetalert.min.js"></script>
                <script> 
                    swal("warning", "Invalid Data or No Data Received.!!", "warning");
                </script>
            ';
        }
        if($_GET['s']==4)
        {
            echo 
                '<script src="../COMMON_FILES/sweetalert.min.js"></script>
                <script> 
                    swal("warning", "ERROR in Prepare Statement.!", "warning");
                </script>
            ';
        }
?>
<html>
    <head>
        <title>New Program</title>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="main-body frmTxt">
                <div class="page-wrapper">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card mainBody bodyStyling">
                                <div class="card-header">
                                    <h4>New Programme</h4><hr/>
                                </div><br/><br/>
                                <div class="card-block progFormBody">
                                    <form id="main" method="POST" action="newProgram_DB.php">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label frmTxt">Programme ID</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control frmTxt" style='<?php echo $ERROR; ?>' name="ProgramID" autocomplete="off" id="ProgramID" required onkeyup="valueCheck()"
                                                    pattern ="[A-Za-z]{3}[A-Za-z\s]{0,}" title="Enter only aphabetical characters of minimum length of three" minLength="3" maxlength ="4" 
                                                    placeholder="Enter Programme ID (Maximum length 4)"/>
                                                <span id="messages"><?php echo $ERROR_MSG; ?></span>
                                            </div>
                                        </div>
                                        <br/>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label frmTxt">Programme Name</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control frmTxt" name="ProgramName" autocomplete="off" id="ProgramName" required onkeyup="valueCheck()"
                                                    pattern ="[A-Za-z]{1,}[A-Za-z\s]{1,}" title="Enter only aphabetical characters"  placeholder="Enter Programme Name "/>
                                            </div>
                                        </div>
                                        <br/>
                                        <div class="row">
                                            <label class="col-sm-2 col-form-label frmTxt">Programme status</label>
                                            <div class="col-sm-4">
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        Active <input type="radio" name="ProgramStatus" value="1" checked/>
                                                    </label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        Deactive <input type="radio" name="ProgramStatus" value="0"/>
                                                    </label>
                                                </div>
                                                <span class="messages"></span>
                                            </div>
                                        </div>
                                        <br/>
                                        <div class="form-group row">
                                            <label class="col-sm-2"></label>
                                            <div class="col-sm-4">
                                                <input type="submit" class="btn btn-primary m-b-0 btnEffect btnSubmit" name="btnSubmit" id="Submit" onclick="return inputChecker()"/>
                                                <input type="reset" class="btn btn-primary m-b-0 btnEffect btnSubmit" onmouseout="valueCheck()"/>
                                            </div>
                                        </div>
                                    </form>
                                    <script>
                                        if(document.getElementById("ProgramID").value == '' || document.getElementById("ProgramName").value == '')
                                        {
                                            var x = document.querySelector("#Submit");
                                            x.style.display = "none";
                                        }
                                        function valueCheck() 
                                        {
                                            if(document.getElementById("ProgramID").value != '' && document.getElementById("ProgramName").value != '')
                                            {
                                                x.removeAttribute("style");
                                            }
                                            else
                                            {
                                                styleAttr = document.createAttribute("style");
                                                styleAttr.value = "display:none";
                                                x.setAttributeNode(styleAttr);
                                            }
                                        }
                                        function inputChecker() 
                                        {
                                            if(document.getElementById("ProgramID").value == '')
                                            {
                                                alert("Enter Program ID");
                                                
                                                return false;
                                            }
                                            else if(document.getElementById("ProgramName").value == '')
                                            {
                                                alert("Enter Program Name");
                                                return false;
                                            }
                                            return true;
                                        }
                                        if ( window.history.replaceState ) 
                                        {
                                            window.history.replaceState( null, null, "newProgram.php");
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>