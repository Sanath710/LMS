<?php
    session_start();
    include("../COMMON_FILES/Connection.php");

    $PID =  $_POST['PID'];
    $ProgramID = $_POST['ProgramID'];
    $ProgramName = $_POST['ProgramName'];
    $ProgramStatus = strtoupper(implode($_POST['ProgramStatus']));
    $Selection = $_POST['Operation'];
    $ProgramStatusError ='';
    // error_reporting(0);

    if(!$ProgramID)
    {
        header("refresh:0;url=viewPrograms.php?s=6");
    }
    else if(!$ProgramName)
    {
        header("refresh:0;url=viewPrograms.php?s=7");
    }

    if(!empty($ProgramID) && !empty($ProgramName))
    {
        if($Selection == 'Update')
        {
            $sql = "UPDATE Mtb_Programme SET PRGM_ID='$ProgramID',PRGM_Name='$ProgramName', PRGM_Status=$ProgramStatus WHERE PID='$PID'";
        }
        else if($Selection == 'Remove')
        {
            $sql = "DELETE FROM Mtb_Programme where PRGM_ID='$ProgramID'";
        }

        if(!mysqli_query($con,$sql))
        {
            header("refresh:0;url=viewPrograms.php?s=8");
        }
        else 
        {
            header("refresh:0;url=viewPrograms.php?s=5");
        }
    }

?>