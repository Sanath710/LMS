<?php
   
//    function myfun() {
//     $courses = array("30010413","30010414","30010415","30010416","30010417");
//     $c1=$c2=$c3=$c4=$c5=0;
//     // $teachers = array("t1","t2","t3","t4","t5");
//     // $timings = array("08:15","03:45");
//     // $break = array("11:15","11:50","01:45","01:55");

//     $fitness = 0;
//     $day = 0;
//     echo '<table style="border:1px solid black;width:50%;height:35rem;">';
//     for($i = 0; $i < 5; $i++) 
//     {
//         echo '<tr>';

//         for($j = 0; $j <5; $j++)
//         {
//             $course = $courses[array_rand($courses)];

//             echo 
//             '<td>
//                 '.$course;
//                 if($course == $courses[0]  || $c1 >5) 
//                 {   
//                     $c1++; 
//                     if($c1 > 8) 
//                     {continue;}
//                 }
//                 else if($course == $courses[1] || $c2 >5)
//                 {
//                     if($c2 > 8) 
//                     {continue;}
//                     $c2++; 

//                 }
//                 else if($course == $courses[2] || $c2 >5)
//                 {
//                     if($c3 > 8) 
//                     {continue;}
//                     $c3++; 

//                 }
//                 else if($course == $courses[3] || $c3 >5)
//                 {
//                     $c4++; 
//                     if($c4 > 8) 
//                     {continue;}
//                 }
//                 else if($course == $courses[4] || $c4 >5)
//                 {
//                     $c5++; 
//                     if($c5 > 8) 
//                     {continue;}
//                 }
//             echo'
//             </td>';

//         }
//         echo '</tr>';

//     }
//     echo '</table>';
//     echo $c1." ".$c2." ".$c3." ".$c4." ".$c5;
// }
// myfun();


    include("../COMMON_FILES/Connection.php");
    $sql = "SELECT USR_ID,CRSE_USR_CourseID,CRSE_SCHED_StartTime FROM Mtb_Users,Tb_CourseUsers,Mtb_CourseSchedule 
            WHERE substring(CRSE_USR_CourseID,5,2) = 4 AND USR_ID LIKE 'T%' AND UID = CRSE_USR_UID AND CRSE_SCHED_CourseID = CRSE_SCHED_CourseID
            ";
    $data = mysqli_query($con,$sql);
    echo "<pre>";
    print_r(mysqli_fetch_all($data));
    echo "</pre>";





?>