<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {   
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
      include_once("adminNavbar.php");
    }
    else if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
      include_once("../HoD/teacherNavbar.php");
    }
    include("../COMMON_FILES/Connection.php");
    $PRGM_QRY = "SELECT PRGM_CRSE_PID,PRGM_ID FROM Tb_ProgrammeCourseTypes,Mtb_Programme WHERE PID = PRGM_CRSE_PID GROUP BY PID";
    $PRGM_Data = mysqli_query($con,$PRGM_QRY);
    $CRSE_QRY = "SELECT PRGM_CRSE_CourseID FROM Tb_ProgrammeCourseTypes GROUP BY PRGM_CRSE_CourseID";
    $CRSE_Data = mysqli_query($con,$CRSE_QRY);
    if($_GET['s']==2)
    {
      echo 
          '<script src="../COMMON_FILES/sweetalert.min.js"></script>
          <script> 
            swal("Sorry", "This course is already assigned previously in selected programme.!", "info");
          </script>
      ';
    }
    elseif($_GET['s']==3)
    {
      echo 
          '<script src="../COMMON_FILES/sweetalert.min.js"></script>
          <script> 
            swal("Success", "Course for the day assigned successfully.", "success");
          </script>
      ';
    }
    if($_GET['s']==4)
    {
      echo 
          '<script src="../COMMON_FILES/sweetalert.min.js"></script>
          <script> 
            swal("warning", "ERROR in Prepare Statement.!", "warning");
          </script>
      ';
    }
    if($_GET['s']==5)
    {
      echo 
          '<script src="../COMMON_FILES/sweetalert.min.js"></script>
          <script> 
            swal("warning", "Please select all fields.!", "warning");
          </script>
      ';
    }
?>
<html>

  <head>
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="../css/icofont.css">
    <script src="../COMMON_FILES/sweetalert.min.js"></script>
    <script>
      if (window.history.replaceState) {
        window.history.replaceState(null, null, "newSchedule.php");
      }
    </script>
  </head>

  <body>
    <div class="pcoded-content">
      <!-- Main Body Starts -->
      <div class="main-body">
        <div class="page-wrapper subBodyProgram">
          <!-- <div class="page-body"> -->
          <div class="card bodyStyling" style="padding-left:0.5%;">
            <div class="card-header" style="margin-top:0.5%;">
              <h4>Create Schedule</h4>
              <hr style="width:97.5%; margin-left:0%;" />
            </div>
            <div class="card-block">
              <div class="dt-responsive table-responsive tableView">
                <br />
                <table style="width:100%;margin-left:-0.5%;" class="table table-striped table-bordered tableViewProgram">
                  <thead>
                    <tr>
                      <th style="width:11%;padding-left:3.1%;">Programme ID</th>
                      <th style="width:11%;padding-left:4.5%;">Course ID</th>
                      <th style="width:11%;padding-left:5.8%;">Day</th>
                      <th style="width:11%;padding-left:4.2%;">Start Time</th>
                      <th style="width:11%;padding-left:4.5%;">End Time</th>
                      <th style="width:11%;padding-left:6%;">Div</th>
                      <th style="width:11%;text-align:center;">Add</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                  <!-- Form For New Schedule -->
                      <form action="newSchedule_DB.php" method="POST">
                        <td class="height_td">
                          <select name='selProgramID' id="selProgramID" style="width:100%;height:2rem;border:none;">
                            <option value='x'>Select Programme</option>
                            <?php
                                while($r = mysqli_fetch_assoc($PRGM_Data))
                                {
                                    echo "<option value='".$r['PRGM_CRSE_PID']."'>".$r['PRGM_ID']."</option>";
                                }
                              ?>
                          </select>
                        </td>
                        <td>
                          <select name='selCourseID' id="selCourseID" style="width:100%;height:2rem;border:none;">
                            <option value='x'>Select Course</option>
                            <?php
                                while($r = mysqli_fetch_assoc($CRSE_Data))
                                {
                                    echo "<option value='".$r['PRGM_CRSE_CourseID']."'>".$r['PRGM_CRSE_CourseID']."</option>";
                                }
                              ?>
                          </select>
                        </td>
                        <td>
                          <select name="selDay" id="selDay" style="width:100%;height:2rem;border:none;">
                            <option value='x'>Select Day</option>
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                          </select>
                        </td>
                        <td>
                          <select name="selStartTime" id="selStartTime" style="width:100%;height:2rem;border:none;">
                            <option value='x'>Select Start Time</option>
                            <option value="08:30">08:30 am</option>
                            <option value="08:45">08:45 am</option>
                            <option value="09:00">09:00 am</option>
                            <option value="09:15">09:15 am</option>
                            <option value="09:30">09:30 am</option>
                            <option value="09:45">09:45 am</option>
                            <option value="10:00">10:00 am</option>
                            <option value="10:15">10:15 am</option>
                            <option value="10:30">10:30 am</option>
                            <option value="10:45">10:45 am</option>
                            <option value="11:00">11:00 am</option>
                            <option value="11:15">11:15 am</option>
                            <option value="11:30">11:30 am</option>
                            <option value="11:45">11:45 am</option>
                            <option value="12:00">12:00 pm</option>
                            <option value="12:15">12:15 pm</option>
                            <option value="12:30">12:30 pm</option>
                            <option value="12:45">12:45 pm</option>
                            <option value="13:00">13:00 pm</option>
                            <option value="13:15">13:15 pm</option>
                            <option value="13:30">13:30 pm</option>
                            <option value="13:45">13:45 pm</option>
                            <option value="14:00">14:00 pm</option>
                            <option value="14:15">14:15 pm</option>
                            <option value="14:30">14:30 pm</option>
                            <option value="14:45">14:45 pm</option>
                            <option value="15:00">15:00 pm</option>
                            <option value="15:15">15:15 pm</option>
                            <option value="15:30">15:30 pm</option>
                            <option value="15:45">15:45 pm</option>
                          </select>
                        </td>
                        <td>
                          <select name="selEndTime" id="selEndTime" style="width:100%;height:2rem;border:none;">
                            <option value='x'>Select End Time</option>
                            <option value="08:45">08:45 am</option>
                            <option value="09:00">09:00 am</option>
                            <option value="09:15">09:15 am</option>
                            <option value="09:30">09:30 am</option>
                            <option value="09:45">09:45 am</option>
                            <option value="10:00">10:00 am</option>
                            <option value="10:15">10:15 am</option>
                            <option value="10:30">10:30 am</option>
                            <option value="10:45">10:45 am</option>
                            <option value="11:00">11:00 am</option>
                            <option value="11:15">11:15 am</option>
                            <option value="11:30">11:30 am</option>
                            <option value="11:45">11:45 am</option>
                            <option value="12:00">12:00 pm</option>
                            <option value="12:15">12:15 pm</option>
                            <option value="12:30">12:30 pm</option>
                            <option value="12:45">12:45 pm</option>
                            <option value="13:00">13:00 pm</option>
                            <option value="13:15">13:15 pm</option>
                            <option value="13:30">13:30 pm</option>
                            <option value="13:45">13:45 pm</option>
                            <option value="14:00">14:00 pm</option>
                            <option value="14:15">14:15 pm</option>
                            <option value="14:30">14:30 pm</option>
                            <option value="14:45">14:45 pm</option>
                            <option value="15:00">15:00 pm</option>
                            <option value="15:15">15:15 pm</option>
                            <option value="15:30">15:30 pm</option>
                            <option value="15:45">15:45 pm</option>
                          </select>
                        </td>
                        <td>
                          <select name="selDiv" id="selDiv" style="width:100%;height:2rem;border:none;">
                            <option value='x'>Select Div</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                          </select>
                        </td>
                        <td style="text-align:center;background-color:white;">
                        <button class="btn waves-effect waves-dark btn-success btn-outline-success btn-icon" style="padding-bottom:1%;" name="btnAdd" onclick="return check()">
                          <i class="icofont icofont-check-circled" style="padding-left:15%;"></i>
                        </button>
                          <!-- <input type="submit" class="PGSubmit"
                            style="margin-left:3.5%;margin-top:2.5%;width:70%;font-size:17.5px;padding:0.5%;"
                            name="btnAdd" onclick="return dataCheck()" value="Assign" /> -->
                        </td>
                        <!-- <script>
                          function setSCHED() 
                          {
                            let program = document.getElementById("selProgramID").value;
                            let course = document.getElementById("selCourseID").value;
                            let day = document.getElementById("selDay").value;
                            let div = document.getElementById("selDiv").value;
                            let ST = document.getElementById("selStartTime").value;
                            let ET = document.getElementById("selEndTime").value;

                            if (program == "Null" || course == "Null" || day == "Null" || div == "Null" || ST == "Null" || ET == "Null") 
                            {
                              // Do Nothing :)
                            }
                            else 
                            {
                              let xhr0;

                              (window.XMLHttpRequest) ? xhr0 = new XMLHttpRequest() : xhr0 = new ActiveXObject("Microsoft.XMLHTTP");

                              let data0 = "program=" + program + "&course=" + course + "&day=" + day + "&div=" + div + "&st=" + ST + "&et=" + ET;

                              xhr0.open("POST", "newSchedule_DB.php", true);
                              xhr0.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                              xhr0.send(data0);

                              xhr0.onreadystatechange = display;

                              function display() 
                              {
                                if (xhr0.readyState == 4) 
                                {
                                  if (xhr0.status == 200) 
                                  {
                                    // document.getElementById("yo").innerHTML = xhr0.responseText;
                                    // swal("Success", "Course for the day assigned successfully.", "success");
                                  }
                                  else 
                                  {
                                    alert("There was a problem with the request");
                                  }
                                }
                              }
                            }
                          }
                        </script>
                        <noscript>Your browser doesnot support JavaScript!</noscript> -->
                      </form>
                  </tbody>
                </table>
                <script>
                    function check()
                    {
                      if(document.getElementById("selProgramID").value == 'x')
                      {
                        swal("Oops.!!", "You forgot to select a Programme.!", "warning");
                        return false;
                      }
                      if(document.getElementById("selCourseID").value == 'x')
                      {
                        swal("Oops.!!", "You forgot to select a Course.!", "warning");
                        return false;
                      }
                      if(document.getElementById("selDay").value == 'x')
                      {
                        swal("Oops.!!", "You forgot to select Day.!", "warning");
                        return false;
                      }
                      if(document.getElementById("selStartTime").value == 'x')
                      {
                        swal("Oops.!!", "You forgot to select Start Time.!", "warning");
                        return false;
                      }
                      if(document.getElementById("selEndTime").value == 'x')
                      {
                        swal("Oops.!!", "You forgot to select End Time.!", "warning");
                        return false;
                      }
                      if(document.getElementById("selDiv").value == 'x')
                      {
                        swal("Oops.!!", "You forgot to select Division.!", "warning");
                        return false;
                      }
                    }
                </script>
                <hr style="width:100%; margin-left:-0.4%;margin-top:1.4%" />
              </div>
            </div>
          </div>
          <div class="card bodyStyling" style="padding-left:0.5%;">
            <div class="card-header" style="margin-top:0.5%;">
              <h4>View Schedule</h4>
              <hr style="width:97.5%; margin-left:0%;" />
            </div>
            <div class="card-block">
              <div class="dt-responsive table-responsive tableView">
                <br />
                <table style="width:40%;margin-left:-0.5%;" class="table-striped">
                  <thead>
                    <tr>
                      <th style="width:1.5%;padding-bottom:2%;">Programme</th>
                      <th style="width:3%;padding-bottom:2%;">Semester</th>
                      <th style="width:3%;padding-bottom:2%;">Division</th>
                      <th style="width:4%;padding-bottom:2%;">Year</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <form action="newSchedule_DB.php" method="POST">
                        <td class="height_td">
                          <select name='selPRO_ID' id="PRO" onchange="getSCHED()" style="width:100%;height:2rem;border:none;">
                            <option value=''>Select</option>
                            <?php
                                $PRO_QRY = "SELECT CRSE_SCHED_PID,PRGM_ID FROM Mtb_CourseSchedule,Mtb_Programme WHERE PID = CRSE_SCHED_PID GROUP BY PID";
                                $PRO_Data = mysqli_query($con,$PRO_QRY);
                                while($r = mysqli_fetch_assoc($PRO_Data))
                                {
                                    echo "<option value='".$r['CRSE_SCHED_PID']."'>".$r['PRGM_ID']."</option>";
                                }
                            ?>
                          </select>
                        </td>
                        <td>
                          <select name='selSEM' id="SEM" onchange="getSCHED()" style="width:100%;height:2rem;border:none;">
                            <option value=''>Select</option>
                            <?php
                                $Sem_QRY = "SELECT substring(CRSE_SCHED_CourseID,6,1) AS Sem FROM Mtb_CourseSchedule GROUP BY substring(CRSE_SCHED_CourseID,6,1)";
                                $Sem_Data = mysqli_query($con,$Sem_QRY);
                                while($r = mysqli_fetch_assoc($Sem_Data))
                                {
                                    echo "<option value='".$r['Sem']."'>".$r['Sem']."</option>";
                                }
                            ?>
                          </select>
                        </td>
                        <td>
                          <select name="selDivision" id="DIV" onchange="getSCHED()" style="width:100%;height:2rem;border:none;">
                            <option value=''>Select</option>
                            <?php
                                $Div_QRY = "SELECT CRSE_SCHED_Division FROM Mtb_CourseSchedule GROUP BY CRSE_SCHED_Division";
                                $Div_Data = mysqli_query($con,$Div_QRY);
                                while($r = mysqli_fetch_assoc($Div_Data))
                                {
                                    echo "<option value='".$r['CRSE_SCHED_Division']."'>".$r['CRSE_SCHED_Division']."</option>";
                                }
                            ?>
                          </select>
                        </td>
                        <td>
                          <select name="selYEAR" id="YEAR" onchange="getSCHED()" style="width:100%;height:2rem;border:none;">
                            <option value=''>Select</option>
                            <?php
                                $Year_QRY = "SELECT CRSE_SCHED_Year FROM Mtb_CourseSchedule GROUP BY CRSE_SCHED_Year";
                                $Year_Data = mysqli_query($con,$Year_QRY);
                                while($r = mysqli_fetch_assoc($Year_Data))
                                {
                                    echo "<option value='".$r['CRSE_SCHED_Year']."'>".$r['CRSE_SCHED_Year']."</option>";
                                }
                              ?>
                          </select>
                        </td>
                        <script>
                          function getSCHED() 
                          {
                            let program = document.getElementById("PRO").value;
                            let year = document.getElementById("YEAR").value;
                            let sem = document.getElementById("SEM").value;
                            let div = document.getElementById("DIV").value;

                            if (program == "Null" || year == "Null" || sem == "Null" || div == "Null") 
                            {
                              // Do Nothing :)
                            }
                            else 
                            {
                              let xhr;

                              (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");

                              let data = "program=" + program + "&year=" + year + "&sem=" + sem+ "&div=" +div;

                              xhr.open("POST", "AJAX_ViewSchedule_DB.php", true);
                              xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                              xhr.send(data);
                              xhr.onreadystatechange = display_data;

                              function display_data() 
                              {
                                if (xhr.readyState == 4) 
                                {
                                  if (xhr.status == 200) 
                                  {
                                    document.getElementById("resSchedule").innerHTML = xhr.responseText;
                                  }
                                  else 
                                  {
                                    alert("There was a problem with the request");
                                  }
                                }
                              }
                            }
                          }
                        </script>
                        <noscript>Your browser doesnot support JavaScript!</noscript>
                      </form>
                  </tbody>
                </table>
                <br/>
                <div style="margin-left:-0.5%;width:100%;" id="resSchedule">
                          <!-- View Schedule -->
                </div>
                <hr style="width:100%; margin-left:-0.4%;margin-top:1.4%" />
              </div>
            </div>
          </div>
        </div>
      </div>
  </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>