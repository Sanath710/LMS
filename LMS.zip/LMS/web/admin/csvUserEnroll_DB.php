<?php
    session_start();
    // error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
        $Programme = $_POST['prgmSelect'];
        $Role = $_POST['userRole'];

        # info for operation events
        $flag = false;
        $newID = null;
        $duplicate = 0;
        $insertError = 0;
        $insertSuccess = 0;

        # Accepted MIME types
        $csvMimes = array(
                            'text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 
                            'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 
                            'application/excel', 'application/vnd.msexcel', 'text/plain'
                        );

        # Checking if file is CSV or not
        if(in_array($_FILES['csvFileUpload']['type'], $csvMimes))
        {
            # If the file is uploaded
            if(is_uploaded_file($_FILES['csvFileUpload']['tmp_name'])) 
            {
                # Connection file.
                include_once ("../COMMON_FILES/Connection.php");

                # Opening CSV file in READ mode.
                $csvFile = fopen($_FILES['csvFileUpload']['tmp_name'], 'r');
                
                # Neglecting the first line Data
                fgetcsv($csvFile);
                
                #For generating a random password
                $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
                $password = array(); 
                $alphaLength = strlen($alphabet) - 1; 
                for ($i = 0; $i < 12; $i++) {
                    $n = rand(0, $alphaLength);
                    $password[] = $alphabet[$n];
                }
                $pass = implode($password);

                #For generating Student ID 
                function Stud_ID_Creation($con,$Programme)
                {
                    $d = date("Y");
                   
                    $d.=$Programme;
                    $QRY_uID = "SELECT USR_ID FROM Mtb_Users WHERE USR_Role = 'Student' and substring(USR_ID,2,7)='$d' order by USR_ID desc Limit 1";
                    $data = mysqli_query($con,$QRY_uID);
                    @$UID = substr(implode(mysqli_fetch_assoc($data)),1,11);
                    $temp = (int)substr($UID,0,10)+1;
                    $newID = "S".$temp;
                    #If there is no previous record available then generating new record.
                    if(!$UID) 
                    {
                        $newID = "S".$d."001";
                    }
                    return $newID;
                }


                #For generating HoD/Teacher ID 
                function TCHR_ID_Creation($con,$role)
                {
                    $d = date("Y");
                    $QRY_uID = "SELECT USR_ID FROM Mtb_Users WHERE USR_Role = '$role' and substring(USR_ID,2,4)='$d' order by USR_ID desc Limit 1";
                    $data = mysqli_query($con,$QRY_uID);
                    @$UID = substr(implode(mysqli_fetch_assoc($data)),1,10);
                    $temp = (int)substr($UID,0,10)+1;
                    # For T (Teacher)/ H (HoD) => (Indication first charcter at index 0)
                    $char_0_Role  = substr($role,0,1);
                    $newID = $char_0_Role.$temp;
                    if(!$UID)
                    {
                        $newID = $char_0_Role.$d."00001";
                    }
                    return $newID;
                }

                # Parse data from CSV file line by line
                while(($col = fgetcsv($csvFile)) !== FALSE) 
                {
                    $flag = true;

                    # Regex for Name fields
                    $regexName = '/^[a-zA-Z]*$/';

                    # Get row data
                    $firstName  = trim(strval($col[0]));
                    $lastName   = trim(strval($col[1]));
                    $emailID    = trim(strval($col[2]));
                    $contactNo  = trim(intval($col[3]));
                    $aadhaarNo  = trim(intval($col[4]));
                    $gender     = strtoupper(trim(substr($col[5],0,1)));

                    if(preg_match($regexName,$firstName) && preg_match($regexName,$lastName) && preg_match('/^[0-9]{10}+$/',$contactNo) &&  preg_match('/^[0-9]{12}+$/',$aadhaarNo) && preg_match('/^[a-zA-Z]{1,6}+$/',$gender))
                    {
                        # checking if user is already enrolled or not 
                        $priorCheck_QRY = "SELECT USR_EmailID FROM Mtb_Users WHERE USR_EmailID = '$emailID' || USR_AadharNo = '$aadhaarNo'";
                        $priorCheckData = mysqli_query($con,$priorCheck_QRY);
                        $priorCheck_Result = mysqli_fetch_assoc($priorCheckData);
                        @$priorCheck_Result = $priorCheck_Result['USR_EmailID'];

                        if($priorCheck_Result)
                        {
                            $duplicate++;
                        }
                        else 
                        {
                            # Checking Enroll User As...
                            if($Role == "HoD")
                            {
                                $newID = TCHR_ID_Creation($con,"HoD");
                            }
                            else if($Role == "Student")
                            {
                                $newID = Stud_ID_Creation($con,$Programme);
                            }
                            else if($Role == "Teacher")
                            {
                                $newID = TCHR_ID_Creation($con,"Teacher");
                            }
                            $Insert_QRY = "INSERT INTO Mtb_Users (USR_ID,USR_FirstName, USR_LastName, USR_EmailID,USR_ContactNo,USR_AadharNo,USR_Gender,USR_Role,USR_Password) 
                                           VALUES ('$newID','$firstName','$lastName','$emailID','$contactNo','$aadhaarNo','$gender','$Role','$pass')";
                            if(!mysqli_query($con,$Insert_QRY)) {
                                $insertError++;
                            } 
                            else if((substr($newID,0,1) != "H") && (substr($newID,0,1) != "T") && (substr($newID,0,1) != "A"))
                            {
                                $insertSuccess++;
                                # Transaction Query
                                $insert_QRY = "INSERT INTO Tb_CourseUsers(CRSE_USR_UID,CRSE_USR_PID,CRSE_USR_CourseID,CRSE_USR_Year,CRSE_USR_Sem,CRSE_USR_Status) 
                                               Values(?,?,?,?,?,?)";
                                $stmt = mysqli_stmt_init($con);
                                if(!mysqli_stmt_prepare($stmt,$insert_QRY))
                                {
                                    header("refresh:0;url=enrollUser.php?status=6");    # Error in Prepare Statement for transaction table
                                } 
                                else 
                                {
                                    # Preparing Data Set Required.
                                    $getUID = "SELECT UID FROM Mtb_Users WHERE USR_ID = '$newID'";
                                    $UID_Data = mysqli_query($con,$getUID);
                                    $newUID = mysqli_fetch_assoc($UID_Data);
                                    $newUID = $newUID["UID"];
                                    #
                                    $getPID = "SELECT PID, PRGM_Code FROM Mtb_Programme WHERE PRGM_Code = '$Programme'";
                                    $getPIDData = mysqli_query($con,$getPID);
                                    $PID = mysqli_fetch_assoc($getPIDData);
                                    $PCode = $PID['PRGM_Code'];
                                    $PID = $PID['PID'];
                                    #
                                    $getCourse = "SELECT CRSE_ID FROM Mtb_Courses WHERE substring(CRSE_ID,6,1)=1 AND substring(CRSE_ID,1,3) = RPAD($PCode,3,0)";
                                    $getCourseData = mysqli_query($con,$getCourse);
                                    $year = date("Y");
                                    $userStatus = 1;
                                    $sem = 1;

                                    while($course = mysqli_fetch_assoc($getCourseData))
                                    {
                                        $course = $course['CRSE_ID'];
                                        mysqli_stmt_bind_param($stmt,"iiiiii",$newUID,$PID,$course,$year,$sem,$userStatus);
                                        if(!mysqli_stmt_execute($stmt))
                                        {
                                            $flag = false;
                                            # Deleting record from master table if even a single course insertion fails.    (Rollback)
                                            $deleteQRY = "DELETE FROM Mtb_Users WHERE USR_ID = '$newID'";
                                            mysqli_query($con,$deleteQRY);
                                            header("refresh:0;url=enrollUser.php?status=2");    # Something went wrong. Enrolling failed.
                                        }
                                    }
                                }
                            } else {
                                $insertSuccess++;
                            }
                        }
                    }
                    else {
                       $insertError++;
                    }
                }
                if($flag == true) {
                    header("refresh:0;url=enrollUser.php?status=8&err=$insertError&succ=$insertSuccess&duplicate=$duplicate"); 
                }
                # Close file
                fclose($csvFile);
            }
            else {
                # File Upload Error
                header("refresh:0;url=enrollUser.php?status=7"); 
            }
        }
        else {
            # Invalid File.
            header("refresh:0;url=enrollUser.php?status=4");
        }
    }
    else
    {
        echo "You Don't have previleges to access this page.<br/>";
        header("refresh:2;url=../COMMON_FILES/logout.php");
    }
?>