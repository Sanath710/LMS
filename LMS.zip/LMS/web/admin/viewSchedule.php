<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {   
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
      include_once("adminNavbar.php");
    }
    else if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
      include_once("../HoD/teacherNavbar.php");
    }
    include("../COMMON_FILES/Connection.php");
    
?>
<html>

<head>
  <style>
    #submit:hover,
    #reset:hover {
      background-color: rgb(2, 223, 2) !important;
      border: 1px solid rgb(85, 0, 221) !important;
    }

    table td 
    {
      padding: 2% !important;
    }
    
    table th,
    table td {
      padding: 1% !important;
      text-align: center;
      /* vertical-align: inherit !important; */
    }

    .card .card-block {
      padding: 0%!important;
      padding-right: 1%;
    }

    .tableView {
      padding-left: 0.5%;
    }

    .table thead th {
      /* border-bottom: 1px solid #d6dde1;
                border-top: none;
                border-left: none;
                border-right: none;*/
    }

    table {
      /* border:none!important; */
      margin-top: 2%;
      margin-left: 1.8%;
    }
  </style>
  <script src="../COMMON_FILES/sweetalert.min.js"></script>
  <script>
    if (window.history.replaceState) 
    {
        window.history.replaceState( null, null, "viewSchedule.php");
    }
  </script>
</head>

<body>

  <div class="pcoded-content">
    <!-- Main Body Starts -->
    <div class="main-body" style="margin-top:0.5%;">
      <div class="page-wrapper ">
        <!-- <div class="page-body"> -->
        <div class="card" style="margin-bottom:0%!important;min-height:54.7rem;">
          <div class="card-block" style="background-color:white;">
            <div class="card-header" style="margin-top:1%;margin-right:1.5%;">
              <h4 style="font-weight:bold;">Personalize Course Schedule</h4>
              <hr/>
            </div>
            <div class="dt-responsive table-responsive tableView">
              <table style="width:40%;margin-left:3.4%;">
                <thead>
                  <tr>
                    <th style="width:1.5%;padding-bottom:1.8%;">Programme</th>
                    <th style="width:4%;padding-bottom:2%;">Year</th>
                    <th style="width:3%;padding-bottom:2%;">Semester</th>
                    <th style="width:3%;padding-bottom:2%;">Division</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <form action="newSchedule_DB.php" method="POST">
                      <td class="height_td">  <!-- style="background-color:whitesmoke;" -->
                        <select name='selPRO_ID' id="PRO" onchange="getSCHED()"
                          style="width:100%;height:2rem;cursor:pointer;"> <!-- border:none;-->
                          <option value=''>Select</option>
                          <?php
                                $PRO_QRY = "SELECT CRSE_SCHED_PID,PRGM_ID FROM Mtb_CourseSchedule,Mtb_Programme WHERE PID = CRSE_SCHED_PID GROUP BY PID";
                                $PRO_Data = mysqli_query($con,$PRO_QRY);
                                while($r = mysqli_fetch_assoc($PRO_Data))
                                {
                                    echo "<option value='".$r['CRSE_SCHED_PID']."'>".$r['PRGM_ID']."</option>";
                                }
                            ?>
                        </select>
                      </td>
                      <td>
                        <select name="selYEAR" id="YEAR" onchange="getSCHED()"
                          style="width:100%;height:2rem;cursor:pointer;">
                          <option value=''>Select</option>
                          <?php
                                $Year_QRY = "SELECT CRSE_SCHED_Year FROM Mtb_CourseSchedule GROUP BY CRSE_SCHED_Year";
                                $Year_Data = mysqli_query($con,$Year_QRY);
                                while($r = mysqli_fetch_assoc($Year_Data))
                                {
                                    echo "<option value='".$r['CRSE_SCHED_Year']."'>".$r['CRSE_SCHED_Year']."</option>";
                                }
                              ?>
                        </select>
                      </td>
                      <td>
                        <select name='selSEM' id="SEM" onchange="getSCHED()"
                          style="width:100%;height:2rem;cursor:pointer;">
                          <option value=''>Select</option>
                          <?php
                                $Sem_QRY = "SELECT substring(CRSE_SCHED_CourseID,5,2) AS Sem FROM Mtb_CourseSchedule GROUP BY substring(CRSE_SCHED_CourseID,6,1)";
                                $Sem_Data = mysqli_query($con,$Sem_QRY);
                                while($r = mysqli_fetch_assoc($Sem_Data))
                                {
                                    echo "<option value='".$r['Sem']."'>".$r['Sem']."</option>";
                                }
                            ?>
                        </select>
                      </td>
                      <td>
                        <select name="selDivision" id="DIV" onchange="getSCHED()"
                          style="width:100%;height:2rem;cursor:pointer;">
                          <option value=''>Select</option>
                          <?php
                                $Div_QRY = "SELECT CRSE_SCHED_Division FROM Mtb_CourseSchedule GROUP BY CRSE_SCHED_Division";
                                $Div_Data = mysqli_query($con,$Div_QRY);
                                while($r = mysqli_fetch_assoc($Div_Data))
                                {
                                    echo "<option value='".$r['CRSE_SCHED_Division']."'>".$r['CRSE_SCHED_Division']."</option>";
                                }
                            ?>
                        </select>
                      </td>
                      <script>
                        function getSCHED() 
                        {
                          let program = document.getElementById("PRO").value;
                          let year = document.getElementById("YEAR").value;
                          let sem = document.getElementById("SEM").value;
                          let div = document.getElementById("DIV").value;

                          if (program == "Null" || year == "Null" || sem == "Null" || div == "Null") 
                          {
                            // Do Nothing :)
                          }
                          else 
                          {
                            let xhr;

                            (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");

                            let data = "program=" + program + "&year=" + year + "&sem=" + sem + "&div=" + div;

                            xhr.open("POST", "AJAX_ViewSchedule_DB.php", true);
                            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                            xhr.send(data);
                            xhr.onreadystatechange = display_data;

                            function display_data() 
                            {
                              if (xhr.readyState == 4) 
                              {
                                if (xhr.status == 200) 
                                {
                                  document.getElementById("resSchedule").innerHTML = xhr.responseText;
                                  document.getElementById("hidePersonalSchedule").style.display="none";
                                }
                                else 
                                {
                                  alert("There was a problem with the request");
                                }
                              }
                            }
                          }
                        }
                      </script>
                      <noscript>Your browser doesnot support JavaScript!</noscript>
                    </form>
                </tbody>
              </table>
              <button style="margin-left:89%;height:2rem;padding-bottom:2%;margin-top:-3%;" 
                    class="btn btn-primary waves-effect waves-light" data-toggle="modal" data-target="#default-Modal">
                    Delete Schedule
              </button> 
              <div id="resSchedule" style="margin-bottom:3%;"></div>
              <div id="hidePersonalSchedule">
                  <?php
                    include_once("../Teacher/teacherPersonalSchedule.php");
                  ?>
              </div>
            </div>
          </div>
           <!-- New Programme -->
        <div class="card-block">
          <ul>
            <li>
              <div class="modal fade" id="default-Modal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width:120%;">
                    <div class="modal-header">
                        <h4 class="modal-title" style="font-weight:bold;">Delete Schedule</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                  <form id="main" method="POST">
                    <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:2%;font-weight:550;">Programme</label>
                            <div style="width:20%;">
                              <select name='selPRO_ID' required id="PRO" onchange="getSCHED()"
                                style="width:100%;height:2rem;"> <!-- border:none;-->
                                <option value=''>Select</option>
                                <?php
                                      $PRO_QRY = "SELECT CRSE_SCHED_PID,PRGM_ID FROM Mtb_CourseSchedule,Mtb_Programme WHERE PID = CRSE_SCHED_PID GROUP BY PID";
                                      $PRO_Data = mysqli_query($con,$PRO_QRY);
                                      while($r = mysqli_fetch_assoc($PRO_Data))
                                      {
                                          echo "<option value='".$r['CRSE_SCHED_PID']."'>".$r['PRGM_ID']."</option>";
                                      }
                                  ?>
                              </select>
                            </div>
                        <!-- </div>
                        <div class="form-group row"style="margin-top:-0.5%;"> -->
                            <label class="col-form-label frmTxt" style="margin-left:5%;margin-right:1.5%;font-weight:550;">Year  </label>
                            <select name="selYEAR" required id="YEAR" onchange="getSCHED()"
                              style="width:20%;height:2rem;margin-left:4.8%;">
                              <option value=''>Select</option>
                              <?php
                                    $Year_QRY = "SELECT CRSE_SCHED_Year FROM Mtb_CourseSchedule GROUP BY CRSE_SCHED_Year";
                                    $Year_Data = mysqli_query($con,$Year_QRY);
                                    while($r = mysqli_fetch_assoc($Year_Data))
                                    {
                                        echo "<option value='".$r['CRSE_SCHED_Year']."'>".$r['CRSE_SCHED_Year']."</option>";
                                    }
                                  ?>
                            </select>
                        </div>
                        <div class="form-group row"style="margin-top:-0.5%;">
                        <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:1.5%;font-weight:550;">Semester </label>
                          <select name='selSEM' required id="SEM" onchange="getSCHED()"
                            style="width:20%;height:2rem;margin-left:3.9%;">
                            <option value=''>Select</option>
                            <?php
                                  $Sem_QRY = "SELECT substring(CRSE_SCHED_CourseID,5,2) AS Sem FROM Mtb_CourseSchedule GROUP BY substring(CRSE_SCHED_CourseID,6,1)";
                                  $Sem_Data = mysqli_query($con,$Sem_QRY);
                                  while($r = mysqli_fetch_assoc($Sem_Data))
                                  {
                                      echo "<option value='".$r['Sem']."'>".$r['Sem']."</option>";
                                  }
                              ?>
                          </select>
                          <label class="col-form-label frmTxt" style="margin-left:5%;margin-right:1.5%;font-weight:550;">Division </label>
                          <select name="selDivision" required id="DIV" onchange="getSCHED()"
                            style="width:20%;height:2rem;">
                            <option value=''>Select</option>
                            <?php
                                  $Div_QRY = "SELECT CRSE_SCHED_Division FROM Mtb_CourseSchedule GROUP BY CRSE_SCHED_Division";
                                  $Div_Data = mysqli_query($con,$Div_QRY);
                                  while($r = mysqli_fetch_assoc($Div_Data))
                                  {
                                      echo "<option value='".$r['CRSE_SCHED_Division']."'>".$r['CRSE_SCHED_Division']."</option>";
                                  }
                              ?>
                          </select>
                        </div>
                    </div>
                    <!-- New Programme Buttons -->
                    <div class="modal-footer">
                        <input type="reset" class="btn btn-default waves-effect" data-dismiss="modal" value="Cancel"/>
                        <input type="submit" class="btn btn-primary waves-effect waves-light" name="btnSubmit" value="Delete" onclick="return inputCheck()"/>
                    </div>
                </form>
                <?php
                  if(isset($_POST['btnSubmit']))
                  {
                    $PID  = $_POST['selPRO_ID'];
                    $SEM  = $_POST['selSEM'];
                    $DIV  = $_POST['selDivision'];
                    $Year = $_POST['selYEAR'];
                    $dlt = "DELETE FROM Mtb_CourseSchedule 
                            WHERE CRSE_SCHED_PID = $PID AND substring(CRSE_SCHED_CourseID,5,2) = $SEM AND CRSE_SCHED_Division = '$DIV' AND CRSE_SCHED_Year = $Year";
                    if(!mysqli_query($con,$dlt)) {
                      echo '
                        <script> 
                            swal("Alert", "Some Error Occured. Schedule Not Removed", "warning");
                        </script>
                    ';
                    } else {
                      echo '
                        <script> 
                            swal("Success", "Successfully Removed Course Schedule.", "success");
                        </script>
                    ';
                    }
                  }
                ?>
        </div>
      </div>
    </div>
</body>

</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>