<?php
    session_start();
    // error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
        $courses = array("CS5001 - JKT","CS5002 - UJP","CS5003 - PBN","CS5004 - ADP","CS5005 - JBU");
        $allocatedTimes = array(0,0,0,0,0);

        $lecturePerDay = 6;
        $lectureDuration = 1;

        $lectureStartTime = $_POST['txtLectureStartTime'];
        $breaks = $_POST['selTotalBreaks'];
        $breakStart = $_POST['txtStartBreak'];
        $breakEnds = $_POST['txtEndBreak'];

        # TimeSlots Data
        $startTimeArr = array();
        $endTimeArr = array();

        $days = array("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
        $courseReservedForDay = array();

        function timeSlots() 
        {
            global $lecturePerDay, $lectureStartTime, $lectureDuration, 
                   $startTimeArr, $endTimeArr,$breaks, $breakEnds;

            array_push($startTimeArr,$lectureStartTime);
            $time = date('H:i',strtotime($lectureStartTime) + 60*60*$lectureDuration);
            $breakStart = $_POST['txtStartBreak'];
            $flag = false;

            for($i = 0; $i < $lecturePerDay+$breaks; $i++) {
                foreach(array_combine($breakStart,$breakEnds) as $bst => $bet) {
                    if($startTimeArr[$i] == $bst) {
                        array_push($startTimeArr,$bet);
                        array_push($endTimeArr,$bet);
                        $flag = true;
                        break;
                    }
                }
                if($flag == true) {
                    $flag = false;
                    continue;
                }
                array_push($startTimeArr,date('H:i',strtotime($startTimeArr[$i]) + 60*60*$lectureDuration));
                array_push($endTimeArr,date('H:i',strtotime($startTimeArr[$i]) + 60*60*$lectureDuration));
            }
            # Removing extra element 
            array_splice($startTimeArr,array_key_last($startTimeArr),1);
        }

        echo '
        <style>
            table, td, th {
                border: 1px solid black;
                border-collapse:collapse;
            }
            table {
                width:85%;
                height:37rem;
            }
        </style>
        ';

        # Main function (GUI)
        function genesis($sem, $div) 
        {
            global $startTimeArr, $endTimeArr, $courses, $days, $lecturePerDay, 
                   $breaks, $breakStart, $allocatedTimes, $courseReservedForDay;

            echo '
                <br/>
                Semester : '.$sem.' &nbsp;&nbsp; Division : '.$div.'
                <table class="table table-striped table-bordered wrap" style="height:20rem;">
                    <thead>
                        <tr>
                            <th style="width:10%;height:2.5rem;">Time /<br/>Day</th> 
            ';
                        $count = 0;
                        # For Timing Display
                        foreach (array_combine($startTimeArr,$endTimeArr) as $st => $et) 
                        {
                            echo "<th style='background-color:pink;'>".date("g:i A", strtotime($st))."  to ".date("g:i A", strtotime($et))."</th>";
                            if($count >= $lecturePerDay+$breaks) {
                                break;
                            }
                            $count++;
                        }
            echo '
                        </tr>
                    </thead>
                    <tbody>
            ';

            $cntr = 0; 
            # Vertical view (Days)
            $coursePerWeek = $allocatedTimes;   # New array creation.
            foreach($days as $day) 
            {
                $cresCntr = 0;
                $coursePerWeek = array_fill(0,count($allocatedTimes),0);
                echo "<tr>";
                    # For Timing Display
                    echo "<td style='text-align:center;'>".$days[$cntr]."</td>";
                    # Horizontal view (Courses)
                    for($i = 0; $i < $lecturePerDay+$breaks; $i++) {

                        if($i >= $lecturePerDay+$breaks) { break; }

                        if(in_array($startTimeArr[$i],$breakStart)) {
                            echo "<td style='text-align:center;background-color:lightyellow;'> BREAK </td>";
                        } 
                        else {
                            $randNum = rand(0,count($courses)-1);
                            $allocatedTimes[$randNum]++;
                            if(@in_array($courses[$randNum],$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]])) {
                                # infinite situation handler.
                                $exitInfinite = 0;
                                while(in_array($courses[$randNum],$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]])) {
                                    $randNum = rand(0,count($courses)-1);
                                    $allocatedTimes[$randNum]++;
                                    if($courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]) {
                                        if(!in_array($courses[$randNum],$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]])) {
                                            $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $courses[$randNum];
                                            $coursePerWeek[$randNum]++;
                                            #yellow
                                            echo 
                                                "<td style='text-align:center;background-color:lightblue;'>
                                                    ".$courses[$randNum]."
                                                </td>";
                                            break;
                                        }
                                    }
                                    if($exitInfinite == count($courses)) {  
                                        if(@$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]) {
                                            $arr = array_diff($courses,$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]);
                                            foreach($arr as $index => $c) {
                                                if($coursePerWeek[$index] < 2) {
                                                    $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                    $coursePerWeek[$index]++;
                                                    echo "<td style='text-align:center;background-color:lightblue;'>
                                                        ".$c."
                                                    </td>";
                                                    break;
                                                }
                                            }
                                        } else {
                                            foreach($courses as $index => $c) {
                                                if($coursePerWeek[$index] < 2) {
                                                    $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                    $coursePerWeek[$index]++;
                                                    echo "<td style='text-align:center;background-color:lightblue;'>
                                                        ".$c."
                                                    </td>";
                                                    break;
                                                }
                                            }
                                        }
                                        break; 
                                    }
                                    $exitInfinite++;
                                }
                            } else {
                                $check = false;
                                if($coursePerWeek[$randNum] < 2) {
                                    $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $courses[$randNum];
                                    $coursePerWeek[$randNum]++;
                                    echo 
                                        "<td style='text-align:center;background-color:lightblue;'>
                                            ".$courses[$randNum]."
                                        </td>";
                                } else {
                                    if(@in_array($courses[$randNum],$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]])) {
                                       # Do Nothing.
                                    } else {
                                        if(@$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]) {
                                            $arr = array_diff($courses,$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]);
                                            foreach($arr as $index => $c) {
                                                if($coursePerWeek[$index] < 2) {
                                                    $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                    $coursePerWeek[$index]++;
                                                    $check = true;
                                                    #cyan
                                                    echo "<td style='text-align:center;background-color:lightblue;'>
                                                        ".$c."
                                                    </td>";
                                                    break;
                                                }
                                            }
                                        } else {
                                            foreach($courses as $index => $c) {
                                                if($coursePerWeek[$index] < 2) {
                                                    $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                    $coursePerWeek[$index]++;
                                                    $check = true;
                                                    ##bb88fd
                                                    echo "<td style='text-align:center;background-color:lightblue;'>
                                                        ".$c."
                                                    </td>";
                                                    break;
                                                }
                                            }
                                        }
                                        if($check == false) {
                                            echo "<td style='text-align:center;background-color:red;'></td>";
                                            break;
                                        }
                                    }
                                }
                            }
                            $cresCntr ++;
                        }
                    }
                echo "</tr>";
                $cntr++;
            }

            echo '
                    </tbody>
                </table>
            <br/>
            ';
        }

        # Execution block
        timeSlots();
        genesis("5","A");
        // echo "<pre>";
        // print_r($allocatedTimes);
        // echo "</pre>";
        $allocatedTimes = array_fill(0,count($allocatedTimes),0);
        genesis("5", "B");
        // echo "<pre>";
        // print_r($allocatedTimes);
        // echo "</pre>";
        echo "<pre>";
        // print_r($courseReservedForDay);
        echo "</pre>";
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>