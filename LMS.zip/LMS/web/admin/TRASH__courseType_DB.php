<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {    
        $ProgramID = strtoupper($_POST['selProgramID']);
        $CourseType = $_POST['selCRSE_TYPE'];
        $year = $_POST['selYear'];
        $sem = $_POST['selSem'];
        if(!empty($ProgramID) && !empty($year) && !empty($_POST['Courses'])  && !empty($sem))
        {
            include("../COMMON_FILES/Connection.php");
            foreach($_POST['Courses'] as $c)
            {
                $sql = "INSERT INTO Tb_ProgrammeCourseTypes (PRGM_CRSE_PID, PRGM_CRSE_CourseID, PRGM_CRSE_AcademicYear, PRGM_CRSE_CourseType,PRGM_CRSE_Sem) VALUES ('$ProgramID','$c', '$year', '$CourseType','$sem')";
                if(!mysqli_query($con,$sql))
                {
                    header("refresh:0;url=courseType.php?Status=1");
                }
            }
        }
        if(!mysqli_query($con,$sql))
        {
            header("refresh:0;url=courseType.php?Status=2");
        }
    }
    else
    {
        echo "You Don't have previleges to access this page.<br/>This incident will be reported along with your IP.";
        header("refresh:2;url=../COMMON_FILES/logout.php");
    }

?>