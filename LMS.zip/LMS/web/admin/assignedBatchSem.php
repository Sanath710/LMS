<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {   
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
      include_once("adminNavbar.php");
    }
    else if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
      include_once("../HoD/teacherNavbar.php");
    }
    include("../COMMON_FILES/Connection.php");
    $URL_PRGM_Year = substr($_GET['pRgM'],5,4);
    $URL_PRGM_ID = substr($_GET['pRgM'],-11,1);
    $URL_PRGM_Name = base64_decode(substr($_GET['pRgM'],-15,4));

    $query ="SELECT PRGM_CRSE_Sem FROM Tb_ProgrammeCourseTypes WHERE PRGM_CRSE_PID = $URL_PRGM_ID AND PRGM_CRSE_AcademicYear = $URL_PRGM_Year GROUP BY PRGM_CRSE_PID,PRGM_CRSE_Sem";
    $data = mysqli_query($con,$query);
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    </head>
    <body>
        <div class="pcoded-content">
            <div class="main-body">
                <div class="page-wrapper subBodyProgram">
                    <div class="card bodyStyling">
                        <div class="card-header" style="margin-top:0.5%;">
                        <h4>Semester of  Batch&nbsp;<?php echo $URL_PRGM_Name." ".$URL_PRGM_Year; ?></h4>
                        <hr style="width:97.8%; margin-left:0%;" />
                        </div>
                        <br />
                        <div class="page-body" style="display:flex;flex-wrap:wrap;">
                        <?php 
                            while($prgms = mysqli_fetch_assoc($data))
                            {
                        ?>
                        <div class="card sale-card" style="margin-left:3.01%;margin-top:1%;padding-left:1.6%;padding-right:1.6%;padding-top:0.8%;">
                            <div class="card-block text-center">
                            <?php
                                echo '<a href="assignedSemCourses.php?pRgM='.$prgms['PRGM_CRSE_Sem'].$_GET['pRgM'].'">
                                        <i class="fa fa-folder-o" style="font-size:45px;margin-right:1.7%;">
                                        <h6 style="display:flex;padding:5%;margin-left:-12%;margin-top:15%;">&nbsp;&nbsp;Sem '.$prgms['PRGM_CRSE_Sem'].'</h6>
                                        </i>
                                    </a>';
                            ?>
                            </div>
                        </div>
                        <?php
                            }
                        ?>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>