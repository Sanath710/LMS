<?php
    session_start();
    error_reporting(0);
    if((substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H") && isset($_POST['btnAdd']))
    {  
        $day = $_POST['selDay'];
        $startTime = $_POST['selStartTime'];
        $endTime = $_POST['selEndTime'];
        $cid = $_POST['selCourseID'];
        $pid = $_POST['selProgramID'];
        $div = $_POST['selDiv'];
        
        if(!empty($day) && !empty($startTime) && !empty($endTime) && !empty($cid) && !empty($pid) && !empty($div))
        {
            include("../COMMON_FILES/Connection.php");
            $sql = "INSERT INTO Mtb_CourseSchedule
                    (CRSE_SCHED_PID,CRSE_SCHED_CourseID,CRSE_SCHED_Day,CRSE_SCHED_StartTime,CRSE_SCHED_EndTime,CRSE_SCHED_Division,CRSE_SCHED_Year) VALUES (?,?,?,?,?,?,?)";
            $stmt = mysqli_stmt_init($con);
            if(!mysqli_stmt_prepare($stmt,$sql))
            {
                echo "Error in Prepare Statement";
                header("Location:newSchedule.php?s=4");
            }
            else
            {
                $d = date("Y");
                mysqli_stmt_bind_param($stmt,"iisssss",$pid,$cid,$day,$startTime,$endTime,$div,$d);
                if(!mysqli_stmt_execute($stmt))
                {
                    header("Location:newSchedule.php?s=2");
                } 
                else
                {
                    header("Location:newSchedule.php?s=3");
                }
            }
        }
        else 
        {
            header("Location:newSchedule.php?s=5");
        }
    }
    else
    {
        echo "You don't have previleges to access this page.!!";
        header("refresh:2;url=../COMMON_FILES/logout.php");
    }
?>