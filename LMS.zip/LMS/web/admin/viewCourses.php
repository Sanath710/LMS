<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
  {   
    include_once("adminNavbar.php");
    include("../COMMON_FILES/Connection.php");
    $query ="SELECT Mtb_Courses.*,Tb_ProgrammeCourseTypes.*,PRGM_ID FROM Mtb_courses,Tb_ProgrammeCourseTypes,Mtb_Programme
             WHERE CRSE_ID = PRGM_CRSE_CourseID AND PRGM_CRSE_PID = PID";
    $data = mysqli_query($con,$query);
    echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
    if($_GET['s']==2)
    {
      echo '
          <script> 
              swal("Alert", "You Forgot to Enter Course ID.", "warning");
          </script>
      ';
    }
    else if($_GET['s']==3)
    {
      echo '
          <script> 
              swal("Alert", "You Forgot to Enter Course Name.", "warning");
          </script>
      ';
    }
    else if($_GET['s']==4)
    {
      echo '
          <script> 
              swal("Alert", "Some Error Occured While Inserting Data into Database.", "warning");
          </script>
      ';
    }
    else if($_GET['s']==5)
    {
      echo '
          <script> 
              swal("Success", "Operation Performed Successfully.", "success");
          </script>
      ';
    }
    if($_GET['Status']==1)
    {
        echo 
        '
            <script> 
                swal("Success", "COURSE '.$_GET['id'].' Added Successfully.", "success");
            </script>
        ';
    }
    else if($_GET['Status']==6)
    {
        $Status = "border:1px solid red;";
        $ERROR_MSG = "<span style='color:red; font-size:14px;'>Some Error Occured.<br/> Operation Failed.</span>";
    }
    else if(($_GET['Status']==7))
    {
        echo 
        '
            <script> 
                swal("warning", "Invalid Data or No Data Received.", "warning");
            </script>
        ';
    }
    else if($_GET['Status']==8)
    {
        if($_GET['t'] == "m") {
          echo 
          '
              <script> 
                  swal("warning", "ERROR in Prepare Statement for Master table.", "warning");
              </script>
          ';
        } else {
          echo 
          '
              <script> 
                  swal("warning", "ERROR in Prepare Statement for Transaction table.", "warning");
              </script>
          ';
        }
    }
        // else if($_GET['Status']==9)
        // {
        //     echo 
        //     '
        //         <script> 
        //             swal("Error", "Some error occured while moving file to destination", "warning");
        //         </script>
        //     ';
        // }
        // else if($_GET['Status']==10)
        // {
        //     echo 
        //     '
        //         <script> 
        //             swal("Error", "Some error occured while uploading image", "warning");
        //         </script>
        //     ';
        // }
        // else if($_GET['Status']==11)
        // {
        //     echo 
        //     '
        //         <script> 
        //             swal("Error", "Unsupported image file format.\nOnly JPEG, JPG & PNG Format is allowed.", "warning");
        //         </script>
        //     ';
        // }
        // else if($_GET['Status']==12)
        // {
        //     echo '
        //         <script> 
        //             swal("Sorry", "Image File Size must be greater than 20 kb.", "info");
        //         </script>
        //     ';
        // }
        // else if($_GET['Status']==13)
        // {
        //     echo '
        //         <script> 
        //             swal("Sorry", "Image File Size must be lesser than 2 MB.", "info");
        //         </script>
        //     ';
        // }
?>
<html lang="en">

  <head>
    <link rel="stylesheet" type="text/css" href="../css/datatables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <!-- <style>table tr,table,td,table {border:none!important;}</style> -->
    <style>table tr,table,td {border:none!important;}</style>
    <script>
      if ( window.history.replaceState ) 
      {
        window.history.replaceState( null, null, "viewCourses.php");
      }
    </script>
    <style>
      th
      {
         border-right:none!important;
      }
    </style>
    <script src="../COMMON_FILES/sweetalert.min.js"></script>
  </head>

  <body>
  <div class="pcoded-content">
    <!-- <div class="page-header card">
     <div class="row align-items-end">
      <div class="col-lg-8">
        <div class="page-header-title">
          <i class="fa fa-book bg-c-blue" aria-hidden="true"></i>
          <div style="padding-top:1%;">
            <h5>View Programs</h5>
            <span></span>
          </div>
        </div>
      </div>
        <div class="col-lg-4">
          <div class="page-header-breadcrumb">
            <ul class=" breadcrumb breadcrumb-title">
              <li class="breadcrumb-item">
                <a href=""><i class="feather icon-home"></i></a>
              </li>
              <li class="breadcrumb-item"><a href="#!">View Programs</a> </li>
            </ul>
          </div>
        </div>
    </div>
  </div> -->
  <!-- Main Body Starts -->
  <div>
    <div class="main-body">
      <div class="page-wrapper subBodyProgram">
        <div class="page-body">
          <div class="card bodyStyling">
            <div class="card-header" style="">
              <h4 style="font-weight:bold;">Course Details</h4><hr style="width:97.8%; margin-left:0%;"/>
            </div>
            <div class="card-block">
              <div class="dt-responsive table-responsive tableView" style=" margin-bottom:-0.5%;">
              <span style="color:red;font-size:15.5px;font-weight:520;"><br/>TO EDIT A RECORD, CLICK ON IT 
                  <button style="margin-left:93.8%;height:2rem;padding-bottom:2.2%;padding-right:0.4%;padding-left:0.7%;display:flex;margin-top:-0.5%;" 
                        class="btn btn-primary waves-effect" data-toggle="modal" data-target="#default-Modal"> Add &nbsp;<i class='bx bx-plus-circle f-24'></i></button> 
                  <!-- <button style="margin-left:75%;margin-top:1%;display:flex;" 
                    class="btn btn-primary waves-effect waves-light" data-toggle="modal" data-target="#default-Modal">
                    Add &nbsp;<i class='bx bx-plus-circle f-24'></i> -->
                  </button>
              </span>
                <table id="base-style" style="width:100%; margin-top:-1%;cursor:pointer;" class="table table-striped table-bordered nowrap tableViewProgram">
                  <thead>
                    <tr>
                      <th style="width:5%;text-align:center;">Sr No</th>
                      <th style="width:8%;">Programme</th>
                      <th style="width:10%;">Course ID</th>
                      <th style="width:30%;">Course Name</th>
                      <th style="width:8%;text-align:center;">Semester</th>
                      <th style="width:10%;text-align:center;">Course Status</th>
                      <th style="width:9%;text-align:center;">Last Modified</th>
                      <th id="hideTH" style="width:10%;text-align:center;padding-left:1.5%;">Edit</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                    $cnt=1;
                    while ($result = mysqli_fetch_assoc($data)) 
                    {
                  ?>  
                        <tr class="RowHeight" onclick="edit(this)">
                        <!-- Update form starts -->
                          <form action="updateCourse_DB.php" method="POST">
                            <td style="text-align:center;"><?php echo $cnt; ?></td>
                            <td >
                                <?php echo $result['PRGM_ID']; ?>
                            </td>
                            <td class="height_td"> <span class="dispID"><?php echo $result['CRSE_ID'];?></span>
                              <input type="text" class="editID UpdateCForm" name="CourseID" autocomplete="off" id="CourseID" readonly
                                pattern ="[0-9]{9}" title="Enter Only Numeric Values" minLength="9" maxlength="9" value="<?php echo $result['CRSE_ID'] ?>"/>
                            </td>
                            <td style="text-align:left;" ><span class="dispName"><?php echo $result['CRSE_Name'];?></span>
                                <input type="text" name="CourseName" id="CourseName" autocomplete="off" class="editName UpdateCForm" minLength="1"
                                    pattern ="[A-Za-z][A-Z &a-z0-9]{0,}" title="Enter Only Aphabetical Characters with/without numeric value. No special characters allowed." value="<?php echo $result['CRSE_Name'];?>" readonly />
                            </td>
                            <td style="text-align:center;">
                                <?php echo $result['PRGM_CRSE_Sem']; ?>
                            </td>
                            <td style="text-align:center;"> 
                                <?php
                                  if($result['CRSE_Status'] == "1") 
                                  {
                                    echo '<label class="dispStatus label label-md bg-success" style="font-size:15px;padding-left:11.5%;padding-right:12.5%;">Active</label>';
                                ?>
                              <span class="editStatus">
                                <?php
                                    echo "<input type='radio' name='CourseStatus' value='1' checked/>&nbsp;Active &nbsp;
                                          <input type='radio' name='CourseStatus' value='0' />&nbsp;Deactive";
                                  }
                                ?>
                              </span>
                                <?php
                                  if($result['CRSE_Status'] == "0")
                                  {
                                    echo '<label class="dispStatus label label-md bg-danger" style="font-size:15px;">Deactive</label>';
                                ?>
                              <span class="editStatus">
                                <?php
                                    echo "<input type='radio' name='CourseStatus' value='1'/>&nbsp;Active &nbsp;
                                          <input type='radio' name='CourseStatus' value='0' checked/>&nbsp;Deactive";
                                  }
                                ?>
                              </span>
                            </td>
                            <td style="text-align:center;"><?php echo $result['CRSE_LastModified']; ?></td>
                            <td style="text-align:center;" class="hideTD">
                                <span style="display:flex;">&nbsp;
                                    <button type="submit" class="PGSubmit FormBtn Update" style="margin-left:1.3%;outline:none;" onclick = "return inputChecker()" name="Operation" value="Update" >&nbsp;&nbsp;<i class="fa fa-check-circle"></i>&nbsp; &nbsp;</button>
                                    &nbsp; 
                                    <button type="submit" class="PGSubmit FormBtn Remove" name="Operation" onclick = "return inputChecker()" value="Remove" >&nbsp; <i class="fa fa-trash"></i>&nbsp;&nbsp;</button>
                                    <i class='bx bx-x editIcon close' onclick="history.go(0);"></i>
                                </span>
                            </td>
                          </form>
                            <script>
                                    CRSEID = document.getElementsByClassName("editID");
                                    CRSEName = document.getElementsByClassName("editName");
                                    CRSEStatus = document.getElementsByClassName("editStatus");
                                    dispID = document.getElementsByClassName("dispID");
                                    dispName = document.getElementsByClassName("dispName");
                                    dispStatus = document.getElementsByClassName("dispStatus");
                                    hideTD = document.getElementsByClassName("hideTD");
                                    hideTH = document.getElementById("hideTH").style.display = "none";

                                    UpdateBtn = document.getElementsByClassName("Update");
                                    RemoveBtn = document.getElementsByClassName("Remove");

                                    editClose = document.getElementsByClassName("close");
                                    // editIcon = document.getElementsByClassName("editBtn");

                                    for(i = 0 ; i < UpdateBtn.length; i++)
                                    {
                                        UpdateBtn[i].style.display = "none";
                                        RemoveBtn[i].style.display = "none";
                                        editClose[i].style.display = "none";
                                        CRSEID[i].style.display = "none";
                                        CRSEName[i].style.display = "none";
                                        CRSEStatus[i].style.display = "none";
                                        hideTD[i].style.display = "none";
                                    }
                                    function edit(id) 
                                    { 
                                        UpdateBtn[id.rowIndex-1].removeAttribute("style");
                                        RemoveBtn[id.rowIndex-1].removeAttribute("style");
                                        editClose[id.rowIndex-1].removeAttribute("style");
                                        CRSEID[id.rowIndex-1].removeAttribute("style");
                                        CRSEName[id.rowIndex-1].removeAttribute("style");
                                        CRSEStatus[id.rowIndex-1].removeAttribute("style");
                                        hideTD[id.rowIndex-1].removeAttribute("style");
                                        // editIcon[id.rowIndex-1].style.display = "none";
                                        dispID[id.rowIndex-1].style.display = "none";
                                        dispName[id.rowIndex-1].style.display = "none";
                                        dispStatus[id.rowIndex-1].style.display = "none";
                                        document.getElementById("hideTH").removeAttribute("style");
                                        
                                        // alert("Enter the Updates in the high-lightened fields then Click on the \"Update\" button");

                                        // CRSEID[id.rowIndex-1].removeAttribute("readonly");
                                        CRSEName[id.rowIndex-1].removeAttribute("readonly");

                                        // styleAttrID = document.createAttribute("style");
                                        // styleAttrID.value = "border: 1px solid rgba(81, 203, 238, 1); padding-left:2%; background-color: white; border-radius:5px; height:30px;";

                                        styleAttrCRSEName = document.createAttribute("style");
                                        styleAttrCRSEName.value = "border: 1px solid rgba(81, 203, 238, 1);  padding-left:1%; background-color: white; border-radius:5px; height:32px;";

                                        // CRSEID[id.rowIndex-1].setAttributeNode(styleAttrID);
                                        CRSEName[id.rowIndex-1].setAttributeNode(styleAttrCRSEName);
                                    }      
                                    function inputChecker()
                                    {
                                        if(document.getElementById("CourseID").value == '')
                                        {
                                            swal("Alert", "Please Enter Course ID.!", "warning");
                                            return false;
                                        }
                                        if(document.getElementById("CourseName").value == '')
                                        {
                                            swal("Alert", "Please Enter Course Name.!", "warning");
                                            return false;
                                        }
                                        return true;
                                    }
                            </script>
                        </tr>
                       <?php
                        $cnt++;
                        }
                      ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- New Course -->
        <div class="card-block">
          <ul>
            <li>
              <div class="modal fade" id="default-Modal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width:145%;">
                    <div class="modal-header">
                        <h4 class="modal-title" style="font-weight:bold;">New Course</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                  <form id="main" method="POST" action="newCourse_DB.php" enctype="Multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:4.5%;font-weight:550;">Programme </label>
                            <div>
                              <select name='selProgramID' style="width:100%;height:2rem;border:1px solid #ccc;cursor:pointer;margin-top:5%;">
                               <?php
                                  $procode_QRY = "SELECT PRGM_ID,PRGM_Code from Mtb_Programme";
                                  $procode_Data = mysqli_Query($con,$procode_QRY);
                                  while($res = mysqli_fetch_assoc($procode_Data)) {
                                    echo '<option value="'.$res['PRGM_Code'].'">'.$res['PRGM_ID'].' ('.$res['PRGM_Code'].')</option>';
                                  }
                               ?>
                               </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:7.3%;font-weight:550;">Semester </label>
                            <?php
                              $semRange = range(1, 10);
                            ?>
                            <select name="selSemester" style="width:11%;height:2rem;border:1px solid #ccc;margin-top:0.7%;cursor:pointer;">
                              <?php
                                foreach ($semRange as $sem) {
                                    echo '<option value="'.$sem.'">'.$sem.'</option>';
                                }
                              ?>
                            </select>
                            <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:2%;font-weight:550;">Course Type : </label>
                            <select name="selCourseType" style="width:20%;height:2rem;border:1px solid #ccc;margin-top:0.7%;cursor:pointer;">
                              <option value="0">Compulsory</option>
                              <option value="1">Elective</option>
                            </select>
                        </div>
                        <!-- <br/> -->
                        <div class="form-group row"style="margin-top:-0.5%;">
                            <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:2.5%;font-weight:550;">Course Name </label>
                            <!-- <br/><br/> -->
                            <input type="text" class="form-control frmTxt" name="CourseName"style='width:73%;font-size:17px;padding-left:1%;'
                                autocomplete="off" id="CRSEName" required onkeyup="valueCheck()"
                                pattern="[A-Za-z]{1,}[A-Z\s&a-z0-9]{0,}"
                                title="Enter Only Aphabetical Characters along with numeric values. No Special Characters are allowed other than '&'."
                                placeholder="Enter Course Name " />
                            <input type="hidden" name="CourseStatus" value="1" checked/>
                        </div>
                    </div>
                    <!-- New Course Buttons -->
                    <div class="modal-footer">
                        <input type="reset" class="btn btn-default waves-effect" data-dismiss="modal" value="Cancel"/>
                        <input type="submit" class="btn btn-primary waves-effect waves-light" name="btnSubmit" value="Add" onclick="return inputCheck()"/>
                    </div>
                </form>
                <script>
                  function inputCheck() 
                  {
                      if (document.getElementById("CRSEID").value == '') 
                      {
                          swal("Alert", "Enter Course ID", "warning");
                          return false;
                      }
                      else if (document.getElementById("CRSEName").value == '') 
                      {
                          swal("Alert", "Please Enter Course Name", "warning");
                          return false;
                      }
                      return true;
                  }
                  if (window.history.replaceState) 
                  {
                      window.history.replaceState(null, null, "viewCourses.php");
                  }
                </script>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <script src="../js/jquery.datatables.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.buttons.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.bootstrap4.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.responsive.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/data-table-custom.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="06ff493bca0b4366a261bcf1-|49" defer=""></script>
  </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>