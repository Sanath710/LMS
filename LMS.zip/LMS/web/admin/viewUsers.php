<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {  
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A") {
      include_once("../admin/adminNavbar.php");
    } else if (substr($_SESSION['Sess_USR_Role'],0,1)=="H") {
      include_once("../HoD/teacherNavbar.php");
    }
    include("../COMMON_FILES/Connection.php");
    $sql = "SELECT USR_ID,USR_FirstName,USR_LastName,USR_ContactNo,USR_EmailID,USR_Role FROM Mtb_Users";
    $data = mysqli_query($con,$sql);
?>
<html lang="en">

  <head>
    <title>LMS | View Users</title>
    <link rel="stylesheet" type="text/css" href="../css/datatables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <style>
      table td,th 
      {
        padding-bottom:1.75%!important;
        font-size:18px'
      }
      table tr,table,td {border:none!important; border-color: black; color:black;}
    </style>
    <script>
        if (window.history.replaceState) 
        {
            window.history.replaceState( null, null, "viewUsers.php");
        }
    </script>
  </head>

  <body>
  <div class="pcoded-content">
    <!-- <div class="page-header card">
     <div class="row align-items-end">
      <div class="col-lg-8">
        <div class="page-header-title">
          <i class="fa fa-book bg-c-blue" aria-hidden="true"></i>
          <div style="padding-top:1%;">
            <h5>View Programs</h5>
            <span></span>
          </div>
        </div>
      </div>
        <div class="col-lg-4">
          <div class="page-header-breadcrumb">
            <ul class=" breadcrumb breadcrumb-title">
              <li class="breadcrumb-item">
                <a href=""><i class="feather icon-home"></i></a>
              </li>
              <li class="breadcrumb-item"><a href="#!">View Programs</a> </li>
            </ul>
          </div>
        </div>
    </div>
  </div> -->
    <!-- Main Body Starts -->
    <div>
        <div class="main-body">
        <div class="page-wrapper subBodyProgram">
            <div class="page-body">
            <div class="card bodyStyling" style="min-height:54.7rem;">
                <div class="card-header" >
                  <h4 style="font-weight:550;">View Users</h4><hr style="width:99%; margin-left:0%;"/>
                </div>
                <div class="card-block" style="display:flex;padding-right:2%;margin-top:2.5%;">
                  <div class="dt-responsive table-responsive tableView">
                    <!-- Span for hiding main table if search criteria occurs -->
                    <span id="main-table">
                      <table id="base-style" style="width:99.5%;" class="table table-striped table-bordered nowrap tableViewProgram">
                        <thead>
                            <tr>
                                <th style="width:2%;">No.</th>
                                <th style="width:13%;">User ID</th>
                                <th style="width:16%;">User Name</th>
                                <th style="width:15%;">Contact No</th>
                                <th style="width:20%;">Email ID</th>
                                <th style="width:10%;">User Type</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $cnt=1;
                            while ($result = mysqli_fetch_assoc($data)) 
                            {
                                echo '
                                <tr class="RowHeight" onclick="edit(this)">
                                    <td >'.$cnt.'</td>
                                    <td class="height_td">
                                        '.$result['USR_ID'].'
                                    </td>
                                    <td style="text-align:left;" >
                                        '.$result['USR_FirstName']." ".$result['USR_LastName'].'
                                    </td>
                                    <td style="text-align:left;" >
                                        '.$result['USR_ContactNo'].'
                                    </td>
                                    <td style="text-align:left;" >
                                    '.$result['USR_EmailID'].'
                                    </td>
                                    <td style="text-align:left;" >
                                    '.$result['USR_Role'].'
                                    </td>
                                </tr>';
                            $cnt++;
                            } 
                        ?>
                         </tbody>
                      </table>
                    </span> 
                    <!-- Table hiding span ends here -->
                    <span id="result-table">
                    <span> 
                </div>
                <div class="" style="margin-left:0%;margin-top:-0.1%;width:37%;">
                  <br/>
          <!-- SEARCH FORM STARTS-->
                <form method="POST">
                  <div class="card button-page">
                    <div style="margin-left:10%;margin-top:8%;margin-right:9%;">
                        <div class="form-radio m-t-5">
                          <b style="font-weight:550;font-size:18px;margin-right:4%;">Filter Details</b>
                            <p style="font-weight:550;margin-right:4%;color:red;margin-top:1%;">You cannot find newly enrolled users using this filter, Since they are not allocated a division.</p>
                            <hr/>
                            <div class="radio radiofill radio-primary radio-inline" style="font-size:18px;margin-top:2%;">
                                <label>
                                    <input type="radio" name="rdbtnViewChoice" onclick="getUsers()" value="S" required data-bv-field="member">
                                    <i class="helper" style="margin-top:4%;"></i> Student
                                </label>
                            </div>
                            <div class="radio radiofill radio-primary radio-inline" style="margin-left:-0.5%;font-size:18px;">
                                <label>
                                    <input type="radio" name="rdbtnViewChoice" onclick="getUsers()" value="T" data-bv-field="member">
                                    <i class="helper" style="margin-top:4%;"></i> Faculty
                                </label>
                            </div>
                            <div class="radio radiofill radio-primary radio-inline" style="margin-left:-0.5%;font-size:18px;">
                                <label>
                                    <input type="radio" name="rdbtnViewChoice" onclick="getUsers()" value="B" data-bv-field="member">
                                    <i class="helper" style="margin-top:4%;"></i> Both
                                </label>
                            </div>
                        </div>
                  </div>
                  <div class="card-block" style="margin-left:5%;margin-right:3%;margin-bottom:3%;margin-top:-2%;">
                    <?php
                      $sql = "SELECT PID,PRGM_ID FROM Mtb_Programme";
                      $data = mysqli_query($con,$sql);
                    ?>
                    <span style="display:flex;margin-top:2%;">
                      <b style="font-weight:550;font-size:18px;">Programme &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;: </b>
                      <select name="selProg" onchange="getPro(this)"
                          style="border-top:0; border-left:0; border-right:0; border-bottom:1%; cursor:pointer; margin-top:-2%;margin-left:5.5%;width:30%;">
                          <option value="0">Select</option>
                          <?php
                            while($res = mysqli_fetch_assoc($data)) {
                              echo '<option value="'.$res['PID'].'">'.$res['PRGM_ID'].'</option>';
                            }
                          ?>
                      </select>
                    </span>
                    <br/>
                    <span style="display:flex;margin-top:2%;">
                      <b style="font-weight:550;font-size:18px;">Academic Year&nbsp; &nbsp;&nbsp;&nbsp;:&nbsp;</b>
                      <select name="selAY" onchange="getAY(this)"
                          style="border-top:0; border-left:0; border-right:0; border-bottom:1%; cursor:pointer; margin-top:-2%;margin-left:4%;width:30%;">
                          <option value="0">Select</option>
                          <?php
                            for($i = 2021; $i <= date("Y"); $i++) {
                              echo '<option value="'.$i.'">'.$i.'</option>';
                            }
                          ?>
                      </select>
                    </span>
                    <br/>
                    <span style="display:flex;margin-top:2%;">
                      <b style="font-weight:550;font-size:18px;">Semester &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;: </b>
                      <select name="selSem" onchange="getSem(this)"
                          style="border-top:0; border-left:0; border-right:0; border-bottom:1%; cursor:pointer; margin-top:-2%;margin-left:5%;width:30%;">
                          <option value="0">Select</option>
                          <?php
                            for($i = 1; $i <= 10; $i++) {
                              echo '<option value="'.$i.'">'.$i.'</option>';
                            }
                          ?>
                      </select>
                    </span>
                    <br/>
                    <span style="display:flex;margin-top:2%;">
                      <b style="font-weight:550;font-size:18px;">Division &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;: </b>
                      <select name="selSem" onchange="getDiv(this)"
                          style="border-top:0; border-left:0; border-right:0; border-bottom:1%; margin-bottom:1%; cursor:pointer; margin-top:-2%;margin-left:5%;width:30%;">
                          <option value="0">Select</option>
                          <?php
                            $div_QRY = "SELECT DISTINCT CRSE_USR_Division FROM Tb_CourseUsers WHERE CRSE_USR_Division != ''";
                            $div_Data = mysqli_query($con,$div_QRY);
                            while($div_res = mysqli_fetch_assoc($div_Data)) {
                              echo '<option value="'.$div_res['CRSE_USR_Division'].'">'.$div_res['CRSE_USR_Division'].'</option>';
                            } 
                          ?>
                      </select>
                    </span>
                  </div>
                </div>
              </form>
              <script>
                      let Programme = 0;
                      let sem = 0;
                      let AY = 0;
                      let DIV = "X";

                      function getPro(e)
                      {
                        Programme = e.value
                        getUsers();
                      }
                      function getAY(e)
                      {
                          AY = e.value
                          getUsers();
                      }
                      function getSem(e)
                      {
                          sem = e.value
                          getUsers();
                      }
                      function getDiv(e)
                      {
                          DIV = e.value
                          getUsers();
                      }
                      // For Displaying only that courses which is based on the semester selected by a teacher
                      function getUsers()
                      {
                          let rdBtn = document.getElementsByName('rdbtnViewChoice');
                          let Choice = 0;

                          for(let i = 0; i < rdBtn.length; i++)
                          {
                              if(rdBtn[i].checked) {
                                Choice = rdBtn[i].value;
                              }
                          } 

                          if(Programme == 0 || AY == 0 || sem == 0 || Choice == 0 || DIV == "X")
                          {
                              // Do Nothing :)
                          }
                          else
                          {
                              let xhr;

                              (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                              
                              let data1 = "programme="+Programme+"&AY="+AY+"&sem="+sem+"&type="+Choice+"&Div="+DIV;
                          
                              xhr.open("POST","AJAX_viewUsers.php",true);
                              xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                              xhr.send(data1);
                              xhr.onreadystatechange = display; 

                              function display()
                              {
                                  if(xhr.readyState == 4)
                                  {
                                      if(xhr.status == 200)
                                      {
                                        document.getElementById("main-table").style.display="none";
                                        document.getElementById("result-table").innerHTML = xhr.responseText;
                                      }
                                      else
                                      {
                                          alert("There was a problem with the request");
                                      }
                                  }
                              }
                          }
                      }
                </script>
          <!-- SEARCH FORM ENDS-->
            <div class="card" style="padding:7%;overflow-x:overflow;margin-bottom:-2%;">
                <b style="font-weight:550;font-size:18px;margin-right:4%;margin-bottom:2.7%;margin-left:2.5%;">User ID Information</b>
                <!-- <hr/> -->
                <table style="margin-top:0%;margin-bottom:-0.3%;" class="table table-striped table-bordered nowrap tableViewProgram">
                  <thead>
                    <tr style="padding:2%;">
                      <th style="width:40%;border-top:none;border-left:none;border-right:none;">User (Role) </th>
                      <th style="border-top:none;border-left:none;border-right:none;"> Last ID Allocated </th>
                    </tr>
                    <tr><td></td></tr>
                    <tr><td></td></tr>
                  </thead>
                  <tbody>
                    <tr>
                        <td>Student</td>
                        <td>
                          <?php
                            $sql = "select USR_ID from Mtb_Users WHERE USR_Role = 'Student' ORDER BY USR_ID DESC LIMIT 1";
                            $data = mysqli_query($con,$sql);
                            $res = mysqli_fetch_assoc($data);
                            echo $res['USR_ID'];
                          ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Teacher</td>
                        <td>
                          <?php
                            $sql = "select USR_ID from Mtb_Users WHERE USR_Role = 'Teacher' ORDER BY USR_ID DESC LIMIT 1";
                            $data = mysqli_query($con,$sql);
                            $res = mysqli_fetch_assoc($data);
                            echo $res['USR_ID'];
                          ?>
                        </td>
                    </tr>
                    <tr>
                        <td>HoD</td>
                        <td>
                          <?php
                            $sql = "select USR_ID from Mtb_Users WHERE USR_Role = 'HoD' ORDER BY USR_ID DESC LIMIT 1";
                            $data = mysqli_query($con,$sql);
                            $res = mysqli_fetch_assoc($data);
                            echo $res['USR_ID'];
                          ?>
                        </td>
                    </tr>
                  </tbody>
                </table>
            </div>
            </div>
          </div>
        </div>
        <script src="../js/jquery.datatables.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.buttons.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.bootstrap4.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.responsive.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/data-table-custom.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="06ff493bca0b4366a261bcf1-|49" defer=""></script>
  </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>