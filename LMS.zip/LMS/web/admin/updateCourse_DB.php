<?php
    session_start();
    include("../COMMON_FILES/Connection.php");

    $CourseID = $_POST['CourseID'];
    $CourseName = $_POST['CourseName'];
    $CourseStatus = strtoupper($_POST['CourseStatus']);
    $Selection = $_POST['Operation'];
    // error_reporting(0);
    if(!$CourseID)
    {
        header("refresh:0;url=viewCourses.php?s=2");
    }
    else if(!$CourseName)
    {
        header("refresh:0;url=viewCourses.php?s=3");
    }
    if(!empty($CourseID) && !empty($CourseName))
    {
        $d = date("Y");
        if($Selection == 'Update')
        {
            $sql = "UPDATE mtb_courses SET CRSE_ID='$CourseID',CRSE_Name='$CourseName', CRSE_Status='$CourseStatus',CRSE_LastModified='$d' WHERE CRSE_ID='$CourseID'";
        ?>  
        <?php
        }
        else if($Selection == 'Remove')
        {
            $sql = "DELETE FROM Mtb_Courses where CRSE_ID='$CourseID'";
        }
        if(!mysqli_query($con,$sql))
        {
            // echo "Some Error Occured While Inserting Data into Database.!";
            header("refresh:0;url=ViewCourses.php?s=4");
        }
        else 
        {
            header("refresh:0;url=viewCourses.php?s=5");
        }
    }

?>