<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {    
        include_once ("adminNavbar.php");
        if($_GET['Status']==1)
        {
            echo "<script>alert('Course Added Successfully.!');</script>";
        }
        else if($_GET['Status']==2)
        {
            $Status = "border:1px solid red;";
            $ERROR_MSG = "<span style='color:red; font-size:14px;'>Please Enter Some Other Course ID.<br/> Previously Entered Course ID was Already Taken.!</span>";
        }
        
?>
<html>

    <head>
        <title>Course Type</title>
        <link rel="stylesheet" href="css/select2.min.css" />
        <link rel="stylesheet" type="text/css" href="../css/bootstrap-multiselect.css" />
        <link rel="stylesheet" type="text/css" href="../css/multi-select.css" />
        <!-- <link rel="stylesheet" type="text/css" href="../css/style.css"> -->
        <link rel="stylesheet" type="text/css" href="../css/pages.css">
    </head>

    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="pcoded-wrapper">
                <div class="main-body" >
                    <div class="page-wrapper">
                        <div class="card mainBody">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 m-b-30">
                                        <h4>Course Type</h4>
                                        <hr style="margin-left:0%;" />
                                        <span style="font-size:17px;">Compulsory Courses</span><span  style="font-size:17px;margin-left:45%;">Elective Courses</span>
                                        <br/><br/>
                                        <select id='public-methods' multiple='multiple'>
                                            <option value='elem_1'>elem 1</option>
                                            <option value='elem_17'>elem 17</option>
                                            <option value='elem_3'>elem 3</option>
                                            <option value='elem_4'>elem 4</option>
                                            <option value='elem_5'>elem 5</option>
                                            <option value='elem_6'>elem 6</option>
                                            <option value='elem_7'>elem 7</option>
                                            <option value='elem_8'>elem 8</option>
                                            <option value='elem_9'>elem 9</option>
                                            <option value='elem_10'>elem 10</option>
                                            <option value='elem_11'>elem 11</option>
                                            <option value='elem_12'>elem 12</option>
                                            <option value='elem_13'>elem 13</option>
                                            <option value='elem_14'>elem 14</option>
                                            <option value='elem_15'>elem 15</option>
                                            <option value='elem_16'>elem 16</option>
                                        </select>
                                        <br /><br />
                                        <button type="button" class="btn btn-primary waves-effect waves-light m-b-10">
                                            Update
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script type="88add89075ed2b878b934720-text/javascript" src="../js/select2.full.min.js"></script>
        <script type="88add89075ed2b878b934720-text/javascript" src="../js/bootstrap-multiselect.js"></script>
        <script type="88add89075ed2b878b934720-text/javascript" src="../js/jquery.multi-select.js"></script>
        <script type="88add89075ed2b878b934720-text/javascript" src="../js/jquery.quicksearch.js"></script>
        <script type="88add89075ed2b878b934720-text/javascript" src="../js/select2-custom.js"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="88add89075ed2b878b934720-|49" defer=""></script>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>