<?php
    include("../COMMON_FILES/Connection.php");
    error_reporting(0);
    @$program = $_POST['program'];
    @$year = $_POST['year'];
    @$sem = $_POST['sem'];
    @$div = $_POST['div'];

    $QRY = "SELECT * FROM Mtb_CourseSchedule WHERE CRSE_SCHED_PID = $program AND CRSE_SCHED_Year = '$year' AND substring(CRSE_SCHED_CourseID,6,1) = $sem
            AND CRSE_SCHED_Division = '$div' GROUP BY CRSE_SCHED_Day ORDER BY FIELD(CRSE_SCHED_Day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), DATE_FORMAT(CRSE_SCHED_StartTime,'%T')";
    @$data_QRY = mysqli_query($con,$QRY);
    @$cnt = mysqli_num_rows($data_QRY);
    if(!empty($program) && !empty($year) && !empty($sem) && !empty($div))
    {
        if($cnt)
        {
            echo '
                <table style="width:95.5%;margin-left:3.5%;height:37rem;" class="table table-striped table-bordered wrap">
                    <thead>
                        <tr><th style="text-align:center;">Day<br/>Time</th>
            ';
        }
        else
        {
            echo "<br/><span style='margin-left:3.7%;font-size:18px;color:red;'>No Course Schedule Found</span>";
        }
        while(@$res = mysqli_fetch_array($data_QRY))
        {
            echo "<th style='width:16%;text-align:center;border-right:none;height:5rem;border-left:none;padding-top:2.5%!important;padding-bottom:2%!important;'>".$res['CRSE_SCHED_Day']."</th>";
        }
        echo "      </tr>
                </thead>
                <tbody>
                    <tr>
        ";
        @$QRY = "SELECT * FROM Mtb_CourseSchedule WHERE CRSE_SCHED_PID = $program AND CRSE_SCHED_Year = '$year' AND substring(CRSE_SCHED_CourseID,6,1) = $sem
                AND CRSE_SCHED_Division = '$div' GROUP BY DATE_FORMAT(CRSE_SCHED_StartTime,'%T') ORDER BY DATE_FORMAT(CRSE_SCHED_StartTime,'%T')";
        @$data_QRY_2 = mysqli_query($con,$QRY);
        while(@$res = mysqli_fetch_array($data_QRY_2))
        {
            echo "
                <td style='width:10%;background-color:white;padding-top:2.1%!important;padding-bottom:1.8%!important;'>".date('h:i A', strtotime($res['CRSE_SCHED_StartTime']))."<br/>
                ".date('h:i A', strtotime($res['CRSE_SCHED_EndTime']))."</td>
            ";
            $QRY_CRSE = "SELECT CRSE_SCHED_CourseID FROM Mtb_CourseSchedule WHERE CRSE_SCHED_StartTime = '".$res['CRSE_SCHED_StartTime']."' AND CRSE_SCHED_PID = $program 
                AND CRSE_SCHED_Year = '$year' AND substring(CRSE_SCHED_CourseID,6,1) = $sem AND CRSE_SCHED_Division = '$div' GROUP BY  FIELD(CRSE_SCHED_Day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')";
            @$data_QRY_3 = mysqli_query($con,$QRY_CRSE);
            $cnt = 0;
            while($r = mysqli_fetch_assoc($data_QRY_3))
            {
                echo"
                    <td style='width:13%;border:none;text-align:center;padding-top:2.6%!important;padding-bottom:2.5%!important;'>".$r['CRSE_SCHED_CourseID']."</td>
                ";
                if($cnt == 4)
                {
                    echo"</tr>";
                    break;
                }
                $cnt++;
            }
        }
        echo "      </tr>
                </tbody>
            </table>
        ";
    }
?>