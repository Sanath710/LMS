<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" && isset($_POST['btnSubmit']))
    {    
        include("../COMMON_FILES/Connection.php");

        # Form Data Received
        $programme = $_POST['selProgramID'];
        $CourseName = mysqli_real_escape_string($con,$_POST['CourseName']);
        $CourseStatus = $_POST['CourseStatus'];
        $CourseType = $_POST['selCourseType'];
        $Sem = $_POST['selSemester'];

        $CourseID = str_pad($programme,3,0);                # Programme Code Attached (eg : 300)
        $CourseID .= "1";                                   # Numeric Value Attached (eg : 3001)
        $CourseID .= str_pad($Sem,2,0,STR_PAD_LEFT);        # Semester Value Attached (eg : 300102)

        # For getting ID of course
        $crse_QRY = "SELECT substring(CRSE_ID,-2) as id FROM Mtb_Courses WHERE substring(CRSE_ID,5,2) = LPAD($Sem,2,0) AND substring(CRSE_ID,1,1) = $programme ORDER BY CRSE_ID DESC LIMIT 1";
        $crse_Data = mysqli_query($con,$crse_QRY);
        $crse = mysqli_fetch_assoc($crse_Data);
        // print_r(mysqli_fetch_assoc($crse_Data));

        $crse = intval($crse['id'])+1;
        # Final Course ID Creation
        if(mysqli_fetch_assoc(mysqli_query($con,$crse_QRY))) {
            # Finalizing Course ID
            // $CourseID .= $crse;
            $CourseID .= str_pad($crse, 2, 0, STR_PAD_LEFT);  
        } else {
            $CourseID .="01";
        }
        if(!empty($CourseID) && !empty($CourseName))
        {
            $d = date("Y");

            $master_sql = "INSERT INTO Mtb_Courses (CRSE_ID, CRSE_Name, CRSE_LastModified, CRSE_Status) VALUES (?,?,?,?)";
            $master_stmt = mysqli_stmt_init($con);
            $trasnsaction_sql = "INSERT INTO Tb_ProgrammeCourseTypes (PRGM_CRSE_PID, PRGM_CRSE_CourseID, PRGM_CRSE_AcademicYear, PRGM_CRSE_CourseType, PRGM_CRSE_Sem) VALUES (?,?,?,?,?)";
            $transaction_stmt = mysqli_stmt_init($con);

            $PID_QRY = "SELECT PID FROM Mtb_Programme WHERE PRGM_Code = $programme";
            $PID_Data = mysqli_query($con,$PID_QRY);
            $PID = mysqli_fetch_assoc($PID_Data);
            $PID = $PID['PID'];

            if(!mysqli_stmt_prepare($master_stmt,$master_sql)) {
                # Error in Prepare Statement
                header("refresh:0;url=viewCourses.php?Status=8&t=M");
            }
            else {
                if(!mysqli_stmt_prepare($transaction_stmt,$trasnsaction_sql)) {
                    # Error in Prepare Statement
                    header("refresh:0;url=viewCourses.php?Status=8&t=t");
                } 
                else {
                    mysqli_stmt_bind_param($master_stmt,"issi",$CourseID,$CourseName,$d,$CourseStatus);

                    if(!mysqli_stmt_execute($master_stmt)) 
                    {
                        header("refresh:0;url=viewCourses.php?Status=6");
                    }
                    else {
                        mysqli_stmt_bind_param($transaction_stmt,"iiiii",$PID,$CourseID,$d,$CourseType,$Sem);
                        if(!mysqli_stmt_execute($transaction_stmt)) 
                        {
                            $delete = "DELETE FROM Mtb_Courses WHERE CRSE_ID = $CourseID";
                            mysqli_query($con,$delete);
                            header("refresh:0;url=viewCourses.php?Status=6");
                        }
                        else {
                            header("refresh:0;url=viewCourses.php?Status=1&id=$CourseID");
                        }
                    }
                }
            }
        }
        else {
            header("refresh:0;url=viewCourses.php?Status=7");
        }
    }
    else {
        echo "You Don't have previleges to access this page.<br/>This incident will be reported along with your IP.";
        header("refresh:2;url=../COMMON_FILES/logout.php");
    }

?>