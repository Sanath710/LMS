<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {   
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
      include_once("adminNavbar.php");
    }
    else if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
      include_once("../HoD/teacherNavbar.php");
    }
    include("../COMMON_FILES/Connection.php");
    $URL_PRGM_ID = substr($_GET['pRgM'],9,1);
    $URL_PRGM_Name = base64_decode(substr($_GET['pRgM'],5,4));

    $query ="SELECT PRGM_CRSE_AcademicYear FROM Tb_ProgrammeCourseTypes WHERE PRGM_CRSE_PID = $URL_PRGM_ID GROUP BY PRGM_CRSE_PID,PRGM_CRSE_AcademicYear";
    $data = mysqli_query($con,$query);
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    </head>
    <body>
        <div class="pcoded-content">
            <div class="main-body">
                <div class="page-wrapper subBodyProgram">
                    <div class="card bodyStyling">
                        <div class="card-header" style="margin-top:0.5%;">
                        <h4>Available Batches for&nbsp;<?php echo $URL_PRGM_Name; ?></h4>
                        <hr style="width:97.8%; margin-left:0%;" />
                        </div>
                        <br />
                        <div class="page-body" style="display:flex;flex-wrap:wrap;">
                        <?php 
                            while($prgms = mysqli_fetch_assoc($data))
                            {
                        ?>
                        <div class="card sale-card" style="margin-left:3.01%;margin-top:1%;padding-left:1.6%;padding-right:1.6%;padding-top:0.8%;">
                            <div class="card-block text-center">
                            <?php
                                // For URL Parameter encoding
                                $tempNum1 = substr(str_shuffle(str_repeat("0123456789", 5)), 0, 5);
                                $tempNum2 = substr(str_shuffle(str_repeat("0123456789", 5)), 0, 5);


                                echo '<a href="assignedBatchSem.php?pRgM='.$tempNum1.$prgms['PRGM_CRSE_AcademicYear'].$_GET['pRgM'].$tempNum2.'">
                                        <i class="fa fa-folder-o" style="font-size:45px;margin-right:1.7%;">
                                        <h6 style="display:flex;padding:5%;margin-left:-19%;margin-top:15%;">&nbsp;&nbsp;'.$prgms['PRGM_CRSE_AcademicYear'].'</h6>
                                        </i>
                                    </a>';
                            ?>
                            </div>
                        </div>
                        <?php
                            }
                        ?>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>