<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {    
        include ("adminNavbar.php");
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['Status']==1)
        {
            echo 
            '
                <script> 
                    swal("Success", "Course Added Successfully.!", "success");
                </script>
            ';
        }
        else if($_GET['Status']==2)
        {
            $Status = "border:1px solid red;";
            $ERROR_MSG = "<span style='color:red; font-size:14px;'>Please Enter Some Other Course ID.<br/> Previously Entered Course ID was Already Taken.!</span>";
        }
        else if(($_GET['Status']==3))
        {
            echo 
            '
                <script> 
                    swal("warning", "Invalid Data or No Data Received.!!", "warning");
                </script>
            ';
        }
        else if($_GET['Status']==4)
        {
            echo 
            '
                <script> 
                    swal("warning", "ERROR in Prepare Statement.!", "warning");
                </script>
            ';
        }
        else if($_GET['Status']==5)
        {
            echo 
            '
                <script> 
                    swal("Error", "Some error occured while moving file to destination", "warning");
                </script>
            ';
        }
        else if($_GET['Status']==6)
        {
            echo 
            '
                <script> 
                    swal("Error", "Some error occured while uploading image", "warning");
                </script>
            ';
        }
        else if($_GET['Status']==7)
        {
            echo 
            '
                <script> 
                    swal("Error", "Unsupported image file format.\nOnly JPEG, JPG & PNG Format is allowed.", "warning");
                </script>
            ';
        }
        else if($_GET['Status']==9)
        {
            echo '
                <script> 
                    swal("Sorry", "Image File Size must be greater than 20 kb.", "info");
                </script>
            ';
        }
        else if($_GET['Status']==8)
        {
            echo '
                <script> 
                    swal("Sorry", "Image File Size must be lesser than 2 MB.", "info");
                </script>
            ';
        }
?>
<html>
    <head>
        <title>New Course</title>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="main-body frmTxt">
                <div class="page-wrapper">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card mainBody bodyStyling">
                                <div class="card-header">
                                    <h4>New Course</h4>
                                    <hr />
                                </div><br /><br />
                                <div class="card-block progFormBody">
                                    <form id="main" method="POST" action="newCourse_DB.php" enctype="Multipart/form-data">
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label frmTxt">Course ID</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control frmTxt" style='<?php echo $ERROR; ?>'
                                                    name="CourseID" autocomplete="off" id="CourseID" required
                                                    onkeyup="valueCheck()" pattern="[0-9]{9}"
                                                    title="Please Enter Only Numeric Values of minimum & maximum length 9"
                                                    minLength="9" maxlength="9" placeholder="Enter Course ID (Maximum length 9)" />
                                                <span id="messages">
                                                    <?php echo $ERROR_MSG; ?>
                                                </span>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label frmTxt">Course Name</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control frmTxt" name="CourseName"
                                                    autocomplete="off" id="CourseName" required onkeyup="valueCheck()"
                                                    pattern="[A-Za-z]{1,}[A-Z\s&a-z0-9]{0,}"
                                                    title="Enter Only Aphabetical Characters along with numeric values. No Special Characters are allowed other than '&'."
                                                    placeholder="Enter Course Name " />
                                            </div>
                                        </div>
                                        <br />
                                        <div class="row">
                                            <label class="col-sm-2 col-form-label frmTxt">Course status</label>
                                            <div class="col-sm-4">
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        Active <input type="radio" name="CourseStatus" value="1" checked />
                                                    </label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        Deactive <input type="radio" name="CourseStatus" value="0" />
                                                    </label>
                                                </div>
                                                <span class="messages"></span>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label frmTxt">Upload Image</label>
                                            <div class="col-sm-4">
                                                <input type="file" class="form-control frmTxt" name="coursePic" required/>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <label class="col-sm-2"></label>
                                            <div class="col-sm-4">
                                                <input type="submit" class="btn btn-primary m-b-0 btnEffect btnSubmit"
                                                    id="Submit" onclick="return inputChecker()" name="btnSubmit"/>&nbsp;
                                                <input type="reset" class="btn btn-primary m-b-0 btnEffect btnSubmit"
                                                    onmouseout="valueCheck()" />
                                            </div>
                                        </div>
                                    </form>
                                    <script>
                                        if (document.getElementById("CourseID").value == '' || document.getElementById("CourseName").value == '') 
                                        {
                                            var x = document.querySelector("#Submit");
                                            x.style.display = "none";
                                        }
                                        function valueCheck() 
                                        {
                                            if (document.getElementById("CourseID").value != '' && document.getElementById("CourseName").value != '') 
                                            {
                                                x.removeAttribute("style");
                                            }
                                            else 
                                            {
                                                styleAttr = document.createAttribute("style");
                                                styleAttr.value = "display:none";
                                                x.setAttributeNode(styleAttr);
                                            }
                                        }
                                        function inputChecker() 
                                        {
                                            if (document.getElementById("CourseID").value == '') 
                                            {
                                                alert("Enter Course ID");
                                                return false;
                                            }
                                            else if (document.getElementById("CourseName").value == '') 
                                            {
                                                alert("Enter Course Name");
                                                return false;
                                            }
                                            return true;
                                        }
                                        if (window.history.replaceState) 
                                        {
                                            window.history.replaceState(null, null, "newCourse.php");
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>