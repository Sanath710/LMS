<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
        include_once("adminNavbar.php");
        include("../COMMON_FILES/Connection.php");

        function getProg($con) {
            $sql = "SELECT PID, PRGM_ID FROM Mtb_Programme";
            $dataSet = mysqli_query($con,$sql);
            while($res = mysqli_fetch_assoc($dataSet)) {
                echo "<option value='".$res['PID']."'>".$res['PRGM_ID']."</option>";
            }
        }

        function getSem($con) {
            $sql = "SELECT distinct(CRSE_USR_Sem) as sem FROM Tb_CourseUsers ORDER BY CRSE_USR_Sem";
            $dataSet = mysqli_query($con,$sql);
            while($res = mysqli_fetch_assoc($dataSet)) {
                echo "<option value='".$res['sem']."'>".$res['sem']."</option>";
            }
        }

        function getYear($con) {
            $sql = "SELECT distinct(PRGM_CRSE_AcademicYear) as acYear FROM Tb_ProgrammeCourseTypes ORDER BY PRGM_CRSE_AcademicYear DESC";
            $dataSet = mysqli_query($con,$sql);
            while($res = mysqli_fetch_assoc($dataSet)) {
                echo "<option value='".$res['acYear']."'>".$res['acYear']."</option>";
            }
        }
?>
<html>
    <head>
        <title>LMS | Generate Schedule</title>
        <style>
            .schedule-form-body {
                margin-left:3.5%;
            }
            .label-schedule-form,.label-schedule-form-label,.label-schedule-form-label-right {
                font-weight:550;
                font-size:18px;
            }
            .label-schedule-form-label,.label-schedule-form-label-right {
                margin-right:1.5%;
            }
            .label-schedule-form-label-right {
                margin-left:4%;
            }
            .dynamic-elements {
                cursor:pointer;
            }
            .course-table {
                font-size:16px;
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <!-- Main Body Starts -->
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="row" style="min-height:53.8rem;">
                        <div class="col-sm-12">
                            <div class="card mainBody bodyStyling" style="min-height:53.8rem;">
                                <div class="card-block usrFormBody">
                                    <h4 style=" margin-left:2%;font-weight:bold;">Generate Schedule</h4>
                                    <hr style="width:96.8%;"/>
                                </div>
                                <div class="schedule-form-body">
                                    <form method="POST" action="generateSchedule_DB.php">
                                        <label class="label-schedule-form">Programme : </label> &nbsp;
                                        <select name="PRGM_Name" style="cursor:pointer;min-width:6%;height:2rem;" onchange="getPro(this)">
                                            <option value='x'>Select</option>
                                            <?php
                                                getProg($con);
                                            ?>
                                        </select>
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <label class="label-schedule-form">Academic Year : </label> &nbsp;
                                        <select name="year" style="cursor:pointer;min-width:6%;height:2rem;" onchange="getYear(this)">
                                            <option value='0'>Select</option>
                                            <?php
                                                getYear($con);
                                            ?>
                                        </select>
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <label class="label-schedule-form">Semester : </label> &nbsp;
                                        <select name="semester" style="cursor:pointer;min-width:6%;margin-right:1%;height:2rem;" onchange="getSem(this)">
                                            <option value='0'>Select</option>
                                            <?php
                                                getSem($con);
                                            ?>
                                        </select>
                                        <div id="lect-Details" style="display:none;">
                                            <div id="course-Dataset" style="width:50%;display:none;margin-top:1%;margin-right:3%;"></div>
                                            <div style="width:40%;margin-top:2.3%;">
                                                <label class="label-schedule-form m-t-7">Total Lectures (per day)&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : &nbsp;</label> &nbsp;
                                                <select name="selTotalLectures" style="width:7%;cursor:pointer;height:2rem;">
                                                    <?php
                                                        for($i=1;$i<=7;$i++) {
                                                            echo "<option value='".$i."'>".$i."</option>";
                                                        }
                                                    ?>
                                                </select>
                                                <!-- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -->
                                                <br/>
                                                <label class="label-schedule-form" style="margin-top:1.5%;">Lecture Duration (in hours) &nbsp;&nbsp; : &nbsp; </label> &nbsp;
                                                <select name="selLectureDuration" style="width:7%;cursor:pointer;height:2rem;">
                                                    <?php
                                                        for($i=1;$i<=3;$i++) {
                                                            echo "<option value='".$i."'>".$i."</option>";
                                                        }
                                                    ?>
                                                </select>
                                                <br/>
                                                <label class="label-schedule-form" style="margin-top:1.3%;">Lecture Starting Time &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; : &nbsp; </label> &nbsp;
                                                <input type="time" name="txtLectureStartTime" style="cursor:pointer;height:2rem;"  required/>
                                                <br/><br/>
                                                <label class="label-schedule-form" style="margin-top:1.5%;font-size:19px;">Total breaks &nbsp;: </label> &nbsp;
                                                <select name="selTotalBreaks" style="cursor:pointer;width:7%;height:2rem;" onchange="generateElement(this)">
                                                    <option value="0">0</option>
                                                    <?php
                                                        for($i=1;$i<=4;$i++) {
                                                            echo "<option value='".$i."'>".$i."</option>";
                                                        }
                                                    ?>
                                                </select>
                                                <div id="dynamic-elements" style="margin-top:2%;"></div>
                                                <br/>
                                            </div>
                                        </div>
                                        <script>
                                            let Programme = 0;
                                            let sem = 0;
                                            let year = 0;

                                            function getPro(e)
                                            {
                                                Programme = e.value
                                                getCourses();
                                            }
                        
                                            function getSem(e)
                                            {
                                                sem = e.value
                                                getCourses();
                                            }

                                            function getYear(e)
                                            {
                                                year = e.value
                                                getCourses();
                                            }

                                            function generateElement(e)
                                            {
                                                let cnt = e.value;
                                                let container = document.getElementById("dynamic-elements");

                                                while (container.hasChildNodes()) {
                                                    container.removeChild(container.lastChild);
                                                }
                                                for(i = 1; i <= cnt; i++) {

                                                    let labelStart = document.createElement("span");
                                                    labelStart.innerHTML = i+".  Start time &nbsp;&nbsp;: ";
                                                    labelStart.className = "label-schedule-form-label";
                                                    container.appendChild(labelStart);

                                                    let startInput = document.createElement("input");
                                                    startInput.type = "time";
                                                    startInput.className = "dynamic-elements"
                                                    startInput.name = "txtStartBreak[]";
                                                    container.appendChild(startInput);
                                                    
                                                    let labelEnd = document.createElement("span");
                                                    labelEnd.innerHTML = "End time : ";
                                                    labelEnd.className = "label-schedule-form-label-right";
                                                    container.appendChild(labelEnd);

                                                    let endInput = document.createElement("input");
                                                    endInput.type = "time";
                                                    endInput.name = "txtEndBreak[]";
                                                    container.appendChild(endInput);

                                                    container.appendChild(document.createElement("br"));
                                                    container.appendChild(document.createElement("br"));
                                                }
                                            }

                                            // For Displaying only that courses which is based on the semester selected by a teacher
                                            function getCourses()
                                            {

                                                if(Programme == 'x' || sem == 0 || year == 0)
                                                {
                                                    document.getElementById("course-Dataset").style.display="none";
                                                    document.getElementById("lect-Details").style.display="none";
                                                }
                                                else
                                                {
                                                    let xhr;

                                                    (window.XMLHttpRequest) ? xhr = new XMLHttpRequest() : xhr = new ActiveXObject("Microsoft.XMLHTTP");
                                                    
                                                    let data = "programme="+Programme+"&sem="+sem+"&year="+year;
                                                
                                                    xhr.open("POST","AJAX_GenerateSchedule.php",true);
                                                    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                                                    xhr.send(data);
                                                    xhr.onreadystatechange = display; 

                                                    function display()
                                                    {
                                                        if(xhr.readyState == 4)
                                                        {
                                                            if(xhr.status == 200)
                                                            {
                                                                document.getElementById("course-Dataset").style.display="";
                                                                document.getElementById("lect-Details").style.display="flex";
                                                                document.getElementById("course-Dataset").innerHTML = xhr.responseText;
                                                            }
                                                            else
                                                            {
                                                                alert("There was a problem with the request");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        </script>
                                        <noscript>
                                            Your Browser Does not Suppport JavaScript. Please Change Your Browser.
                                        </noscript>
                                        <br/>
                                        <input type="submit" style="margin-top:1%;margin-bottom:2%;" class="btn btn-primary waves-effect waves-light" name="btnGenerate" value="Generate"/>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>