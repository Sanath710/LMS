<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {    
        include_once("../admin/adminNavbar.php");
        include("../COMMON_FILES/Connection.php");

        function getUsers($USR_ID) {
            include("../COMMON_FILES/Connection.php");
            $total_Qry = "SELECT count(*) as totalUser FROM Mtb_Users WHERE USR_ID LIKE '$USR_ID'";
            $total_Data = mysqli_query($con,$total_Qry);
            $total = mysqli_fetch_assoc($total_Data);
            $total = $total['totalUser'];
            return $total;
        }

        function activeUsers($USR_ID) {
            include("../COMMON_FILES/Connection.php");
            $activeCnt_Qry = "SELECT count(*) as cnt FROM Mtb_Users WHERE USR_Session != '' AND USR_ID LIKE '$USR_ID'";
            $activeCnt_Data = mysqli_query($con,$activeCnt_Qry);
            $activeCnt = mysqli_fetch_assoc($activeCnt_Data);
            $activeCnt = $activeCnt['cnt'];
            return $activeCnt;
        }

        function getUploadData($USR_ID, $month) {
            include("../COMMON_FILES/Connection.php");
            $year = date("Y");
            $getUploads_Qry = 
                    "SELECT count(*) as total_uploads FROM mtb_coursedocs_new 
                     WHERE CRSE_DOC_Year = $year AND CRSE_DOC_USR_ID LIKE '$USR_ID' 
                     AND MONTHNAME(CRSE_DOC_Submission) = '$month'
                     Group by MONTH(CRSE_DOC_Submission)";
            $getUploads_Data = mysqli_query($con,$getUploads_Qry);
            $res = mysqli_fetch_assoc($getUploads_Data);
            if($res['total_uploads']) {
                return $res['total_uploads'];
            }
            else {
                return 0;
            }
        }

        function yearlyUploads($year) {
            include("../COMMON_FILES/Connection.php");
            $getYearlyUploads_Qry = "SELECT count(*) as total 
                                     FROM mtb_coursedocs_new 
                                     Where YEAR(CRSE_DOC_Submission) = '$year' 
                                     GROUP by YEAR(CRSE_DOC_Submission)";
            $getYearlyUploads_Data = mysqli_Query($con,$getYearlyUploads_Qry);
            $yearlyUploads = mysqli_fetch_assoc($getYearlyUploads_Data);
            if($yearlyUploads['total']) {
                return $yearlyUploads['total'];
            }
            else {
                return 0;
            }
        }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>LMS | Dashboard</title>
        <link rel="stylesheet" type="text/css" href="../css/widget.css">
        
        <script type="text/javascript" src="../js/google_loader.js"></script>
        <!-- <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script> -->
        <!-- <link rel="stylesheet" type="text/css" href="../css/widget.css"> -->
        <!-- For Active Student/Teacher Icon -->
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <style>
            .main-panel {
                display: table;
                width: 100%;
                table-layout: fixed;
                text-align: left;
                padding: 0.5%;

            }

            .main-panel .rightPanel {
                border: 1px solid rgba(0, 0, 0, .125);
                border-radius: .25rem;
            }

            .btn-view :hover {
                color: blue;
                cursor: pointer;
                text-decoration: underline;
            }

            .scroll-widget {
                height:335px!important;
            }
        </style>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="main-body" style="margin-left:-0.5%;">
                <div class="page-wrapper">
                    <!-- <div class="page-header card"  style="margin-left:0.7%;margin-top:1%;">
                        <div class="row align-items-end">
                            <div class="col-lg-8">
                                <div class="page-header-title">
                                    <i class="feather icon-home bg-c-blue"></i>
                                    <div class="d-inline">
                                        <h5>Dashboard</h5>
                                        <span style="font-weight:510;">Welcome <?php //echo $_SESSION['Sess_USR_Name']; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="" style="margin-left:18%;">
                                <div class="page-header-breadcrumb">
                                    <ul class=" breadcrumb breadcrumb-title">
                                        <li class="breadcrumb-item">
                                            Logged In as 
                                        </li>
                                        <li class="breadcrumb-item"><?php //echo $_SESSION['Sess_USR_ID']; ?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <div class="page-body main-panel" style="display:flex;">
                        <div class="leftPanel" style="margin-right:0.8%;width: 67%;">
                            <!-- <div class="page-header card"  style="margin-left:0.7%;margin-top:2.5%;margin-bottom:4%;">
                                <div class="row align-items-end">
                                    <div class="col-lg-10">
                                        <div class="page-header-title">
                                            <i class="feather icon-home bg-c-blue"></i>
                                            <div class="d-inline">
                                                <h5>Dashboard</h5>
                                                <span style="font-weight:510;">Welcome <?php //echo $_SESSION['Sess_USR_Name']."&nbsp;&nbsp;(".$_SESSION['Sess_USR_ID'].")"; ?></span>
                                            </div>
                                        </div>
                                    </div> -->
                                <!-- <div class="" style="margin-left:18%;">
                                    <div class="page-header-breadcrumb">
                                        <ul class=" breadcrumb breadcrumb-title">
                                            <li class="breadcrumb-item">
                                                Logged In as 
                                            </li>
                                            <li class="breadcrumb-item"><?php //echo $_SESSION['Sess_USR_ID']; ?></li>
                                        </ul>
                                    </div>
                                </div> -->
                            <!-- </div> -->
                        <!-- </div> -->
                            <div class="card analytic-card card-blue" style="margin-bottom:2.3%;">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-10">
                                        <div class="col-auto">
                                            <i class="fas fa-users text-c-blue f-18 analytic-icon"></i>
                                        </div>
                                        <?php
                                                $totalUsers_Qry = "SELECT count(*) as totalUsers FROM Mtb_Users";
                                                $totalUsers_Data = mysqli_query($con,$totalUsers_Qry);
                                                $totalUsers = mysqli_fetch_assoc($totalUsers_Data);
                                                $totalUsers = $totalUsers['totalUsers'];
                                            ?>
                                        <div class="col text-right">
                                            <h3 class="m-b-5 text-white">
                                                <?php echo $totalUsers; ?>
                                            </h3>
                                            <h6 class="m-b-0 m-t-10 text-white" style="font-weight:bold;">Total Users</h6>
                                        </div>
                                    </div>
                                    <h6 class="m-b-0 d-inline-block text-white float-left" style="font-weight:bold;">
                                        <p class="m-b-0 text-white d-inline-block">Admin <i
                                                class="fas fa-caret-right m-l-5 m-r-5 f-18"></i></p>
                                        <?php echo getUsers("A%"); ?>
                                        <br />
                                        <p class="m-b-0 text-white d-inline-block" style="margin-left:17.5%;">HoD <i
                                                class="fas fa-caret-right m-l-5 m-r-5 f-18"></i></p>
                                        <?php echo getUsers("H%"); ?>
                                    </h6>
                                    <h6 class="m-b-0 d-inline-block text-white float-right" style="font-weight:bold;">
                                        <p class="m-b-0 text-white d-inline-block">Teachers <i
                                                class="fas fa-caret-right m-l-5 m-r-5 f-18"></i></p>
                                        <?php echo getUsers("T%"); ?>
                                        <br />
                                        <p class="m-b-0 text-white d-inline-block">Students <i
                                                class="fas fa-caret-right m-l-5 m-r-5 f-18"></i></p>

                                        <?php echo getUsers("S%"); ?>
                                    </h6>
                                </div>
                            </div>
                            <div style="display:flx;">
                                <div class="card proj-t-card" style="margin-bottom:2.3%;margin-right:2%;width:100%;">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <i class='fas fa-chalkboard-teacher text-c-red f-30'></i>
                                            </div>
                                            <div class="col p-l-0">
                                                <h6 class="m-b-5 m-t-5" style="font-weight:510;">Teachers</h6>
                                                <h6 class="m-b-5 text-c-red m-t-8">Active Now</h6>
                                            </div>
                                        </div>
                                        <div class="row align-items-center text-right">
                                            <div class="col btn-view" data-toggle="modal" data-target="#default-Modal_Teacher">
                                                <h6 class="m-b-0">View &nbsp;<i class="fa fa-sort-down"></i></h6>
                                            </div>
                                        </div>
                                        <h6 class="pt-badge bg-c-red">
                                            <?php echo "&nbsp;".activeUsers("T%")."&nbsp;"; ?>
                                        </h6>
                                    </div>
                                </div>
                                <div class="card proj-t-card" style="margin-bottom:2.3%;width:100%;">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <i class='fas fa-user-graduate text-c-blue f-30'></i>
                                            </div>
                                            <div class="col p-l-0">
                                                <h6 class="m-b-5 m-t-5" style="font-weight:510;">Students</h6>
                                                <h6 class="m-b-5 text-c-blue m-t-8">Active Now</h6>
                                            </div>
                                        </div>
                                        <div class="row align-items-center text-right">
                                            <div class="col btn-view" data-toggle="modal" data-target="#default-Modal_Student">
                                                <h6 class="m-b-0">View &nbsp;<i class="fa fa-sort-down"></i></h6>
                                            </div>
                                        </div>
                                        <h6 class="pt-badge bg-c-blue">
                                            <?php echo "&nbsp;".activeUsers("S%")."&nbsp;"; ?>
                                        </h6>
                                    </div>
                                </div>
                            </div>
                            <div class="card proj-t-card" style="margin-bottom:-0.5%;min-height:28.55rem;">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col p-l-0 m-t-5">
                                            <h6 class="m-b-5 m-l-15" style="font-weight:510;">
                                                Scheduled  Meetings
                                                <hr style="width:38%;margin-left:0%;"/>
                                                <div class="card-block" style="margin-top:-2.8%;">
                                                    <div class="slimScrollDiv" style="position: relative; overflow: visible; width: 107%; ">
                                                        <div class="scroll-widget" style="overflow-y: scroll; overflow-x:hidden; width: auto;">
                                                            <div class="latest-update-box">
                                                            <?php
                                                                // echo "*************************";
                                                                    $meetings = 0;
                                                                    $cnt = 0; #colored circle purpose
                                                                    $getSched_Qry = "SELECT PRGM_ID, CRSE_SCHED_CourseID,  CRSE_SCHED_Division, substring(CRSE_SCHED_CourseID, 5, 2) as semester, 
                                                                                            CRSE_SCHED_StartTime, CRSE_SCHED_EndTime, CRSE_SCHED_LectureLink
                                                                                     FROM mtb_courseschedule, mtb_programme WHERE mtb_programme.PID = CRSE_SCHED_PID 
                                                                                     AND time(now()) <= time(CRSE_SCHED_EndTime) AND DAYNAME(now()) = CRSE_SCHED_Day 
                                                                                     ORDER BY (CRSE_SCHED_StartTime)";
                                                                    $getSchedData = mysqli_query($con, $getSched_Qry);
                                                                    while($schedule = mysqli_fetch_array($getSchedData))
                                                                    {
                                                                        $meetings++;
                                                                        if($cnt%2 == 0)
                                                                        {
                                                                            echo '
                                                                            <div class="row p-b-30">
                                                                                <div class="col-auto text-right update-meta p-r-0">
                                                                                    <i class="b-danger update-icon ring"></i>
                                                                                </div>
                                                                                <div class="col p-l-10">
                                                                                    <span>
                                                                                        <h6 style="font-size:17px;font-weight:bold;">'.$schedule[0].'&nbsp; - '.$schedule[1].'&nbsp; ('.date("g:i a", strtotime($schedule[4])).' - '.date("g:i a", strtotime($schedule[5])).')</h6>
                                                                                    </span>
                                                                                    <p class="text-muted m-b-0">Semester : '.$schedule[3].' &nbsp; Division : '.$schedule[2].'</p>
                                                                                </div>
                                                                            </div>
                                                                            ';
                                                                        }
                                                                        else
                                                                        {
                                                                            echo '
                                                                            <div class="row p-b-30">
                                                                                <div class="col-auto text-right update-meta p-r-0">
                                                                                    <i class="b-primary update-icon ring"></i>
                                                                                </div>
                                                                                <div class="col p-l-10">
                                                                                    <span>
                                                                                        <h6 style="font-size:17px;font-weight:bold;">'.$schedule[0].'&nbsp; - '.$schedule[1].'&nbsp; ('.date("g:i a", strtotime($schedule[4])).' - '.date("g:i a", strtotime($schedule[5])).')</h6>
                                                                                    </span>
                                                                                    <p class="text-muted m-b-0">Semester : '.$schedule[3].' &nbsp; Division : '.$schedule[2].'</p>
                                                                                </div>
                                                                            </div>
                                                                            ';
                                                                        }
                                                                        $cnt++;
                                                                    }
                                                                    echo '
                                                                    <div class="row">
                                                                        <div class="col-auto text-right update-meta p-r-0">
                                                                            <i class="b-success update-icon ring"></i>
                                                                        </div>
                                                                        <div class="col p-l-10" style="font-size:15.5px;margin-bottom:0%;font-weight:bold;">
                                                                            That\'s all for the day.
                                                                        </div>
                                                                    </div>
                                                                    ';
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 100%;margin-bottom:-2.5%;">
                            <div class="top-section" style="display:flex;width:101%;margin-right:0%;">
                                <div class="card proj-t-card" style="margin-bottom:-0.5%;width:45%;">
                                    <div class="card-body">
                                        <div class="col p-l-0 m-t-10">
                                            <h6 class="m-b-5 m-l-15" style="font-weight:510;width:100%;">
                                                <b style="font-weight:510;">Welcome : <?php echo $_SESSION['Sess_USR_ID'];?></b>
                                                <hr style="width:40%;margin-left:0%;"/>
                                                Have a nice day,
                                                <br/><br/>
                                                Total <?php echo $meetings; ?> meetings are scheduled for the day.
                                            </h6>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="card proj-t-card" style="margin-bottom:-0.5%; width:55%;margin-left:1.2%;">
                                    <div class="card-body">
                                        <div class="col p-l-0 m-t-10">
                                            <h6 class="m-l-15" style="font-weight:510;margin-bottom:-2%;overflow:hidden;">
                                                File Uploads Year Wise
                                                <hr style="width:31%;margin-left:0%;"/>
                                            </h6>
                                            <script type="text/javascript">
                                                google.charts.load("current", {packages:["corechart"]});
                                                google.charts.setOnLoadCallback(drawChart);
                                                function drawChart() {
                                                    var data = google.visualization.arrayToDataTable([
                                                    ['Year', 'Uploads'],
                                                    ['<?php echo date("Y");?>',<?php echo yearlyUploads(date("Y"));?>],
                                                    ['<?php echo date("Y")-1;?>',<?php echo yearlyUploads(date("Y")-1);?>],
                                                    ['<?php echo date("Y")-2;?>',<?php echo yearlyUploads(date("Y")-2);?>],
                                                    ['<?php echo date("Y")-3;?>',<?php echo yearlyUploads(date("Y")-3);?>],
                                                    ['<?php echo date("Y")-4;?>',<?php echo yearlyUploads(date("Y")-4);?>]
                                                    ]);
                                                    var options = {
                                                        title: "Last 5 Year Statistics",
                                                        is3D: false,
                                                        pieHole: 0.4,
                                                        'tooltip' : {
                                                            // trigger: 'none'
                                                        },
                                                        titleTextStyle: {
                                                            fontSize: 15
                                                        }
                                                    };

                                                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));
                                                    chart.draw(data, options);
                                                }
                                            </script>
                                            <div style="height:16.8rem;margin-top:-2.5%;margin-bottom:6.5%;">
                                                <div id="piechart" style="height:22.8rem; width:170%;margin-left:-15%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card bodyStyling" style="width:101%;margin-top:1.5%;">
                                <div class="card-header m-l-10">
                                    <h6 style="font-weight:510;">File Upload Statistics</h6>
                                    <hr style="width:14.9%;margin-left:0%;" />
                                </div>
                                <div class="card-block" style="padding-top:0.5%;">
                                    <script type="text/javascript">
                                        google.charts.load('current', { 'packages': ['corechart'] });
                                        google.charts.setOnLoadCallback(drawVisualization);

                                        function drawVisualization() {
                                            // Some raw data (not necessarily accurate)
                                            var data = google.visualization.arrayToDataTable([
                                                ['Month', 'HoD', 'Teacher', 'Student'],
                                                ['Jan\n(<?php echo getUploadData("H%", "January")+getUploadData("T%", "January")+getUploadData("S%", "January");?>)', 
                                                    <?php echo getUploadData("H%", "January");?>,<?php echo getUploadData("T%", "January");?>,<?php echo getUploadData("S%", "January");?>],
                                                ['Feb\n(<?php echo getUploadData("H%", "February")+getUploadData("T%", "February")+getUploadData("S%", "February");?>)',
                                                    <?php echo getUploadData("H%", "February");?>,<?php echo getUploadData("T%", "February");?>,<?php echo getUploadData("S%", "February");?>],
                                                ['March\n(<?php echo getUploadData("H%", "March")+getUploadData("T%", "March")+getUploadData("S%", "March");?>)', 
                                                    <?php echo getUploadData("H%", "March");?>,<?php echo getUploadData("T%", "March");?>,<?php echo getUploadData("S%", "March");?>],
                                                ['Apr\n(<?php echo getUploadData("H%", "April")+getUploadData("T%", "April")+getUploadData("S%", "April");?>)',
                                                    <?php echo getUploadData("H%", "April");?>,<?php echo getUploadData("T%", "April");?>,<?php echo getUploadData("S%", "April");?>],
                                                ['May\n(<?php echo getUploadData("H%", "May")+getUploadData("T%", "May")+getUploadData("S%", "May");?>)',
                                                    <?php echo getUploadData("H%", "May");?>,<?php echo getUploadData("T%", "May");?>,<?php echo getUploadData("S%", "May");?>],
                                                ['Jun\n(<?php echo getUploadData("H%", "June")+getUploadData("T%", "June")+getUploadData("S%", "June");?>)',
                                                    <?php echo getUploadData("H%", "June");?>,<?php echo getUploadData("T%", "June");?>,<?php echo getUploadData("S%", "June");?>],
                                                ['Jul\n(<?php echo getUploadData("H%", "July")+getUploadData("T%", "July")+getUploadData("S%", "July");?>)',
                                                    <?php echo getUploadData("H%", "July");?>,<?php echo getUploadData("T%", "July");?>,<?php echo getUploadData("S%", "July");?>],
                                                ['Aug\n(<?php echo getUploadData("H%", "August")+getUploadData("T%", "August")+getUploadData("S%", "August");?>)',
                                                    <?php echo getUploadData("H%", "August");?>,<?php echo getUploadData("T%", "August");?>,<?php echo getUploadData("S%", "August");?>],
                                                ['Sept\n(<?php echo getUploadData("H%", "September")+getUploadData("T%", "September")+getUploadData("S%", "September");?>)',
                                                    <?php echo getUploadData("H%", "September");?>,<?php echo getUploadData("T%", "September");?>,<?php echo getUploadData("S%", "September");?>],
                                                ['Oct\n(<?php echo getUploadData("H%", "October")+getUploadData("T%", "October")+getUploadData("S%", "October");?>)',
                                                    <?php echo getUploadData("H%", "October");?>,<?php echo getUploadData("T%", "October");?>,<?php echo getUploadData("S%", "October");?>],
                                                ['Nov\n(<?php echo getUploadData("H%", "November")+getUploadData("T%", "November")+getUploadData("S%", "November");?>)',
                                                    <?php echo getUploadData("H%", "November");?>,<?php echo getUploadData("T%", "November");?>,<?php echo getUploadData("S%", "November");?>],
                                                ['Dec\n(<?php echo getUploadData("H%", "December")+getUploadData("T%", "December")+getUploadData("S%", "December");?>)',
                                                    <?php echo getUploadData("H%", "December");?>,<?php echo getUploadData("T%", "December");?>,<?php echo getUploadData("S%", "December");?>]
                                            ]);

                                            var options = {
                                                title: 'Files Uploaded in <?php echo date("Y"); ?>',
                                                vAxis: { title: 'Documents' },
                                                hAxis: { title: 'Month' },
                                                seriesType: 'bars'
                                                //   series: {7: {type: 'bars'}}
                                            };

                                            var chart = new google.visualization.ComboChart(document.getElementById('chart_div'));
                                            chart.draw(data, options);
                                        }
                                    </script>
                                    <div id="chart_div" style="min-height: 21.36rem; margin-top:0%;margin-bottom:1%;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal Student Details -->
                <div class="modal fade" id="default-Modal_Student" tabindex="-1" role="dialog" style="margin-left:-13%;">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content" style="width:180%;padding:1.5%;">
                            <div class="modal-header">
                                <h4 class="modal-title" style="font-weight:bold;">Online Student Details</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <table class="table">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col" style="text-align:center;">Sr No.</th>
                                        <th scope="col" style="width:19%;">User ID</th>
                                        <th scope="col" style="width:21%;">User Name</th>
                                        <th scope="col">Profile Image</th>
                                        <th scope="col">Email ID</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $activeStud_Qry = "SELECT USR_ID, USR_FirstName, USR_LastName, USR_Pic, USR_EmailID  FROM Mtb_Users WHERE USR_Session != '' AND USR_ID LIKE 'S%'";
                                        $activeStud_Data = mysqli_query($con,$activeStud_Qry);
                                        $cnt = 0;
                                        while($res = mysqli_fetch_assoc($activeStud_Data)) 
                                        {
                                            echo '
                                                <td style="text-align:center;">'.++$cnt.'</td>
                                            ';
                                            echo '
                                                </td>
                                                <td>'.$res['USR_ID'].'</td>
                                                <td>'.$res['USR_FirstName'].' '.$res['USR_LastName'].'</td>
                                                <td style="text-align:left;margin:0%;padding-top:0%;">
                                            ';
                                            if(@$res['USR_Pic'] != "") {
                                                echo '
                                                <div class="radial-bar radial-bar radial-bar-warning" style="height:4rem;margin:0%;">
                                                    <img src="../'.$res['USR_Pic'].'" style="border-radius:50%;height:90%;width:50%;margin-top:8%;" alt=""/>
                                                </div>';
                                            } else {
                                                echo "<br/><span style='margin-left:12%;'>No-Image</span>";
                                            }
                                            echo'
                                                </td>
                                                <td>'.$res['USR_EmailID'].'</td>
                                            </tr>
                                            ';
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Modal Teacher Details -->
                <div class="modal fade" id="default-Modal_Teacher" tabindex="-1" role="dialog" style="margin-left:-13%;">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content" style="width:180%;padding:1.5%;">
                            <div class="modal-header">
                                <h4 class="modal-title" style="font-weight:bold;">Online Teacher Details</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <table class="table">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col" style="text-align:center;">Sr No.</th>
                                        <th scope="col" style="width:19%;">User ID</th>
                                        <th scope="col" style="width:21%;">User Name</th>
                                        <th scope="col">Profile Image</th>
                                        <th scope="col">Email ID</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $activeTchr_Qry = "SELECT USR_ID, USR_FirstName, USR_LastName, USR_Pic, USR_EmailID 
                                                           FROM Mtb_Users WHERE USR_Session != '' AND USR_ID LIKE 'T%'";
                                        $activeTchr_Data = mysqli_query($con,$activeTchr_Qry);
                                        $cnt = 0;
                                        while($res = mysqli_fetch_assoc($activeTchr_Data)) 
                                        {
                                            echo '
                                                <td style="text-align:center;">'.++$cnt.'</td>
                                            ';
                                            echo '
                                                </td>
                                                <td>'.$res['USR_ID'].'</td>
                                                <td>'.$res['USR_FirstName'].' '.$res['USR_LastName'].'</td>
                                                <td style="text-align:left;margin:0%;padding-top:0%;">
                                            ';
                                            if(@$res['USR_Pic'] != "") {
                                                echo '
                                                <div class="radial-bar radial-bar radial-bar-warning" style="height:4rem;margin:0%;">
                                                    <img src="../'.$res['USR_Pic'].'" style="border-radius:50%;height:90%;width:50%;margin-top:8%;" alt=""/>
                                                </div>';
                                            } else {
                                                echo "<br/><span style='margin-left:12%;'>No-Image</span>";
                                            }
                                            echo'
                                                </td>
                                                <td>'.$res['USR_EmailID'].'</td>
                                            </tr>
                                            ';
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>