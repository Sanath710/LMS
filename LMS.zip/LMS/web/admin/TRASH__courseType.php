<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {   
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
      include_once("../admin/adminNavbar.php");
    }
    else if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
      include_once("../HoD/teacherNavbar.php");
    }
    include("../COMMON_FILES/Connection.php");
    if($_GET['Status']==1)
    {
      echo 
      '<script src="../COMMON_FILES/sweetalert.min.js"></script>
       <script> 
        swal("Sorry", "You cannot assign a course for the same year in a programme twice!", "info");
      </script>
      ';
    }
    else if($_GET['Status']==2)
    {
        echo 
        '<script src="../COMMON_FILES/sweetalert.min.js"></script>
         <script> 
          swal("Success", "Course assigned successfully", "success");
        </script>
        ';
    }
    $query ="SELECT PID,PRGM_ID FROM Mtb_Programme";
    $data = mysqli_query($con,$query);
    $query1 ="SELECT CRSE_ID,CRSE_Name FROM Mtb_Courses";
    $data1 = mysqli_query($con,$query1);

?>
<html lang="en">

  <head>
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
    <link rel="stylesheet" type="text/css" href="../css/icofont.css">
    <script src="../COMMON_FILES/sweetalert.min.js"></script>
    <script>
      if (window.history.replaceState) {
        window.history.replaceState(null, null, "courseType.php");
      }
    </script>
  </head>

  <body>
    <div class="pcoded-content">
      <!-- Main Body Starts -->
      <div class="main-body">
        <div class="page-wrapper subBodyProgram">
          <!-- <div class="page-body"> -->
          <div class="card bodyStyling">
            <div class="card-header" style="margin-top:0.5%;">
              <h4>Assign Course Type</h4>
              <hr style="width:97.8%; margin-left:0%;" />
            </div>
            <div class="card-block">
              <div class="dt-responsive table-responsive tableView">
                <br />
                <!-- Add this ID to below table to achieve Searching functionality ------------------------id="base-style"--------------------->
                <table style="width:100%;" class="table table-striped table-bordered nowrap tableViewProgram">
                  <thead>
                    <tr>
                      <th style="width:11%;">Programme ID</th>
                      <th style="width:47%;">Course ID</th>
                      <th style="width:11%;">Type</th>
                      <th style="width:9%;">Semester</th>
                      <th style="width:10%;">Academic Year</th>
                      <th style="width:10%;text-align:center;padding-left:0.5%;">Assign</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <form action="courseType_DB.php" method="POST">
                        <td class="height_td">
                          <select name='selProgramID' style="width:100%;height:2rem;border:none;">
                            <?php
                              while($r = mysqli_fetch_assoc($data))
                              {
                                  echo "<option value='".$r['PID']."'>".$r['PRGM_ID']."</option>";
                              }
                            ?>
                          </select>
                        </td>
                        <td style="text-align:left;padding-left:2%;">
                          <!-- To give upper-most padding to avoid changing the flex property for this CELL -->
                          <span style="display:flex;margin-top:-2.4%;">&nbsp;</span>
                          <?php
                            $breakCnt = 0;
                            while($rse_Course = mysqli_fetch_assoc($data1))
                            {
                          ?>
                          <!-- COURSE NAME DISPLAYING ON CLICK ON COURSE ID -->
                          &nbsp;
                          <span style="cursor:pointer;"
                            onclick="viewCourseName('<?php echo $rse_Course['CRSE_Name']; ?>',this)">
                            <?php echo $rse_Course['CRSE_ID']; ?>
                          </span>
                          <input type='checkbox' value='<?php echo $rse_Course['CRSE_ID']; ?>' name='Courses[]'
                          class='Courses' />
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <script>
                            function viewCourseName(value, object) {
                              let crse_Name = value;
                              swal("Course Name : " + crse_Name);
                            }
                          </script>
                          <!-- COURSE NAME DISPLAYING BLOCK ENDS HERE-->
                          <?php
                            if($breakCnt==5)
                            {
                                echo "<br/>";
                            }
                            $breakCnt++;
                            }
                          ?>
                        </td>
                        <td>
                          <select name="selCRSE_TYPE" style="width:100%;height:2rem;border:none;">
                            <option value="0">Compulsory</option>
                            <option value="1">Elective</option>
                          </select>
                        </td>
                        <td>
                          <?php
                              $semRange = range(1, 10);
                            ?>
                          <select name="selSem" style="width:100%;height:2rem;border:none;">
                            <?php
                              foreach ($semRange as $sem) {
                                  echo '<option value="'.$sem.'">'.$sem.'</option>';
                              }
                            ?>
                          </select>
                        </td>
                        <td>
                          <?php
                            $yearRange = range(2021, 2070);
                          ?>
                          <select name="selYear" style="width:100%;height:2rem;border:none;">
                            <?php
                              foreach ($yearRange as $year) {
                                  echo '<option value="'.$year.'">'.$year.'</option>';
                              }
                            ?>
                          </select>
                        </td>
                        <td style="text-align:center;background-color:white;">
                          <button class="btn waves-effect waves-dark btn-success btn-outline-success btn-icon" style="padding-bottom:1%;" name="btnAssign" onclick="return dataCheck()">
                            <i class="icofont icofont-check-circled" style="padding-left:15%;"></i>
                          </button>
                          <!-- <input type="submit" class="PGSubmit" style="margin-left:3.5%;margin-top:2.5%;width:70%;font-size:17.5px;padding:0.5%;"
                            name="btnAssign" onclick="return dataCheck()" value="Assign" /> -->
                        </td>
                      </form>
                  </tbody>
                </table>
                <hr style="width:100%; margin-left:-0.4%;margin-top:1.4%" />
              </div>
            </div>
          </div>
          <!-- Lower body starts -->
          <div class="card bodyStyling">
            <div class="card-header" style="margin-top:0.5%;">
              <h4>Programme Batches</h4>
              <hr style="width:97.8%; margin-left:0%;" />
            </div>
            <br />
            <div class="page-body" style="display:flex;">
              <?php 
                $PRGMName_data = mysqli_query($con,$query);
                while($prgms = mysqli_fetch_assoc($PRGMName_data))
                {
              ?>
              <div class="card sale-card" style="margin-left:3%;margin-top:1%;padding-left:1.5%;padding-right:1.5%;padding-top:0.8%;">
                <div class="card-block text-center">
                  <?php
                    // For URL Parameter encoding
                    $tempStr1 = substr(str_shuffle(str_repeat("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
                    $tempStr2 = substr(str_shuffle(str_repeat("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
                    
                    echo '<a href="assignedBatches.php?pRgM='.$tempStr1.base64_encode($prgms['PRGM_ID']).$prgms['PID'].$tempStr2.'">
                            <i class="fa fa-folder-o" style="font-size:45px;margin-right:1.7%;">
                              <h6 style="display:flex;padding:5%;margin-left:-19%;margin-top:15%;">&nbsp;&nbsp;'.$prgms['PRGM_ID'].'</h6>
                            </i>
                          </a>';
                  ?>
                </div>
              </div>
              <?php
                }
              ?>
            </div>
          </div>
          <script>
            checkBoxs = document.getElementsByClassName("Courses");
            function dataCheck() 
            {
              flag = false;
              for (i = 0; i < checkBoxs.length; i++) 
              {
                if (checkBoxs[i].checked) {
                  flag = true;
                  break;
                }
              }
              if (flag) 
              {
                return true;
              }
              else 
              {
                swal({
                  title: "Oops.!!",
                  text: "You didn't selected a course.",
                  icon: "warning",
                });
                return false;
              }
            }
          </script>
  </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>