<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
  {   
    include_once("adminNavbar.php");
    include("../COMMON_FILES/Connection.php");
    $query ="SELECT * FROM Mtb_Programme";
    $data = mysqli_query($con,$query);
    echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
    if($_GET['s']==1)
    {
        echo'
            <script> 
                swal("Alert", "Please Enter Some Other Program Short Form.\nPreviously Entered Program Short Form was Already Taken.!", "info");
            </script>
        ';
        // $ERROR = "border:1px solid red;";
        // $ERROR_MSG = "<span style='color:red; font-size:14px;'>Please Enter Some Other Program ID.<br/>Previously Entered Program ID was Already Taken.!</span>";
    }
    elseif($_GET['s']==2)
    {
        echo'
            <script> 
                swal("Success", "Programme Added successfully", "success");
            </script>
        ';
    }
    else if($_GET['s']==3)
    {
        
        echo '
            <script> 
                swal("warning", "Invalid Data or No Data Received.!!", "warning");
            </script>
        ';
    }
    if($_GET['s']==4)
    {
        echo '
            <script> 
                swal("warning", "ERROR in Prepare Statement.!", "warning");
            </script>
        ';
    }
    if($_GET['s']==5)
    {
      echo '
          <script> 
              swal("Success", "Operation Performed Successfully.", "success");
          </script>
      ';
    }
    else if($_GET['s']==6)
    {
      echo '
          <script> 
              swal("Alert", "You Forgot to Enter Program Short Form", "warning");
          </script>
      ';
    }
    else if($_GET['s']==7)
    {
      echo '
          <script> 
              swal("Alert", "You Forgot to Enter Program Name", "warning");
          </script>
      ';
    }
    else if($_GET['s']==8)
    {
      echo '
          <script> 
              swal("Alert", "Some Error Occured While Inserting Data into Database", "warning");
          </script>
      ';
    }
    // else if($_GET['s']==9)
    // {
    //   echo '
    //       <script> 
    //           swal("Alert", "ou Forgot to Enter Program Duration", "warning");
    //       </script>
    //   ';
    // }
?>
<html lang="en">

  <head>
    <title>LMS | View Programs</title>
    <link rel="stylesheet" type="text/css" href="../css/datatables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
    <!-- For Cancel Icon -->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <!-- <style>table,td,table {border:none!important;}</style> -->
    <style>
      table tr,table,td 
      {
        border:none!important;
      }
      th
      {
         border-right:none!important;
      }
    </style>
    <script>
      if(window.history.replaceState) 
      {
        window.history.replaceState( null, null, "viewPrograms.php");
      }
    </script>
    <script src="../COMMON_FILES/sweetalert.min.js"></script>
  </head>

  <body>
    <div class="pcoded-content">
      <!-- <div class="page-header card">
      <div class="row align-items-end">
        <div class="col-lg-8">
          <div class="page-header-title">
            <i class="fa fa-book bg-c-blue" aria-hidden="true"></i>
            <div style="padding-top:1%;">
              <h5>View Programs</h5>
              <span></span>
            </div>
          </div>
        </div>
          <div class="col-lg-4">
            <div class="page-header-breadcrumb">
              <ul class=" breadcrumb breadcrumb-title">
                <li class="breadcrumb-item">
                  <a href=""><i class="feather icon-home"></i></a>
                </li>
                <li class="breadcrumb-item"><a href="#!">View Programs</a> </li>
              </ul>
            </div>
          </div>
      </div>
    </div> -->
    <!-- Main Body Starts -->
    <div>
    <div class="main-body">
      <div class="page-wrapper subBodyProgram">
        <div class="page-body">
          <div class="card bodyStyling">
            <div class="card-header" style="margin-top:0.5%;">
              <h4 style="font-weight:550;">Programme Details</h4><hr style="width:97.8%; margin-left:0%;"/>
            </div>
            <div class="card-block">
              <div class="dt-responsive table-responsive tableView" style="min-height:47.7rem;">
                <span style="color:red;font-weight:550;"><br/>TO EDIT A RECORD, CLICK ON IT 
                <!-- <span style="margin-left:60%;"> -->
                  <button style="margin-left:93.8%;height:2rem;padding-bottom:2.2%;padding-right:0.4%;padding-left:0.7%;display:flex;margin-top:-0.5%;" 
                    class="btn btn-primary waves-effect" data-toggle="modal" data-target="#default-Modal"> Add &nbsp;<i class='bx bx-plus-circle f-24'></i></button> 
                  <!-- <button class="btn waves-effect waves-dark btn-primary btn-outline-primary btn-icon"><i class="icofont icofont-user-alt-3"></i></button> -->
                  <!-- <button class="btn btn-inverse waves-effect waves-light" style>Inverse Button</button> -->
                </span>
                <table id="base-style" style="width:100%; cursor:pointer;" class="table table-striped table-bordered nowrap tableViewProgram">
                  <thead>
                    <tr>
                      <th style="width:7%;">Sr No</th>
                      <th style="width:15%;">Programme Short Form</th>
                      <th style="width:45%;">Programme Name</th>
                      <th style="width:15%;text-align:center;">Programme Code</th>
                      <th style="width:15%;text-align:center;">Programme Status</th>
                      <th id="hideTH" style="width:10%;text-align:center;padding-left:1.5%;">Edit</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                    $cnt=1;
                    while ($result = mysqli_fetch_assoc($data)) 
                    {
                  ?>  
                        <tr class="RowHeight" onclick="edit(this)">
                          <form action="updateProgram_DB.php" method="POST">
                            <input type="hidden" name="PID" value="<?php echo $result['PID'] ?>"/>
                            <td ><?php echo $cnt; ?></td>
                            <!-- ID -->
                            <td class="height_td"> <span class="dispID"><?php echo $result['PRGM_ID'];?></span>
                              <input type="text" class="editID UpdateCForm" name="ProgramID" autocomplete="off" id="ProgramID" readonly
                                onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123)"
                                pattern ="[A-Za-z\s]{3,}" title="Enter Only Aphabetical Characters Of Minimum Length Of Three" minLength="3" value="<?php echo $result['PRGM_ID'] ?>"/>
                            </td>
                            <!-- Name -->
                            <td style="text-align:left;" ><span class="dispName"><?php echo $result['PRGM_Name'];?></span>
                                <input type="text" name="ProgramName" id="ProgramName" autocomplete="off" class="editName UpdateCForm" minLength="1"
                                    onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || event.charCode == 32"
                                    pattern ="[A-Za-z\s]{1,}[A-Za-z]{0,}" title="Enter Only Aphabetical Characters" value="<?php echo $result['PRGM_Name'];?>" readonly />
                            </td>
                            <!-- Code -->
                            <td style="text-align:center;"><?php echo $result['PRGM_Code'];?></td>
                            <!-- Status -->
                            <td style="text-align:center;"> 
                                <?php
                                  if($result['PRGM_Status'] == "1") 
                                  {
                                    echo "<span class='dispStatus'>
                                    <label class='label label-md bg-success' style='font-size:15px;padding-left:11.5%;padding-right:12.5%;'>Active</label>
                                    </span>";
                                ?>
                              <span class="editStatus">
                                <?php
                                    echo "<input type='radio' name='ProgramStatus[]' value='1' checked/>&nbsp;Active &nbsp;
                                          <input type='radio' name='ProgramStatus[]' value='0' />&nbsp;Deactive";
                                  }
                                ?>
                              </span>
                                <?php
                                  if($result['PRGM_Status'] == "0")
                                  {
                                    echo "<span class='dispStatus'>
                                    <label class='label label-md bg-danger' style='font-size:15px;'>Deactive</label>
                                    </span>";
                                ?>
                              <span class="editStatus">
                                <?php
                                    echo "<input type='radio' name='ProgramStatus[]' value='1'/>&nbsp;Active &nbsp;
                                          <input type='radio' name='ProgramStatus[]' value='0' checked/>&nbsp;Deactive";
                                  }
                                ?>
                              </span>
                            </td>
                            <td style="text-align:center;" class="hideTD">
                                <span style="display:flex;margin-top:-1.55%;">&nbsp;
                                    <button type="submit" class="PGSubmit FormBtn Update" style="margin-left:1.2%;" onclick = "return inputChecker()" name="Operation" value="Update">
                                        &nbsp;&nbsp;<i class="fa fa-check-circle"></i>&nbsp; &nbsp;
                                    </button>
                                    &nbsp;
                                    <button type="submit" class="PGSubmit FormBtn Remove" name="Operation" onclick = "return inputChecker()" value="Remove">
                                        &nbsp; <i class="fa fa-trash"></i>&nbsp;&nbsp;
                                    </button>
                                    <i class='bx bx-x editIcon close' onclick="history.go(0);"></i>
                                </span>
                            </td>
                            <script>
                                    progID = document.getElementsByClassName("editID");
                                    progName = document.getElementsByClassName("editName");
                                    progStatus = document.getElementsByClassName("editStatus");
                                    
                                    dispID = document.getElementsByClassName("dispID");
                                    dispName = document.getElementsByClassName("dispName");
                                    dispStatus = document.getElementsByClassName("dispStatus");

                                    hideTD = document.getElementsByClassName("hideTD");
                                    hideTH = document.getElementById("hideTH").style.display = "none";

                                    UpdateBtn = document.getElementsByClassName("Update");
                                    RemoveBtn = document.getElementsByClassName("Remove");
                                    editClose = document.getElementsByClassName("close");
                                    // editIcon = document.getElementsByClassName("editBtn");

                                    for(i = 0 ; i < UpdateBtn.length; i++)
                                    {
                                        UpdateBtn[i].style.display = "none";
                                        RemoveBtn[i].style.display = "none";
                                        editClose[i].style.display = "none";

                                        progID[i].style.display = "none";
                                        progName[i].style.display = "none";
                                        progStatus[i].style.display = "none";

                                        hideTD[i].style.display = "none";
                                    }
                                    function edit(id) 
                                    { 
                                        UpdateBtn[id.rowIndex-1].removeAttribute("style");
                                        RemoveBtn[id.rowIndex-1].removeAttribute("style");
                                        editClose[id.rowIndex-1].removeAttribute("style");

                                        progID[id.rowIndex-1].removeAttribute("style");
                                        progName[id.rowIndex-1].removeAttribute("style");
                                        progStatus[id.rowIndex-1].removeAttribute("style");

                                        hideTD[id.rowIndex-1].removeAttribute("style");

                                        dispID[id.rowIndex-1].style.display = "none";
                                        dispName[id.rowIndex-1].style.display = "none";
                                        dispStatus[id.rowIndex-1].style.display = "none";

                                        document.getElementById("hideTH").removeAttribute("style");

                                        progID[id.rowIndex-1].removeAttribute("readonly");
                                        progName[id.rowIndex-1].removeAttribute("readonly");

                                        styleAttrID = document.createAttribute("style");
                                        styleAttrID.value = "border: 1px solid rgba(81, 203, 238, 1);  padding-left:1%; margin-top:-1.8%; background-color: white; border-radius:5px; height:32px;";

                                        styleAttrProgName = document.createAttribute("style");
                                        styleAttrProgName.value = "border: 1px solid rgba(81, 203, 238, 1);  padding-left:1%; margin-top:-0.4%; background-color: white; border-radius:5px; height:32px;";

                                        progID[id.rowIndex-1].setAttributeNode(styleAttrID);
                                        progName[id.rowIndex-1].setAttributeNode(styleAttrProgName);
                                    }
                                    function inputChecker()
                                    {
                                      if(document.getElementById("ProgramID").value == '')
                                      {
                                          swal("Alert", "Please Enter Programme Short Form", "warning");
                                          return false;
                                      }
                                      if(document.getElementById("ProgramName").value == '')
                                      {
                                          swal("Alert", "Please Enter Programme Name", "warning");
                                          return false;
                                      }
                                    }
                            </script>
                          </form>
                        </tr>
                       <?php
                        $cnt++;
                        }
                      ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- New Programme -->
        <div class="card-block">
          <ul>
            <li>
              <div class="modal fade" id="default-Modal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                  <div class="modal-content" style="width:123%;">
                    <div class="modal-header">
                        <h4 class="modal-title" style="font-weight:bold;">New Programme</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                  <form id="main" method="POST" action="newProgram_DB.php">
                    <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:2%;font-weight:550;">Programme Short Form  </label>
                            <div>
                                <input type="text" class="form-control frmTxt" style='width:40%;font-size:17px;padding-left:4%;' name="ProgramID" autocomplete="off" id="PRGMID" required onkeyup="valueCheck()"
                                    pattern ="[A-Za-z]{3}[A-Za-z\s]{0,}" title="Enter only aphabetical characters of minimum length of three & maximum length of four" minLength="3" maxlength ="4" 
                                    onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123)"
                                    placeholder="Enter ID"/>
                                <!-- <span id="messages"><?php //echo $ERROR_MSG; ?></span> -->
                            </div>
                        </div>
                        <!-- <br/> -->
                        <div class="form-group row"style="margin-top:-0.5%;">
                            <label class="col-form-label frmTxt" style="margin-left:4%;margin-right:1.5%;font-weight:550;">Programme Name  </label>
                            <!-- <br/><br/> -->
                                <input type="text" class="form-control frmTxt" name="ProgramName" autocomplete="off" id="PRGMName" required onkeyup="valueCheck()"
                                    onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || event.charCode == 32"
                                    style="margin-left:7.8%;width:58%;margin-right:2%;font-size:17px;padding-left:1.3%;" pattern ="[A-Za-z]{3,}[A-Za-z\s]{0,}" title="Enter only aphabetical characters"  placeholder="Enter Programme Name "/>
                        </div>
                    </div>
                    <!-- New Programme Buttons -->
                    <div class="modal-footer">
                        <input type="reset" class="btn btn-default waves-effect" data-dismiss="modal" value="Cancel"/>
                        <input type="submit" class="btn btn-primary waves-effect waves-light" name="btnSubmit" value="Add" onclick="return inputCheck()"/>
                    </div>
                </form>
                <script>
                  function inputCheck() 
                  {
                      if(document.getElementById("PRGMID").value == '')
                      {
                          swal("Alert", "You Forgot to Enter Program Short Form", "warning");
                          return false;
                      }
                      else if(document.getElementById("PRGMName").value == '')
                      {
                          swal("Alert", "You Forgot to Enter Program Name", "warning");
                          return false;
                      }
                      else if(document.getElementById("PRGMDUR").value == '')
                      {
                          swal("Alert", "You Forgot to Enter Program Duration", "warning");
                          return false;
                      }
                      return true;
                  }
                  if (window.history.replaceState) 
                  {
                      window.history.replaceState( null, null, "viewPrograms.php");
                  }
                </script>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <script src="../js/jquery.datatables.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.buttons.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.bootstrap4.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.responsive.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/data-table-custom.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="06ff493bca0b4366a261bcf1-|49" defer=""></script>
  </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>