<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
        include("adminNavbar.php");
        include_once("../COMMON_FILES/Connection.php");
        echo '<script src="../COMMON_FILES/sweetalert.min.js"></script>';
        if($_GET['status']==1)
        {
            echo '
                <script> 
                    swal("Success", "New user '.$_GET['id'].' enrolled successfully.", "success");
                </script>
            ';
        }
        else if($_GET['status']==2)
        {
            echo '
                <script> 
                    swal("Alert", "Something went wrong.\nUser enrolling failed.", "warning");
                </script>
            ';
        }
        else if($_GET['status']==3)
        {
            echo '
                <script> 
                    swal("Oops.!", "Please Select a Programme for Student.", "info");
                </script>
            ';
        }
        else if($_GET['status']==4)
        {
            echo '
                <script> 
                    swal("Oops.!", "Please upload a valid csv file.", "info");
                </script>
            ';
        }
        else if($_GET['status']==5)
        {
            echo '
                <script> 
                    swal("Alert", "Null Data received. Enrolling failed.", "warning");
                </script>
            ';
        }
        else if($_GET['status']==6)
        {
            echo '
                <script> 
                    swal("Alert", "Some error occured.\nError in Prepare Statement.", "info");
                </script>
            ';
        }
        else if($_GET['status']==7)
        {
            echo '
                <script> 
                    swal("Alert", "File upload failed.\nPlease try again.", "warning");
                </script>
            ';
        }
        else if($_GET['status']==8)
        {
            echo '
                <script> 
                    swal("Success", "'.$_GET['succ'].' New users enrolled successfully.\n'.$_GET['err'].' Record insertion failed (Incorrect Data Format).\n'.$_GET['duplicate'].' Duplicate Email ID/Aadhar No. founded in already registered users & record is neglected.", "success");
                </script>
            ';
        }
        $qry_PRGMID = "SELECT PRGM_ID,LPAD(PRGM_Code,3,0) as code FROM Mtb_Programme";
?>
<html>
<head>
    <title>LMS | Enroll User</title>
    <!-- the fileinput styling CSS file -->
    <link href="../css/fileinput.min.css" rel="stylesheet" type="text/css" />
    <!-- the jQuery Library -->
    <script src="../js/jquery.min.js"></script>
    <!-- the main fileinput script JS file -->
    <script src="../js/fileinput.min.js"></script>
  
    <style> 
        label {
            font-weight:550;
        }
        .input-group .custom-file, .input-group .custom-select, .input-group .form-control {
            flex : none!important;
            width:30%!important;
            margin-left:3%!important;
        }
        table, td, th{
            border: 1px solid black;
        }
        table {
            margin-left:3%;
            width:80%!important;
        }
        td,th {
            padding:2%;
        }
    </style>
</head>

<body>
    <div class="pcoded-content">
        <!-- Main Body Starts -->
        <div class="main-body">
            <div class="page-wrapper">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card mainBody bodyStyling" style="min-height:54.55rem;padding-bottom:0%;margin-bottom:-2%">
                            <div class="card-block usrFormBody">
                                <h4 style=" margin-left:2%;font-weight:bold;">User Registration</h4>
                                <hr style="width:96.8%;"/>
                                <br/>
                                <!-- Enroll Choice (File/Manual Entry) -->
                                <div class="form-group row has-success" style="margin-left:2%;" id="options">
                                    <label class="col-sm-2">Select one of following : </label>
                                    <div class="col-sm-10" style="margin-left:-2%;">
                                        <div class="form-radio">
                                            <div class="radio radiofill radio-primary radio-inline">
                                                <label>
                                                    <input type="radio" name="rdbtnEntryChoice" onclick="selection('1');" data-bv-field="member">
                                                    <i class="helper" style="margin-top:2%;"></i>Import from CSV File
                                                </label>
                                            </div>
                                            <div class="radio radiofill radio-primary radio-inline">
                                                <label>
                                                    <input type="radio" name="rdbtnEntryChoice" onclick="selection('0');" data-bv-field="member">
                                                    <i class="helper" style="margin-top:2%;"></i>Manual Data Entry
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- File Upload Container -->
                                <span id="fileUpload-container" style="display:none;">
                                    <form id="main" method="POST" action="csvUserEnroll_DB.php" enctype="Multipart/form-data"> <!--  action="csvUserEnroll_DB.php" -->
                                        <div style="margin-bottom:1.5%;">
                                            <div style="display:flex;margin-bottom:1.5%;">
                                                <label class="col-sm-1 col-form-label frmTxt" style="margin-left:2%;">Enroll As &nbsp;: </label>
                                                <div class="col-sm-3" style="font-size:17px;">
                                                    <div class="form-check form-check-inline" style="margin-left:-6%;margin-top:2.5%;">
                                                        <label class="form-check-label">
                                                            &nbsp;HoD <input type="radio" name="userRole" onclick="roleCheck('H');" value="HoD" />
                                                        </label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <label class="form-check-label">
                                                            Teacher <input type="radio" name="userRole" onclick="roleCheck('T');" value="Teacher" />
                                                        </label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <label class="form-check-label">
                                                            Student <input type="radio" name="userRole" onclick="roleCheck('S');" value="Student" required/>
                                                        </label>
                                                    </div>
                                                </div>
                                                <script>
                                                    function roleCheck(role) {
                                                        if(role == "H" || role == "T") {
                                                            document.getElementById("selProg").style.display="none";
                                                            document.getElementById("selProg1").style.display="none";
                                                            document.getElementById("labelprgm").style.display="none";
                                                            document.getElementById("labelprgm1").style.display="none";

                                                        }
                                                        else if(role == "S") {
                                                            document.getElementById("selProg").style.display="";
                                                            document.getElementById("selProg1").style.display="";
                                                            document.getElementById("labelprgm").style.display="";
                                                            document.getElementById("labelprgm1").style.display="";
                                                        }
                                                    }
                                                </script>
                                            </div>
                                            <div style="margin-left:3%; display:flex;">
                                                <label class="col-l-1 col-form-label frmTxt" id="labelprgm">Select Programme</label>
                                                <div style="margin-left:1.5%;margin-top:0.3%;">
                                                    <select name="prgmSelect" id="selProg" style='width:130%;height:2rem;cursor:pointer;' required>
                                                        <?php
                                                            $data  =  mysqli_query($con,$qry_PRGMID); 
                                                            while($result = mysqli_fetch_assoc($data))
                                                            {
                                                                echo "<option value='".$result['code']."'>".$result['PRGM_ID']."</option>";
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <input id="input" name="csvFileUpload" type="file" class="file" data-show-preview="false" accept=".csv" required onchange='fileCheck(this)'>
                                        <script>
                                            let myRegex = new RegExp("(.*?)\.(csv)$");
                                            function fileCheck(e) {
                                                if (!(myRegex.test(e.value.toLowerCase()))) {
                                                    e.value = '';
                                                    document.getElementById("lblCSV").style.display="none";
                                                    document.getElementById("base-style").style.display="none";
                                                    swal("Alert", "Invalid File.\nUpload only CSV file.", "warning");
                                                } else {
                                                    let fileUpload = document.getElementById("input");
                                                    if (typeof (FileReader) != "undefined") {
                                                        let reader = new FileReader();
                                                        reader.onload = function (e) {
                                                            let table = document.getElementById('base-style');
                                                            let rows = e.target.result.split("\n");
                                                            for (let i = 1; i < rows.length; i++) {
                                                                let cells = rows[i].split(",");
                                                                if (cells.length > 1) {
                                                                    let row = table.insertRow(-1);
                                                                    for (let j = 0; j < cells.length; j++) {
                                                                        let cell = row.insertCell(-1);
                                                                        cell.innerHTML = cells[j];
                                                                    }
                                                                }
                                                            }
                                                            let dvCSV = document.getElementById("dataCSV");
                                                            dvCSV.innerHTML = "";
                                                            dvCSV.appendChild(table);
                                                        }
                                                        reader.readAsText(fileUpload.files[0]);
                                                    }
                                                    document.getElementById("lblCSV").style.display="";
                                                    document.getElementById("base-style").style.display="";
                                                }
                                            }
                                        </script>
                                    </form>
                                    <p style="font-size:16px;margin-left:3%;border:1px solid black;padding:1%;width:50%;;margin-top:2.5%;">
                                        <b style="font-weight:550;">NOTE : </b>
                                        <br/><br/>
                                        <b style="font-weight:550;">Data Format/Sequence : </b><br/> First Name, &nbsp;Last Name, &nbsp;Email ID, &nbsp;Contact No., &nbsp;Aadhar No, &nbsp;Gender.
                                        <br/><br/>
                                        <b style="font-weight:550;">Sample Data : </b><br/><br/>
                                        <b style="font-weight:550;">FirstName &nbsp;=&nbsp; </b>Sanath &nbsp;&nbsp;(Only alphabets),<br/><b style="font-weight:550;">LastName &nbsp;=&nbsp;</b> Ezhuthachan &nbsp;&nbsp;(Only alphabets), &nbsp;<br/>
                                        <b style="font-weight:550;">Email_ID &nbsp;&nbsp;&nbsp; =&nbsp;</b> sd@gmail.com,<br/><b style="font-weight:550;">ContactNo =&nbsp;</b> 9876543210 &nbsp;&nbsp;(10 digits), <br/>
                                        <b style="font-weight:550;">AadharNo &nbsp;=&nbsp;</b> 330655371532 &nbsp;&nbsp;(Only 12 digits),<br/><b style="font-weight:550;">Gender &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;</b> (Male or M or m).
                                        <br/><br/>
                                        <!-- <b style="font-weight:550;">CSV File Size : </b> File size must be <b style="font-weight:550;">Greater than 1 KB & lesser than 2 MB.</b> -->
                                        <!-- <br/><br/> -->
                                        <b style="font-weight:550;color:red;">If any of above mentioned requirement is not matched, then corresponding record will be neglected while enrolling.</b>
                                    </p>
                                </span>
                                <br/>
                                <h5 style="font-weight:bold;margin-left:3%;display:none;margin-top:-0.5%;" id="lblCSV">Please Verify Records in CSV File</h5>
                                <!-- Load CSV File Data -->
                                <div style="margin-top:1.5%;">
                                    <table class="table table-striped table-bordered wrap" id="base-style" style="display:none;">
                                        <tr style="font-weight:550;background-color:white;color:black;">
                                            <td>First Name</td>
                                            <td>Last Name</td>
                                            <td>Email ID</td>
                                            <td>Contact No</td>
                                            <td>Aadhar No</td>
                                            <td>Gender</td>
                                        </tr>
                                        <tbody id="dataCSV">
                                            
                                        </tbody>
                                    </table>
                                </div>
                                <br/>
                                    <!-- Manual User Data Entry-->
                                    <span id="manualEntry-container" style="display:none;">
                                    <form id="main" method="POST" action="enrollUser_DB.php">
                                        <div style="margin-bottom:2.5%;margin-top:-4.5%;">
                                            <div style="display:flex;">
                                                <label class="col-sm-1 col-form-label frmTxt" style="margin-left:2%;">Enroll As &nbsp;: </label>
                                                <div class="col-sm-3" style="font-size:17px;margin-bottom:0.6%;">
                                                    <div class="form-check form-check-inline" style="margin-left:-6%;margin-top:2.5%;">
                                                        <label class="form-check-label">
                                                            &nbsp;HoD <input type="radio" name="userRole"  onclick="roleCheck('H');" value="HoD" />
                                                        </label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <label class="form-check-label">
                                                            Teacher <input type="radio" name="userRole"  onclick="roleCheck('T');" value="Teacher"/>
                                                        </label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <label class="form-check-label">
                                                            Student <input type="radio" name="userRole" value="Student"  onclick="roleCheck('S');" required/>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div style="margin-left:7.1%; display:flex;">
                                                    <span id="labelprgm1">
                                                        <label class="col-l-1 col-form-label frmTxt" style="margin-top:-0.1%;">Select Programme</label>
                                                        <div style="margin-left:1%;margin-bottom:1.5%;margin-top:0.3%;">
                                                            <select name="prgmSelect" id="selProg1" style='width:100%;height:2rem;cursor:pointer;' required>
                                                                <?php
                                                                    $data  =  mysqli_query($con,$qry_PRGMID); 
                                                                    while($result = mysqli_fetch_assoc($data))
                                                                    {
                                                                        echo "<option value='".$result['PRGM_ID']."'>".$result['PRGM_ID']."</option>";
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row m-t-1">
                                            <div style="margin-left:-0.3%;">&nbsp;</div>
                                            <label class="col-md-1 col-form-label frmTxt" style="margin-left:3%;">First Name </label>
                                            <div class="col-sm-3">
                                                <input type="text" class="form-control frmTxt" name="txtFirstName" autocomplete="off" id="txtFirstName"
                                                    onkeyup="valueCheck()" onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123)" 
                                                    pattern="[A-Za-z]{3,}" title="Enter only aphabetical characters Of minimum length Of three"
                                                    minLength="3" placeholder="Enter First Name " />
                                            </div>
                                            <div style="margin-left:5%;">&nbsp;</div>
                                            <label class="col-md-1 col-form-label frmTxt">Last Name </label>
                                            <div class="col-sm-3">
                                                <input type="text" class="form-control frmTxt" name="txtLastName" autocomplete="off" id="txtLastName" required onkeyup="valueCheck()"
                                                    onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123)"
                                                    pattern="[A-Za-z]{3,}" title="Enter only aphabetical characters Of minimum length Of three" placeholder="Enter Last Name " />
                                            </div>
                                        </div>
                                        <br />
                                        <div class="form-group row">
                                            <div style="margin-left:2.7%;">&nbsp;</div>
                                            <label class="col-sm-1 col-form-label frmTxt">Email ID </label>
                                            <div class="col-sm-3">
                                                <input type="email" class="form-control frmTxt" name="txtEmail" autocomplete="off" id="txtEmailID" required onkeyup="valueCheck()"
                                                    pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$" title="Enter Vaild Email Address" placeholder="Enter Email Address " />
                                            </div>
                                            <div style="margin-left:5%;">&nbsp;</div>
                                            <label class="col-sm-1 col-form-label frmTxt" style="margin-top:-0.5%;padding-top:1%;">Gender </label>
                                            <div class="col-sm-3" style="font-size:17px;margin-left:-0.3%;padding-top:0.6%;">
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        &nbsp;Male <input type="radio" name="gender" value="M" checked/>
                                                    </label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        Female <input type="radio" name="gender" value="F" />
                                                    </label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <label class="form-check-label">
                                                        Other <input type="radio" name="gender" value="O" />
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <br />
                                        <div class="row">
                                            <div style="margin-left:3.7%;">&nbsp;</div>
                                            <label class="col-l-1 col-form-label frmTxt">Contact No</label>
                                            <div class="col-sm-3" style="margin-left:0.6%;">
                                                <input type="text" class="form-control frmTxt mob_no" name="txtContactNo" autocomplete="off" id="txtContactNo" required onkeyup="valueCheck()"
                                                    onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))"
                                                    style="margin-left:3.5%;"
                                                    pattern="[0-9]{10}" title="Enter Valid 10 Digit Contact No" placeholder="Enter Contact No" minLength="10" maxLength="10" />
                                            </div>
                                            <div style="margin-left:6.3%;">&nbsp;</div>
                                            <label class="col-l-1 col-form-label frmTxt">Aadhar No </label>
                                            <div class="col-sm-3" style="margin-left:1.6%;">
                                                <input type="text" class="form-control frmTxt" name="txtAadharNo" autocomplete="off" id="AadharNo" required onkeyup="valueCheck()"
                                                    onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))"
                                                    pattern="[0-9]{12}"  placeholder="Enter Aadhar Card No" minLength="12" maxLength="12" title="Enter Valid 12 Digit Aadhar No" />
                                            </div>
                                        </div>
                                        <br/>
                                        <div class="form-group row" style="margin-top:0.5%;">
                                        
                                            <!-- <div style="margin-left:5%;">&nbsp;</div>
                                            <label class="col-sm-1 col-form-label frmTxt">Upload Pic </label>
                                            <div class="col-sm-3">
                                                <input type="file" class="form-control frmTxt file_UPLD" name="UpldFile" autocomplete="off" id="FileUpload"/>
                                            </div> -->
                                        </div>
                                        <div class="form-group row">
                                            <div style="margin-left:2%;">&nbsp;</div>
                                            <div class="col-sm-4">
                                                <input type="submit" class="btn btn-primary m-b-1 btnEffect btnSubmit" id="Submit" style="width:22%;" onclick="return inputChecker()" /> &nbsp;
                                                <input type="reset" class="btn btn-primary m-b-0 btnEffect btnSubmit" style="width:18%; " onmouseout="valueCheck()" />
                                                <br/>
                                            </div>
                                        </div>
                                    </form>
                                </span>
                                <!--  -->
                                <!-- Script for user choice selection for enrolling user (CSV / Manual Data Entry) -->
                                <script>
                                    function selection(data) {
                                        document.getElementById("options").style.display="none";
                                        if(data == "1") {
                                            document.getElementById("fileUpload-container").style.display="";
                                            document.getElementById("manualEntry-container").style.display="none";
                                        } else if (data == "0") {
                                            document.getElementById("fileUpload-container").style.display="none";
                                            document.getElementById("manualEntry-container").style.display="";
                                        }
                                    }
                                </script>
                                <!-- Ends here -->
                                <script>
                                        let firstName = document.getElementById("txtFirstName").value;
                                        let lastName = document.getElementById("txtLastName").value;
                                        let emailID = document.getElementById("txtEmailID").value;
                                        let contactNo = document.getElementById("txtContactNo").value;
                                        let aadhaarNo = document.getElementById("AadharNo").value;

                                        if(firstName == '' || LastName == '' || emailID == '' || contactNo == '' || aadhaarNo == '') {
                                            var x = document.querySelector("#Submit");
                                            x.style.display = "none";
                                        }
                                        function valueCheck() {

                                            let firstName = document.getElementById("txtFirstName").value;
                                            let lastName = document.getElementById("txtLastName").value;
                                            let emailID = document.getElementById("txtEmailID").value;
                                            let contactNo = document.getElementById("txtContactNo").value;
                                            let aadhaarNo = document.getElementById("AadharNo").value;

                                            if(firstName.length >= 3 && lastName.length >= 3 && emailID != ''  &&  contactNo.length == 10 && aadhaarNo.length == 12) {
                                                x.removeAttribute("style");
                                            } else {
                                                styleAttr = document.createAttribute("style");
                                                styleAttr.value = "display:none";
                                                x.setAttributeNode(styleAttr);
                                            }
                                            // Aadhar Validation (Indication)
                                            if(aadhaarNo.length < 12) {
                                                document.getElementById("AadharNo").style.color="red";
                                            } else {
                                                document.getElementById("AadharNo").style.color="black";
                                            }
                                            // Contact No. validation (Indication)
                                            if(contactNo.length < 10) {
                                                document.getElementById("txtContactNo").style.color="red";
                                            } else {
                                                document.getElementById("txtContactNo").style.color="black";
                                            }
                                            // First Name validation (Indication)
                                            if(firstName.length < 3) {
                                                document.getElementById("txtFirstName").style.color="red";
                                            } else {
                                                document.getElementById("txtFirstName").style.color="black";
                                            }
                                            // Last Name validation (Indication)
                                            if(lastName.length < 3) {
                                                document.getElementById("txtLastName").style.color="red";
                                            } else {
                                                document.getElementById("txtLastName").style.color="black";
                                            }
                                        }
                                        function inputChecker() 
                                        {
                                            if(document.getElementById("txtFirstName").value == '')
                                            {
                                                swal("Alert", "Enter First Name", "warning");
                                                return false;
                                            }
                                            if(document.getElementById("txtLastName").value == '')
                                            {
                                                swal("Alert", "Enter Last Name", "warning");
                                                return false;
                                            }
                                            if (document.getElementById("txtEmailID").value == '')
                                            {
                                                swal("Alert", "Enter Email ID", "warning");
                                                return false;
                                            }
                                            if (document.getElementById("txtContactNo").value == '')
                                            {
                                                swal("Alert", "Enter Contact No", "warning");
                                                return false;
                                            }
                                            if(document.getElementById("txtContactNo").value == '0000000000')
                                            {
                                                swal("Alert", "Enter Correct Contact Number Other than only 0", "warning");
                                                return false;
                                            }
                                            if(document.getElementById("txtAadharNo").value == '0000000000')
                                            {
                                                swal("Alert", "Enter Correct Aadhar Number Other than only 0", "warning");
                                                return false;
                                            }
                                            if (document.getElementById("txtAadharNo").value == '')
                                            {
                                                swal("Alert", "Enter Aadhar No", "warning");
                                                return false;
                                            } 
                                            if(document.getElementById("selProg").value == "None") {
                                                return false;
                                            }
                                            return true;
                                        }
                                        if (window.history.replaceState) 
                                        {
                                            window.history.replaceState( null, null, "enrollUser.php");
                                        }
                                    </script>
                                <?php
                                    if(isset($_POST['submit'])) {

                                        echo '<script>alert("hi");</script>';

                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>