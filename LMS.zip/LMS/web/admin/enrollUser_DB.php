<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
        $FirstName = $_POST['txtFirstName'];
        $LastName = $_POST['txtLastName'];
        $Email = $_POST['txtEmail'];
        $ContactNo = $_POST['txtContactNo'];
        $Role = $_POST['userRole'];
        $Gender = $_POST['gender'];
        $AadharNo = $_POST['txtAadharNo'];
        $Programme = $_POST['prgmSelect'];
        $newID = null;

        # For generating a random password
        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890~!@#$%^&*()_+}{:"<>?|';
        $password = array(); 
        $alphaLength = strlen($alphabet) - 1; 
        for ($i = 0; $i < 12; $i++) 
        {
            $n = rand(0, $alphaLength);
            $password[] = $alphabet[$n];
        }
        $pass = implode($password);

        # For generating Student ID 
        function Stud_ID_Creation($con)
        {
            $d = date("Y");
            $prgmcode_QRY = "SELECT LPAD((SELECT PRGM_Code FROM Mtb_Programme WHERE PRGM_ID = '".$_POST['prgmSelect']."'),3,0) as code";
            $prgmcode_Data = mysqli_query($con,$prgmcode_QRY);
            $prgmcode = mysqli_fetch_assoc($prgmcode_Data);
            $prgmcode = $prgmcode['code'];
           
            $d.=$prgmcode;
            $QRY_uID = "SELECT USR_ID FROM Mtb_Users WHERE USR_Role = 'Student' and substring(USR_ID,2,7)='$d' order by USR_ID desc Limit 1";
            $data = mysqli_query($con,$QRY_uID);
            @$UID = substr(implode(mysqli_fetch_assoc($data)),1,11);
            $temp = (int)substr($UID,0,10)+1;
            $newID = "S".$temp;
            # If there is no previous record available then generating new record.
            if(!$UID) 
            {
                $newID = "S".$d."001";
            }
           
            else if($_POST['prgmSelect']=="None")
            {
                header("refresh:0;url=enrollUser.php?status=3");    # Status = 3 for programme not selected warning.
                exit();
            }
            return $newID;
        }

        # For generating HoD/Teacher ID 
        function TCHR_ID_Creation($con,$role)
        {
            $d = date("Y");
            $QRY_uID = "SELECT USR_ID FROM Mtb_Users WHERE USR_Role = '$role' and substring(USR_ID,2,4)='$d' order by USR_ID desc Limit 1";
            $data = mysqli_query($con,$QRY_uID);
            @$UID = substr(implode(mysqli_fetch_assoc($data)),1,10);
            $temp = (int)substr($UID,0,10)+1;
            # For T (Teacher) / H (HoD) => (Indication first charcter at index 0)
            $char_0_Role  = substr($role,0,1);
            $newID = $char_0_Role.$temp;
            if(!$UID)
            {
                $newID = $char_0_Role.$d."00001";
            }
            return $newID;
        }
        
        if(!empty($FirstName) && !empty($LastName) && !empty($Email) && !empty($ContactNo) && !empty($Role) && !empty($Gender) && !empty($AadharNo))
        {
            include_once ("../COMMON_FILES/Connection.php");

            if($Role == "HoD")
            {
                $newID = TCHR_ID_Creation($con,"HoD");
            }
            else if($Role == "Student")
            {
                $newID = Stud_ID_Creation($con);
            }
            else if($Role == "Teacher")
            {
                $newID = TCHR_ID_Creation($con,"Teacher");
            }
            # Master Query
            $sql = "INSERT INTO Mtb_Users (USR_ID,USR_FirstName, USR_LastName, USR_EmailID,USR_ContactNo,USR_AadharNo,USR_Gender,USR_Role,USR_Password) VALUES ('$newID','$FirstName','$LastName','$Email','$ContactNo','$AadharNo','$Gender','$Role','$pass')";
        }
        else
        {
            header("refresh:0;url=enrollUser.php?status=5");    # Null Data Received.
        }
        if(!mysqli_query($con,$sql))
        {
            header("refresh:0;url=enrollUser.php?status=2");    # Something went wrong. Enrolling failed.
            echo "master error";
        }
        else if((substr($newID,0,1) != "H") && (substr($newID,0,1) != "T") && (substr($newID,0,1) != "A"))
        {
            # Transaction Query
            $insert_QRY = "INSERT INTO Tb_CourseUsers(CRSE_USR_UID,CRSE_USR_PID,CRSE_USR_CourseID,CRSE_USR_Year,CRSE_USR_Sem,CRSE_USR_Status) 
                           Values(?,?,?,?,?,?)";
            $stmt = mysqli_stmt_init($con);
            if(!mysqli_stmt_prepare($stmt,$insert_QRY))
            {
                header("refresh:0;url=enrollUser.php?status=6");    # Error in Prepare Statement for transaction table
            } 
            else 
            {
                # Preparing Data Set Required.
                $getUID = "SELECT UID FROM Mtb_Users WHERE USR_ID = '$newID'";
                $UID_Data = mysqli_query($con,$getUID);
                $newUID = mysqli_fetch_assoc($UID_Data);
                $newUID = $newUID["UID"];
                #
                $getPID = "SELECT PID, PRGM_Code FROM Mtb_Programme WHERE PRGM_ID = '$Programme'";
                $getPIDData = mysqli_query($con,$getPID);
                $PID = mysqli_fetch_assoc($getPIDData);
                $PCode = $PID['PRGM_Code'];
                $PID = $PID['PID'];
                #
                $getCourse = "SELECT CRSE_ID FROM Mtb_Courses WHERE substring(CRSE_ID,6,1)=1 AND substring(CRSE_ID,1,3) = RPAD($PCode,3,0)";
                $getCourseData = mysqli_query($con,$getCourse);
                $year = date("Y");
                $userStatus = 1;
                $sem = 1;
                #
                $flag = false;

                while($course = mysqli_fetch_assoc($getCourseData))
                {
                    $course = $course['CRSE_ID'];
                    mysqli_stmt_bind_param($stmt,"iiiiii",$newUID,$PID,$course,$year,$sem,$userStatus);
                    if(!mysqli_stmt_execute($stmt))
                    {
                        # Deleting record from master table if even a single course insertion fails.
                        $deleteQRY = "DELETE FROM Mtb_Users WHERE USR_ID = '$newID'";
                        mysqli_query($con,$deleteQRY);
                        $flag = false;
                        header("refresh:0;url=enrollUser.php?status=2");    # Something went wrong. Enrolling failed.
                    }
                    else 
                    {
                        $flag = true;
                    }
                }
                if($flag == true)
                {
                    header("refresh:0;url=enrollUser.php?status=1&id=$newID");    # Successfully inserted. New last inserted USR ID.
                }
                else
                {
                    header("refresh:0;url=enrollUser.php?status=2");    # Something went wrong. Enrolling failed.
                }
            }
        } else {
            header("refresh:0;url=enrollUser.php?status=1&id=$newID");    # Successfully inserted. New last inserted USR ID.
        }
    }
    else
    {
        echo "You Don't have previleges to access this page.<br/>";
        header("refresh:2;url=../COMMON_FILES/logout.php");
    }
    //$to_email = "kdsd2000@gmail.com";
//     $subject = "LMS Registration";
//     $body = 
// "Hello User,
// Thank You for registering with LMS.
// Your Username and Password for Learning Management System : 
// Username : $newID
// Password : $pass";

//     $headers = "From:kdsd2000@gmail.com";

//     if (mail($Email, $subject, $body, $headers)) {
//         echo "Email successfully sent to $Email";
//     } else {
//         echo "Email sending failed...";
//     }
?>