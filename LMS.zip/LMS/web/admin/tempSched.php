<?php
    session_start();
    // error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
        $master_sem_courses = array(
            "Sem - 1" => 
                array(
                    "A" => array("CS1001 - HHD","CS1002 - MAG","CS1003 - PMK","CS1004 - AMN"),
                    "B" => array("CS1001 - KPP","CS1002 - JDC","CS1003 - SAM","CS1004 - RMP")
                ),
            "Sem - 2" => 
                array(
                    "A" => array("CS2001 - RMP","CS2002 - SHP","CS2003 - SDL","CS2004 - MAG","CS1005 - HHD"),
                    "B" => array("CS2001 - JAP","CS2002 - DLB","CS2003 - AMN","CS2004 - NRE","CS1005 - PMK")
                ),
            "Sem - 3" => 
                array(
                    "A" => array("CS3001 - NRE","CS3002 - DLB","CS3003 - MAG","CS3004 - PMK","CS3005 - JDC"),
                    "B" => array("CS3001 - HHD","CS3002 - RMP","CS3003 - AMN","CS3004 - MMS","CS3005 - PMK")
                )
            // "Sem - 4" => 
            //     array(
            //         "A" => array("CS4001 - HHD","CS4002 - KPP","CS4003 - AKE","CS4004 - AMN"),
            //         "B" => array("CS4001 - NRE","CS4002 - KHB","CS4003 - SAM","CS4004 - MAG")
            //     ),
            // "Sem - 5" => 
            //     array(
            //         "A" => array("CS5001 - AKE","CS5002 - SHP","CS5003 - PMK","CS5004 - DLB","CS5005 - JDC"),
            //         "B" => array("CS5001 - PMK","CS5002 - NRE","CS5003 - SAM","CS5004 - RMP","CS5005 - RMP")
            //     )
        );
        $clashes = 0;
        $clashTchrName = array();
        $allocatedTimes = array(0,0,0,0,0);

        $lecturePerDay = 6;
        $lectureDuration = 1;

        $lectureStartTime = "08:30";
        $breaks = 2;
        $breakStart = array("10:30", "12:40");
        $breakEnds = array("10:40", "01:20");

        # TimeSlots Data
        $startTimeArr = array();
        $endTimeArr = array();

        $days = array("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
        $courseReservedForDay = array();
        $teacherReserved = array();

        function timeSlots() 
        {
            global $lecturePerDay, $lectureStartTime, $lectureDuration, 
                   $startTimeArr, $endTimeArr,$breaks, $breakEnds, $breakStart;

            array_push($startTimeArr,$lectureStartTime);
            $time = date('H:i',strtotime($lectureStartTime) + 60*60*$lectureDuration);
            // $breakStart = $_POST['txtStartBreak'];
            $flag = false;

            for($i = 0; $i < $lecturePerDay+$breaks; $i++) {
                foreach(array_combine($breakStart,$breakEnds) as $bst => $bet) {
                    if($startTimeArr[$i] == $bst) {
                        array_push($startTimeArr,$bet);
                        array_push($endTimeArr,$bet);
                        $flag = true;
                        break;
                    }
                }
                if($flag == true) {
                    $flag = false;
                    continue;
                }
                array_push($startTimeArr,date('H:i',strtotime($startTimeArr[$i]) + 60*60*$lectureDuration));
                array_push($endTimeArr,date('H:i',strtotime($startTimeArr[$i]) + 60*60*$lectureDuration));
            }
            # Removing extra element 
            array_splice($startTimeArr,array_key_last($startTimeArr),1);
        }

        echo '
        <style>
            table, td, th {
                border: 1px solid black;
                border-collapse:collapse;
            }
            table {
                width:85%;
                height:37rem;
            }
        </style>
        ';
$cpw = array();

        # Main function (GUI)
        function genesis() 
        {
            global $startTimeArr, $endTimeArr, $courses, $days, $lecturePerDay, $teacherReserved, $clashes, $cpw,
                   $clashTchrName, $breaks, $breakStart, $allocatedTimes, $courseReservedForDay, $master_sem_courses;

            foreach($master_sem_courses as $sems => $div) 
            {
                echo "<div style='display:flex;'>";
                $allocatedTimes = array_fill(0,count($allocatedTimes),0);
                foreach($div as $d => $courses) 
                {
                    echo "<div style='margin-top:2%;width:39%;margin-right:2%;'>".$sems." (".$d.")<br/><br/>";
                    echo '
                        <table class="table table-striped table-bordered wrap" style="height:20rem;">
                            <thead>
                                <tr>
                                    <th style="width:10%;height:2.8rem;">Time /<br/>Day</th> 
                    ';
                                $count = 0;
                                # For Timing Display
                                foreach (array_combine($startTimeArr,$endTimeArr) as $st => $et) 
                                {
                                    #background-color:pink;
                                    echo "<th style=''>".date("g:i", strtotime($st))."  to ".date("g:i", strtotime($et))."</th>";
                                    if($count >= $lecturePerDay+$breaks) {
                                        break;
                                    }
                                    $count++;
                                }
                    echo '
                                </tr>
                            </thead>
                            <tbody>
                    ';
                    $cntr = 0; 
                    # Vertical view (Days)
                    $coursePerWeek = $allocatedTimes;   # New array creation.
                    foreach($days as $day) 
                    {
                        $cresCntr = 0;
                        $coursePerWeek = array_fill(0,count($allocatedTimes),0);
                        echo "<tr>";
                            # For Timing Display
                            echo "<td style='text-align:center;'>".$days[$cntr]."</td>";
                            # Horizontal view (Courses)
                            for($i = 0; $i < $lecturePerDay+$breaks; $i++) {

                                if($i >= $lecturePerDay+$breaks) { break; }

                                if(in_array($startTimeArr[$i],$breakStart)) {
                                    #background-color:lightyellow;
                                    echo "<td style='text-align:center;'> BREAK </td>";
                                } 
                                else {
                                    $randNum = rand(0,count($courses)-1);
                                    $allocatedTimes[$randNum]++;
                                    if(@in_array($courses[$randNum],$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]])) {
                                        if(@$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]) {
                                            $arr = array_diff($courses,$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]);
                                            foreach($arr as $index => $c) {
                                                if($coursePerWeek[$index] < 2 && !array_key_exists(substr($c,-3,3),$teacherReserved[$day][$startTimeArr[$i]])) {
                                                    $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                    $coursePerWeek[$index]++;
                                                    $teacherReserved[$day][$startTimeArr[$i]][substr($c,-3,3)][] = $sems;
                                                    $check = true;
                        @$cpw[$sems][$d][$c] += 1;
                                                    #green
                                                    echo "<td style='text-align:center;'>
                                                        ".$c."
                                                    </td>";
                                                    break;
                                                }
                                            }
                                        } 
                                        else {
                                            foreach($courses as $index => $c) {
                                                if($coursePerWeek[$index] < 2 && !array_key_exists(substr($c,-3,3),$teacherReserved[$day][$startTimeArr[$i]])) {
                                                    $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                    $coursePerWeek[$index]++;
                                                    $check = true;
                                                    $teacherReserved[$day][$startTimeArr[$i]][substr($c,-3,3)][] = $sems;
                        @$cpw[$sems][$d][$c] += 1;
                                                    #cyan
                                                    echo "<td style='text-align:center;'>
                                                        ".$c."
                                                    </td>";
                                                    break;
                                                }
                                            }
                                        }
                                    } 
                                    else {
                                    //     $check = false;
                                        if($coursePerWeek[$randNum] < 2) {
                                            $checkCRSE = strval(substr($courses[$randNum],-3,3));
                                            if(@array_key_exists($checkCRSE,$teacherReserved[$day][$startTimeArr[$i]])) {
                                                $clashes++;
                                                array_push($clashTchrName,substr($courses[$randNum],-3,3));
                                                $arr = array_diff($courses,$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]);
                                                    foreach($arr as $index => $c) {
                                                        if($coursePerWeek[$index] < 2 && !array_key_exists(substr($c,-3,3),$teacherReserved[$day][$startTimeArr[$i]])) {
                                                            $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                            $coursePerWeek[$index]++;
                                                            $teacherReserved[$day][$startTimeArr[$i]][substr($c,-3,3)][] = $sems;
                                                            $check = true;
                        @$cpw[$sems][$d][$c] += 1;
                                                            #violet
                                                            echo "<td style='text-align:center;'>
                                                                ".$c."
                                                            </td>";
                                                            break;
                                                        }
                                                    }
                                            } 
                                            else {
                                                $checkCRSE = strval(substr($courses[$randNum],-3,3));
                                                if(@!array_key_exists($checkCRSE,$teacherReserved[$day][$startTimeArr[$i]]) && $coursePerWeek[$randNum] < 2) { #
                                                    $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $courses[$randNum];
                                                    $coursePerWeek[$randNum]++;
                                                    $teacherReserved[$day][$startTimeArr[$i]][substr($courses[$randNum],-3,3)][] = $sems;
                                                    $check = true;
                        @$cpw[$sems][$d][$courses[$randNum]] += 1;
                                                    #background-color:lightblue;
                                                    echo 
                                                        "<td style='text-align:center;'>
                                                            ".$courses[$randNum]."
                                                        </td>";
                                                }
                                                else {
                                                    echo 
                                                    "<td style='text-align:center;background-color:red;color:white;'>
                                                        No Course Available
                                                    </td>";
                                                }
                                            }
                                        }
                                        else {
                                            if(@in_array($courses[$randNum],$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]])) {
                                               # Do Nothing.
                                            } else {
                                                if(@$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]) {
                                                    $arr = array_diff($courses,$courseReservedForDay[$days[$cntr]][$startTimeArr[$i]]);
                                                    foreach($arr as $index => $c) {
                                                        if($coursePerWeek[$index] < 2 && !array_key_exists(substr($c,-3,3),$teacherReserved[$day][$startTimeArr[$i]])) {
                                                            $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                            $coursePerWeek[$index]++;
                                                            $teacherReserved[$day][$startTimeArr[$i]][substr($c,-3,3)][] = $sems;
                                                            $check = true;
                        @$cpw[$sems][$d][$c] += 1;
                                                            #lightgreen
                                                            echo "<td style='text-align:center;'>
                                                                ".$c."
                                                            </td>";
                                                            break;
                                                        }
                                                    }
                                                } 
                                                else {
                                                    foreach($courses as $index => $c) {
                                                        if($coursePerWeek[$index] < 2 && @!array_key_exists(substr($c,-3,3),$teacherReserved[$day][$startTimeArr[$i]])) {
                                                            $courseReservedForDay[$days[$cntr]][$startTimeArr[$i]][] = $c;
                                                            $coursePerWeek[$index]++;
                                                            $check = true;
                                                            $teacherReserved[$day][$startTimeArr[$i]][substr($c,-3,3)][] = $sems;
                        @$cpw[$sems][$d][$c] += 1;

                                                            #orange
                                                            echo "<td style='text-align:center;'>
                                                                ".$c."
                                                            </td>";
                                                            break;
                                                        }
                                                    }
                                                }
                                                if($check == false) {
                                                    echo "<td style='text-align:center;background-color:red;'></td>";
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    $cresCntr ++;
                                }
                            }
                        echo "</tr>";
                        $cntr++;
                    }
                    echo '
                            </tbody>
                        </table>
                    </div>
                    <br/>
                    ';
                }
                echo "</div>";
            }
        }

        function structuralFitness () {
            global $master_sem_courses,$teacherReserved;
            # For Divison Count.
            $totalDivs = 0;
            foreach ($master_sem_courses as $key => $value) {
               $totalDivs += count($value);
            }
            foreach($teacherReserved as $schedDay => $schedTime) {
                foreach ($schedTime as $index => $schedTCHR) {
                    if(count($schedTCHR) < $totalDivs) {
                        echo "<script>location.reload();</script>";
                    }
                }
            }
        }
    # Main Execution Block
    # ******************** #
        timeSlots();
        genesis();
        structuralFitness();
    # ******************** #
    echo "<pre>";
    print_r($cpw);
    echo "</pre>";
foreach ($cpw as $index => $value) {
    foreach ($value as $key => $v) {
        foreach ($v as $k => $v1) {
            if($v1 < 3) {
                echo "<script>location.reload();</script>";
            }
        }
    }
}
        echo "<br/><span style='font-weight:bold;'>Total Clashes : </span>".$clashes." found & resolved.<br/>";
        // echo "<span style='font-weight:bold;'>Total Fitness Iterations : </span>".$_SESSION["fitnessCnt"]."<br/>";
        // echo "Please Review Once, Schedule of following teacher/s :";
        // $clashTchrName = array_unique($clashTchrName);
        // foreach($clashTchrName as $name) {echo $name.",&nbsp;";};
        // echo "<pre>";
        // print_r($teacherReserved);
        // echo "</pre>";
        
        // echo "<pre>";
        // print_r($allocatedTimes);
        // echo "</pre>";
        # For Courses Allocated.
        // echo "<pre>";
        // print_r($courseReservedForDay);
        // echo "</pre>";
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>