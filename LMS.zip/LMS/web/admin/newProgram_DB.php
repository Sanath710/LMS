<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" && isset($_POST['btnSubmit']))
    {    
        include("../COMMON_FILES/Connection.php");
        $ProgramID = mysqli_real_escape_string($con,strtoupper($_POST['ProgramID']));
        $ProgramName = mysqli_real_escape_string($con,$_POST['ProgramName']);
        $ProgramStatus = 1;
        // $ProgramDuration = $_POST['ProgramDuration'];

        
        if(!empty($ProgramID) && !empty($ProgramName))
        {
            $sql = "INSERT INTO Mtb_Programme (PRGM_ID, PRGM_Name, PRGM_Code, PRGM_Status) VALUES (?,?,?,?)";
            $stmt = mysqli_stmt_init($con);
            if(!mysqli_stmt_prepare($stmt,$sql))
            {
                echo "Error in Prepare Statement";
                header("refresh:0;url=viewPrograms.php?s=4");
            }
            else
            {
                # For Auto Increment.
                $PRGM_CODE_QRY = "SELECT PRGM_Code FROM Mtb_Programme ORDER BY PRGM_Code DESC LIMIT 1";
                $PRGM_CODE_Data = mysqli_query($con,$PRGM_CODE_QRY);
                $PRMG_CODE = mysqli_fetch_assoc($PRGM_CODE_Data);
                $PRMG_CODE = intval($PRMG_CODE['PRGM_Code'])+1;

                mysqli_stmt_bind_param($stmt,"ssii",$ProgramID,$ProgramName,$PRMG_CODE,$ProgramStatus);
                if(!mysqli_stmt_execute($stmt))
                {
                    header("refresh:0;url=viewPrograms.php?s=1");
                }
                else 
                {
                    header("refresh:0;url=viewPrograms.php?s=2");
                }
            }
        }
        else
        {
            header("refresh:0;url=viewPrograms.php?s=3");
        }
        // if(!mysqli_query($con,$sql))
        // {
        //     header("refresh:0;url=newProgram.php?error=1");
        // }
        // else 
        // {
        //     header("refresh:0;url=viewPrograms.php");
        // }
    }
    else
    {
        echo "You Don't have previleges to access this page.<br/>This incident will be reported along with your IP.";
        header("refresh:2;url=../COMMON_FILES/logout.php");
    }

?>