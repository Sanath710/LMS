<?php
  session_start();
  error_reporting(0);
  if(substr($_SESSION['Sess_USR_Role'],0,1)=="A" || substr($_SESSION['Sess_USR_Role'],0,1)=="H")
  {   
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
      include_once("adminNavbar.php");
    }
    else if(substr($_SESSION['Sess_USR_Role'],0,1)=="H")
    {
      include_once("../HoD/teacherNavbar.php");
    }
    include("../COMMON_FILES/Connection.php");
    $URL_PRGM_Year = substr($_GET['pRgM'],6,4);
    $URL_PRGM_ID = substr($_GET['pRgM'],-11,1);
    $URL_PRGM_Sem = substr($_GET['pRgM'],0,1);
    $URL_PRGM_Name = base64_decode(substr($_GET['pRgM'],-15,4));

    $query ="SELECT PRGM_CRSE_CourseID,PRGM_CRSE_CourseType,CRSE_Name FROM Tb_ProgrammeCourseTypes,Mtb_Courses WHERE CRSE_ID = PRGM_CRSE_CourseID AND PRGM_CRSE_PID = $URL_PRGM_ID
             AND PRGM_CRSE_Sem = $URL_PRGM_Sem AND PRGM_CRSE_AcademicYear = $URL_PRGM_Year";
    $data = mysqli_query($con,$query);
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="../css/datatables.bootstrap4.min.css" />
        <link rel="stylesheet" type="text/css" href="../css/CustomStyle.css?v=<?php echo time(); ?>">
        <style>table tr,table,td {border:none!important;}</style>
    </head>
    <body>
        <div class="pcoded-content">
            <div class="main-body">
                <div class="page-wrapper subBodyProgram">
                    <div class="page-body">
                        <div class="card bodyStyling"> <!-- To avoid background bluish color visibility style="padding-bottom:18%;" -->
                            <div class="card-header" style="margin-top:0.5%;">
                                <h4>Courses in <?php echo $URL_PRGM_Name." ".$URL_PRGM_Year." Sem ".$URL_PRGM_Sem; ?></h4><hr style="width:97.8%; margin-left:0%;"/>
                            </div>
                            <div class="card-block">
                                <div class="dt-responsive table-responsive tableView">
                                    <table id="base-style" style="width:100%; cursor:pointer;" class="table table-striped table-bordered nowrap tableViewProgram">
                                    <thead>
                                        <tr>
                                        <th style="width:7%;">Sr No</th>
                                        <th style="width:17%;">Course ID</th>
                                        <th style="width:55%;">Course Name</th>
                                        <th style="width:18%;">Course Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $cnt = 0;
                                            while($courseResult = mysqli_fetch_assoc($data))
                                            {
                                                echo '
                                                    <tr>
                                                        <td>'.++$cnt.'</td>
                                                        <td>'.$courseResult['PRGM_CRSE_CourseID'].'</td>
                                                        <td>'.$courseResult['CRSE_Name'].'</td>
                                                        <td>';
                                                            if($courseResult['PRGM_CRSE_CourseType']==0)
                                                            {
                                                                echo "Compulsory";
                                                            }
                                                            else
                                                            {
                                                                echo "Elective";
                                                            }
                                                echo    '</td>
                                                    </tr>
                                                ';
                                            }
                                        ?>
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="../js/jquery.datatables.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.buttons.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.bootstrap4.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/datatables.responsive.min.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/data-table-custom.js" type="06ff493bca0b4366a261bcf1-text/javascript"></script>
        <script src="../js/rocket-loader.min.js" data-cf-settings="06ff493bca0b4366a261bcf1-|49" defer=""></script>
    </body>
</html>
<?php
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>