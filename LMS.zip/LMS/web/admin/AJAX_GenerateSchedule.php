<?php
    session_start();
    error_reporting(0);
    if(substr($_SESSION['Sess_USR_Role'],0,1)=="A")
    {
        include("../COMMON_FILES/Connection.php");

        #Form Data
        $programme = $_POST['programme'];
        $semester = $_POST['sem'];
        $year = $_POST['year'];

        #Counter Variable
        $cnt = 1;

        #Query
        $course_QRY = "SELECT PRGM_CRSE_CourseID, CRSE_Name FROM Tb_ProgrammeCourseTypes,Mtb_Courses 
                       WHERE PRGM_CRSE_CourseID = CRSE_ID AND PRGM_CRSE_PID = $programme AND PRGM_CRSE_Sem = $semester 
                       AND PRGM_CRSE_AcademicYear = $year";
        $course_Data = mysqli_query($con,$course_QRY);
        echo 
        "<div style='font-weight:550;font-size:18px;margin-top:1%;'>Available Courses</div>
         <table class='table table-striped table-bordered wrap course-table' id='base-style' style='margin-top:2%;width:110%;margin-bottom:1.5%;'>
            <thead>
                <tr>
                    <th style='text-align:center;width:5%;'>Sr No.</th>
                    <th style='width:18%;text-align:center;'>Course ID</th>
                    <th style='word-wrap: break-word;'> &nbsp; Course Name</th>
                    <th style='width:5%;text-align:center;'>Require <br/>Extra Lecture ?</th>
                </tr>
            </thead>
            <tbody>
        ";
            while($courses = mysqli_fetch_assoc($course_Data)) {
                echo 
                "<tr>
                    <td style='text-align:center;'>".$cnt++."</td>
                    <td style='text-align:center;'>".$courses['PRGM_CRSE_CourseID']."</td>
                    <td> &nbsp; ".$courses['CRSE_Name']."</td>
                    <td style='text-align:center;'><input type='checkbox' style='cursor:pointer;' value='".$courses['PRGM_CRSE_CourseID']."' name='chkExtraLec[]' /></td>
                    <input type='hidden' style='display:none;' value='".$courses['PRGM_CRSE_CourseID']."' name='txtCourses[]' />
                 </tr>
                ";
            }
        echo 
        "   </tbody>
        </table>";
        echo "<input type='hidden' name='txtTotalCourses' value='".($cnt-1)."' style='display:none;'/>";
    }
    else
    {
        header('Location:../COMMON_FILES/logout.php');
    }
?>