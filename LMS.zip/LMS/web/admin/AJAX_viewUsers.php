<?php

    include("../COMMON_FILES/Connection.php");
    error_reporting(0);

    $PRO = $_POST['programme'];
    $AY = $_POST['AY'];
    $SEM = $_POST['sem'];
    $userType = $_POST['type'];
    $Div = $_POST['Div'];

    if($userType == "B") # B = Both
    {
        $sql= "SELECT USR_ID, USR_FirstName,USR_LastName,USR_ContactNo,USR_EmailID FROM Mtb_Users,Tb_CourseUsers 
               WHERE UID = CRSE_USR_UID AND CRSE_USR_Sem = $SEM AND CRSE_USR_PID = $PRO AND CRSE_USR_Year = $AY AND CRSE_USR_Division = '$Div'
               GROUP BY USR_ID";
    } else if($userType == "T") {
        $sql= "SELECT USR_ID, USR_FirstName,USR_LastName,USR_ContactNo,USR_EmailID FROM Mtb_Users,Tb_CourseUsers 
               WHERE UID = CRSE_USR_UID AND CRSE_USR_Sem = $SEM AND CRSE_USR_PID = $PRO AND CRSE_USR_Year = $AY AND USR_ID NOT LIKE 'S%'
               AND CRSE_USR_Division = '$Div'
               GROUP BY USR_ID";
    } else {
        $sql= "SELECT USR_ID, USR_FirstName,USR_LastName,USR_ContactNo,USR_EmailID FROM Mtb_Users,Tb_CourseUsers 
               WHERE UID = CRSE_USR_UID AND CRSE_USR_Sem = $SEM AND CRSE_USR_PID = $PRO AND CRSE_USR_Year = $AY AND USR_ID LIKE '$userType%'
               AND CRSE_USR_Division = '$Div'
               GROUP BY USR_ID";
    }
    $data = mysqli_query($con,$sql);
    $dataCheck = mysqli_query($con,$sql);
    if(@mysqli_fetch_assoc($dataCheck)) {
        echo '
        <table id="base-style" style="width:100%;cursor:pointer;" class="table table-striped table-bordered nowrap tableViewProgram">
        <thead>
            <tr>
                <th style="width:2%;">No.</th>
                <th style="width:13%;">User ID</th>
                <th style="width:16%;">User Name</th>
                <th style="width:16%;">Contact No</th>
                <th style="width:20%;">Email ID</th>
            </tr>
        </thead>
        <tbody>';

            $cnt=1;
            while ($result = mysqli_fetch_assoc($data)) 
            {
                echo '
                <tr class="RowHeight" onclick="edit(this)">
                    <td >'.$cnt.'</td>
                    <td class="height_td">
                        '.$result['USR_ID'].'
                    </td>
                    <td style="text-align:left;" >
                        '.$result['USR_FirstName']." ".$result['USR_LastName'].'
                    </td>
                    <td style="text-align:left;" >
                        '.$result['USR_ContactNo'].'
                    </td>
                    <td style="text-align:left;" >
                    '.$result['USR_EmailID'].'
                </td>
                </tr>';
            $cnt++;
        }
        echo '</tbody>
            </table>';
    }
    else  {
        echo "<h4 style='color:red;'>No Users Found.</h4>";
    }
?>